import os
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon, QPalette
from PyQt6.QtWidgets import QApplication, QSystemTrayIcon

from fleasion import tray as tray_module
from fleasion import app as app_module
from fleasion.utils import platform_macos
from fleasion.tray import SystemTray, _XfceTrayNotification


class _DashboardStub:
    def __init__(self, visible: bool):
        self.visible = visible
        self.hide_calls = 0

    def isVisible(self):
        return self.visible

    def hide(self):
        self.visible = False
        self.hide_calls += 1


class _TrayIconStub:
    def __init__(self):
        self.hide_calls = 0
        self.context_menus = []
        self.delete_later_calls = 0

    def hide(self):
        self.hide_calls += 1

    def setContextMenu(self, menu):
        self.context_menus.append(menu)

    def deleteLater(self):
        self.delete_later_calls += 1


def test_linux_gui_dependency_check_reports_install_command(monkeypatch):
    from fleasion.utils import platform_linux

    critical_calls = []
    log_calls = []
    monkeypatch.setattr(app_module.sys, 'platform', 'linux')
    monkeypatch.setattr(platform_linux, 'missing_linux_gui_packages', lambda: ['qt6-base'])
    monkeypatch.setattr(
        app_module.QMessageBox,
        'critical',
        lambda *args: critical_calls.append(args),
    )
    monkeypatch.setattr(
        app_module.log_buffer,
        'log',
        lambda category, message: log_calls.append((category, message)),
    )

    assert app_module._check_linux_gui_dependencies() is False
    assert 'sudo pacman -S --needed qt6-base' in critical_calls[0][2]
    assert 'Required package:\n  • qt6-base' in critical_calls[0][2]
    assert log_calls == [
        (
            'Linux GUI',
            'A required Arch Linux GUI package is missing.\n'
            '  Package: qt6-base\n'
            '  Impact: Fleasion cannot reliably publish its system tray icon.\n'
            '  Install: sudo pacman -S --needed qt6-base',
        )
    ]


def test_linux_gui_dependency_check_accepts_complete_runtime(monkeypatch):
    from fleasion.utils import platform_linux

    monkeypatch.setattr(app_module.sys, 'platform', 'linux')
    monkeypatch.setattr(platform_linux, 'missing_linux_gui_packages', lambda: [])

    assert app_module._check_linux_gui_dependencies() is True


def test_dashboard_toggle_hides_visible_window():
    system_tray = SystemTray.__new__(SystemTray)
    dashboard = _DashboardStub(visible=True)
    foreground_modes = []
    system_tray.dashboard_window = dashboard
    system_tray._show_replacer_config = lambda: None
    system_tray._set_dashboard_foreground_mode = foreground_modes.append

    system_tray._toggle_dashboard()

    assert dashboard.hide_calls == 1
    assert foreground_modes == [False]


def test_xfce_desktop_detection(monkeypatch):
    monkeypatch.delenv('XDG_CURRENT_DESKTOP', raising=False)
    monkeypatch.delenv('XDG_SESSION_DESKTOP', raising=False)
    monkeypatch.setenv('DESKTOP_SESSION', 'xfce')

    assert tray_module._is_xfce_desktop() is True

    monkeypatch.setenv('DESKTOP_SESSION', 'gnome')
    assert tray_module._is_xfce_desktop() is False


def test_xfce_notification_uses_an_opaque_surface():
    app = QApplication.instance() or QApplication([])
    notification = _XfceTrayNotification(
        'Fleasion',
        'Fleasion is still running in the system tray.',
        QIcon(),
        True,
        1000,
    )

    assert not notification.testAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
    assert notification.testAttribute(Qt.WidgetAttribute.WA_StyledBackground)
    assert notification.autoFillBackground()
    assert notification.palette().color(QPalette.ColorRole.Window).alpha() == 255

    notification.close()
    app.processEvents()


def test_dashboard_close_uses_styled_notification_on_xfce(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    calls = []

    class _TrayStub:
        def showMessage(self, *args):
            calls.append(('native', args))

    system_tray._dashboard_close_notice_shown = False
    system_tray.tray = _TrayStub()
    system_tray._show_xfce_notification = lambda *args: calls.append(('xfce', args)) or True
    monkeypatch.setattr(tray_module.sys, 'platform', 'linux')
    monkeypatch.setattr(tray_module, '_is_xfce_desktop', lambda: True)
    monkeypatch.setattr(tray_module, 'get_icon_path', lambda: None)

    system_tray.notify_dashboard_closed()

    assert [call[0] for call in calls] == ['xfce']


def test_dashboard_toggle_shows_hidden_window():
    system_tray = SystemTray.__new__(SystemTray)
    dashboard = _DashboardStub(visible=False)
    show_calls = []
    system_tray.dashboard_window = dashboard
    system_tray._show_replacer_config = lambda: show_calls.append(True)

    system_tray._toggle_dashboard()

    assert show_calls == [True]


def test_show_logs_raises_and_activates_new_window(monkeypatch):
    app = QApplication.instance() or QApplication([])
    calls = []

    class _RecordingLogsWindow(tray_module.LogsWindow):
        def show(self):
            calls.append('show')
            super().show()

        def raise_(self):
            calls.append('raise')
            super().raise_()

        def activateWindow(self):
            calls.append('activate')
            super().activateWindow()

    system_tray = SystemTray.__new__(SystemTray)
    system_tray.open_windows = []
    system_tray._apply_always_on_top_to_window = lambda _window: None
    monkeypatch.setattr(tray_module, 'LogsWindow', _RecordingLogsWindow)

    system_tray._show_logs()
    app.processEvents()

    assert calls[:3] == ['show', 'raise', 'activate']
    assert len(system_tray.open_windows) == 1
    assert system_tray.open_windows[0].isVisible()

    system_tray.open_windows[0].close()
    app.processEvents()
    assert system_tray.open_windows == []


def test_show_dashboard_enables_foreground_mode_before_showing_existing_window():
    system_tray = SystemTray.__new__(SystemTray)
    calls = []
    dashboard = _DashboardStub(visible=False)
    dashboard.show = lambda: calls.append('show')
    dashboard.raise_ = lambda: calls.append('raise')
    dashboard.activateWindow = lambda: calls.append('activate')
    system_tray.dashboard_window = dashboard
    system_tray._set_dashboard_foreground_mode = lambda enabled: calls.append(('foreground', enabled))

    system_tray._show_replacer_config()

    assert calls == [('foreground', True), 'show', 'raise', 'activate']


def test_macos_menu_bar_activation_does_not_hide_dashboard(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    toggle_calls = []
    system_tray._toggle_dashboard = lambda: toggle_calls.append(True)
    monkeypatch.setattr(tray_module.sys, 'platform', 'darwin')

    system_tray._on_tray_activated(QSystemTrayIcon.ActivationReason.Trigger)

    assert toggle_calls == []


def test_macos_dashboard_foreground_mode_reapplies_dock_icon(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    calls = []
    icon_path = Path('/tmp/fleasion-test-icon.ico')

    monkeypatch.setattr(tray_module.sys, 'platform', 'darwin')
    monkeypatch.setattr(tray_module, 'get_icon_path', lambda: icon_path)
    monkeypatch.setattr(
        platform_macos,
        'set_application_foreground_mode',
        lambda enabled: calls.append(('foreground', enabled)) or True,
    )
    monkeypatch.setattr(
        platform_macos,
        'set_application_icon',
        lambda path: calls.append(('icon', path)) or True,
    )

    system_tray._set_dashboard_foreground_mode(True)

    assert calls == [('foreground', True), ('icon', icon_path)]


def test_windows_tray_activation_still_toggles_dashboard(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    toggle_calls = []
    system_tray._toggle_dashboard = lambda: toggle_calls.append(True)
    monkeypatch.setattr(tray_module.sys, 'platform', 'win32')

    system_tray._on_tray_activated(QSystemTrayIcon.ActivationReason.Trigger)

    assert toggle_calls == [True]


def test_cleanup_tray_icon_hides_and_deletes_once(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    tray_icon = _TrayIconStub()
    process_events_calls = []
    system_tray.tray = tray_icon
    system_tray._tray_cleaned_up = False
    monkeypatch.setattr(tray_module.QApplication, 'processEvents', lambda: process_events_calls.append(True))

    system_tray.cleanup_tray_icon()
    system_tray.cleanup_tray_icon()

    assert tray_icon.hide_calls == 1
    assert tray_icon.context_menus == [None]
    assert tray_icon.delete_later_calls == 1
    assert process_events_calls == [True]


def test_exit_app_cleans_tray_before_quitting(monkeypatch):
    system_tray = SystemTray.__new__(SystemTray)
    calls = []

    class _AppStub:
        def quit(self):
            calls.append('quit')

    class _ProxyMasterStub:
        def stop(self):
            calls.append('stop')

    system_tray.app = _AppStub()
    system_tray.proxy_master = _ProxyMasterStub()
    system_tray.cleanup_tray_icon = lambda: calls.append('cleanup')
    monkeypatch.setattr(tray_module, 'run_in_thread', lambda func: func)

    system_tray._exit_app()

    assert system_tray._exiting is True
    assert calls[0] == 'cleanup'
    assert calls[-1] == 'quit'


def test_ensure_exit_action_keeps_exit_enabled():
    system_tray = SystemTray.__new__(SystemTray)
    calls = []

    class _ActionStub:
        def setEnabled(self, enabled):
            calls.append(enabled)

    system_tray.exit_action = _ActionStub()

    system_tray._ensure_exit_action_enabled()

    assert calls == [True]


def test_linux_helper_start_failure_keeps_proxy_features_enabled(monkeypatch):
    config = SimpleNamespace(proxy_features_enabled=True)
    calls = []
    warnings = []
    tray = SimpleNamespace(update_status=lambda: calls.append('update_status'))
    monkeypatch.setattr(app_module.sys, 'platform', 'linux')
    monkeypatch.setattr(app_module.QMessageBox, 'warning', lambda *args, **kwargs: warnings.append((args, kwargs)))

    app_module._disable_proxy_features_after_start_failure(
        config,
        tray,
        'Linux Polkit approval was denied or the proxy helper could not start',
    )

    assert calls == ['update_status']
    assert warnings
    assert config.proxy_features_enabled is True
