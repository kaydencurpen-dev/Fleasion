"""Cache viewer tab - simplified version for viewing cached assets."""

import gzip as gzip_module
import io
import json
import sys
import threading

from PIL import Image
from PyQt6.QtCore import QEvent, Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import (
    QAction,
    QColor,
    QCursor,
    QFont,
    QFontDatabase,
    QImage,
    QPalette,
    QPixmap,
)
from PyQt6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
    QWidgetAction,
)

from ..utils import format_count, log_buffer, open_folder
from ..utils.clipboard import copy_pixmap_to_clipboard
from ..utils.roblox_auth import get_roblosecurity as _get_roblosecurity
from . import mesh_processing
from .animation_viewer import AnimationViewerPanel
from .audio_player import AudioPlayerWidget
from .cache_json_viewer import CacheJsonViewer
from .cache_manager import CacheManager
from .font_viewer import FontViewerWidget
from .obj_viewer import ObjViewerPanel
from .rbxm_preview import RbxmPreviewWidget, is_rbx_model_data


def _format_table_timestamp(value) -> str:
    """Format ISO-ish timestamps for scraper table date columns."""
    text = str(value or '')
    if not text:
        return ''
    try:
        if 'T' in text:
            date_part, time_part = text.split('T', 1)
            time_part = time_part.rstrip('Z')
            time_part = time_part.split('.', 1)[0]
            return f'{date_part} {time_part}'
    except ValueError, AttributeError:
        pass
    return text


def _asset_metadata_needs_resolution(info: dict) -> bool:
    """Return whether an asset still has display metadata to resolve.

    Creator lookup can fail independently of the asset metadata request.  A
    numeric creator ID is therefore not a completed creator resolution: keep
    the asset eligible for a later retry until the display name is stored.
    """
    if (
        info.get('resolved_name') is None
        or info.get('created_at') is None
        or info.get('updated_at') is None
    ):
        return True

    return info.get('creator_id') is not None and info.get('creator_name') is None


class NumericSortItem(QTableWidgetItem):
    """Custom table item that sorts based on a numeric value rather than text."""

    def __init__(self, numeric_val, text):
        super().__init__(text)
        self.numeric_val = numeric_val

    def __lt__(self, other):
        if isinstance(other, NumericSortItem):
            return self.numeric_val < other.numeric_val
        return super().__lt__(other)


class SearchWorkerThread(QThread):
    """Worker thread for filtering assets without blocking UI."""

    results_ready = pyqtSignal(list)

    def __init__(self, assets: list, search_text: str, asset_info: dict, search_columns=None):
        super().__init__()
        self.assets = assets
        self.search_text = search_text.strip().lower()
        self.asset_info = asset_info
        self.search_columns = (
            search_columns if search_columns is not None else _DEFAULT_SEARCH_COL_KEYS
        )
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        """Filter assets in background thread."""
        if not self.search_text or self._stop_requested:
            self.results_ready.emit(self.assets)
            return

        filtered = []
        batch_size = 100  # Process in batches to allow interruption

        for i in range(0, len(self.assets), batch_size):
            if self._stop_requested:
                return

            batch = self.assets[i : i + batch_size]

            for a in batch:
                if self._stop_requested:
                    return

                asset_id = a['id']
                cols = self.search_columns
                matched = False

                if not matched and 'id' in cols and self.search_text in asset_id.lower():
                    matched = True

                if not matched and 'type' in cols and self.search_text in a['type_name'].lower():
                    matched = True

                if (
                    not matched
                    and ('name' in cols or 'creator' in cols)
                    and asset_id in self.asset_info
                ):
                    info = self.asset_info[asset_id]
                    if 'name' in cols:
                        name = info.get('resolved_name')
                        if name and self.search_text in name.lower():
                            matched = True
                    if not matched and 'creator' in cols:
                        creator_name = info.get('creator_name')
                        if creator_name and self.search_text in creator_name.lower():
                            matched = True

                if not matched and 'url' in cols and self.search_text in a.get('url', '').lower():
                    matched = True

                if not matched and 'hash' in cols and self.search_text in a.get('hash', '').lower():
                    matched = True

                if (
                    not matched
                    and 'cached_at' in cols
                    and (
                        self.search_text in a.get('cached_at', '').lower()
                        or self.search_text in _format_table_timestamp(a.get('cached_at')).lower()
                    )
                ):
                    matched = True

                if not matched and ('updated_at' in cols or 'created_at' in cols):
                    info = self.asset_info.get(asset_id, {})
                    updated_at = info.get('updated_at') or a.get('resolved_updated_at') or ''
                    created_at = info.get('created_at') or a.get('resolved_created_at') or ''
                    updated_display = _format_table_timestamp(updated_at).lower()
                    created_display = _format_table_timestamp(created_at).lower()
                    if 'updated_at' in cols and (
                        self.search_text in updated_at.lower()
                        or self.search_text in updated_display
                    ):
                        matched = True
                    if (
                        not matched
                        and 'created_at' in cols
                        and (
                            self.search_text in created_at.lower()
                            or self.search_text in created_display
                        )
                    ):
                        matched = True

                if matched:
                    filtered.append(a)

        if not self._stop_requested:
            self.results_ready.emit(filtered)


class TypeProbeWorker(QThread):
    """Resolve corrected asset types from small payload headers off the UI thread."""

    results_ready = pyqtSignal(list)

    def __init__(self, cache_manager: CacheManager, requests: list[tuple]):
        super().__init__()
        self.cache_manager = cache_manager
        self.requests = requests
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        results = []
        for asset_id, asset_type, cache_hash in self.requests:
            if self._stop_requested:
                return

            try:
                detected_type = self.cache_manager.detect_asset_type_from_header(
                    asset_id, asset_type
                )
            except Exception as e:
                log_buffer.log('Scraper', f'Failed to detect type for {asset_id}: {e}')
                detected_type = None

            results.append((asset_id, asset_type, cache_hash, detected_type))

        if not self._stop_requested:
            self.results_ready.emit(results)


class DeleteWorkerThread(QThread):
    """Worker thread for deleting multiple assets without blocking UI."""

    progress = pyqtSignal(int, int)  # (current, total)
    deletion_complete = pyqtSignal(int, int)  # (deleted_count, failed_count)

    def __init__(self, assets: list, cache_manager):
        super().__init__()
        self.assets = assets
        self.cache_manager = cache_manager
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        """Delete assets in background thread using batch delete for efficiency."""
        if self._stop_requested or not self.assets:
            self.deletion_complete.emit(0, 0)
            return

        # Convert assets list to (asset_id, asset_type) tuples
        assets_to_delete = [(a['id'], a['type']) for a in self.assets]

        # Use batch delete which only writes index once (much faster than N writes)
        deleted_count, failed_count = self.cache_manager.delete_assets_batch(assets_to_delete)

        if not self._stop_requested:
            self.deletion_complete.emit(deleted_count, failed_count)


class ImageLoaderThread(QThread):
    """Worker thread for loading and processing images."""

    image_ready = pyqtSignal(QPixmap)
    error = pyqtSignal(str)

    def __init__(self, data: bytes):
        super().__init__()
        self.data = data
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        try:
            log_buffer.log('Preview', f'Loading image ({len(self.data)} bytes)')

            data = self.data
            from .tools.ktx_to_png import convert as _ktx_convert, strip_prefixed_ktx

            ktx_payload = strip_prefixed_ktx(data)
            if ktx_payload is not None:
                log_buffer.log('Preview', 'KTX detected, converting to PNG...')
                data = _ktx_convert(ktx_payload)
                if data is None:
                    if not self._stop_requested:
                        self.error.emit('KTX Conversion failed, see logs for details.')
                    return

            image = Image.open(io.BytesIO(data))

            if self._stop_requested:
                return

            # Convert to RGBA
            if image.mode not in ('RGB', 'RGBA'):
                image = image.convert('RGBA')
            elif image.mode == 'RGB':
                image = image.convert('RGBA')

            if self._stop_requested:
                return

            qimage = QImage(
                image.tobytes(),
                image.width,
                image.height,
                QImage.Format.Format_RGBA8888,
            )
            pixmap = QPixmap.fromImage(qimage)

            if not self._stop_requested:
                log_buffer.log('Preview', f'Image loaded: {image.width}x{image.height}')
                self.image_ready.emit(pixmap)

        except Exception as e:
            if not self._stop_requested:
                log_buffer.log('Preview', f'Image load error: {e}')
                self.error.emit(str(e))


class MeshLoaderThread(QThread):
    """Worker thread for loading and converting meshes."""

    mesh_ready = pyqtSignal(str)  # OBJ content
    error = pyqtSignal(str)

    def __init__(self, data: bytes, asset_id: str):
        super().__init__()
        self.data = data
        self.asset_id = asset_id
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        try:
            log_buffer.log('Preview', f'Loading mesh {self.asset_id} ({len(self.data)} bytes)')

            # Decompress if gzip
            decompressed = self.data
            if self.data.startswith(b'\x1f\x8b'):
                decompressed = gzip_module.decompress(self.data)
                log_buffer.log('Preview', f'Decompressed mesh: {len(decompressed)} bytes')

            if self._stop_requested:
                return

            # Convert to OBJ
            obj_content = mesh_processing.convert(decompressed)

            if self._stop_requested:
                return

            if obj_content:
                log_buffer.log('Preview', f'Mesh converted successfully')
                self.mesh_ready.emit(obj_content)
            else:
                self.error.emit('Failed to convert mesh to OBJ format')

        except Exception as e:
            if not self._stop_requested:
                log_buffer.log('Preview', f'Mesh conversion error: {e}')
                self.error.emit(str(e))


class SolidModelLoaderThread(QThread):
    """Worker thread for loading and converting solid models (CSG)."""

    mesh_ready = pyqtSignal(str)  # OBJ content
    error = pyqtSignal(str)

    def __init__(self, data: bytes, asset_id: str):
        super().__init__()
        self.data = data
        self.asset_id = asset_id
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        try:
            log_buffer.log(
                'Preview',
                f'Loading SolidModel {self.asset_id} ({len(self.data)} bytes)',
            )

            if self._stop_requested:
                return

            # Convert to OBJ using solidmodel_converter
            import gzip as gzip_module
            import tempfile
            from pathlib import Path

            from .tools.solidmodel_converter.converter import (
                _export_obj_from_doc,
                deserialize_rbxm,
            )

            # Decompress if gzip
            decompressed = self.data
            if self.data.startswith(b'\x1f\x8b'):
                decompressed = gzip_module.decompress(self.data)
                log_buffer.log('Preview', f'Decompressed SolidModel: {len(decompressed)} bytes')

            # Use memory directly and dump to temp file because the library forces Path based OBJ output currently
            doc = deserialize_rbxm(decompressed)

            with tempfile.NamedTemporaryFile(suffix='.obj', delete=False) as f:
                temp_obj_path = Path(f.name)

            try:
                _export_obj_from_doc(doc, temp_obj_path, decompose=False)
                obj_content = temp_obj_path.read_text(encoding='utf-8')
            finally:
                if temp_obj_path.exists():
                    temp_obj_path.unlink()

            if self._stop_requested:
                return

            if obj_content:
                log_buffer.log('Preview', f'SolidModel converted successfully')
                self.mesh_ready.emit(obj_content)
            else:
                self.error.emit('Failed to convert SolidModel to OBJ format')

        except Exception as e:
            if not self._stop_requested:
                log_buffer.log('Preview', f'SolidModel conversion error: {e}')
                self.error.emit(str(e))


class AnimationLoaderThread(QThread):
    """Worker thread for loading animation data asynchronously."""

    animation_ready = pyqtSignal(bytes)  # Animation data ready to load into viewer
    error = pyqtSignal(str)

    def __init__(self, data: bytes, asset_id: str):
        super().__init__()
        self.data = data
        self.asset_id = asset_id
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        try:
            # Decompress if gzip
            decompressed = self.data
            if self.data.startswith(b'\x1f\x8b'):
                decompressed = gzip_module.decompress(self.data)
                log_buffer.log('Preview', f'Decompressed animation: {len(decompressed)} bytes')

            if self._stop_requested:
                return

            # Emit the data for the main thread to load into the viewer
            # The actual animation loading must happen on main thread due to OpenGL context
            self.animation_ready.emit(decompressed)

        except Exception as e:
            if not self._stop_requested:
                log_buffer.log('Preview', f'Animation load error: {e}')
                self.error.emit(str(e))


class TexturePackLoaderThread(QThread):
    """Worker thread for loading texture pack images asynchronously."""

    texture_loaded = pyqtSignal(str, str, str, bytes)  # map_name, map_id, hash, image_data
    texture_error = pyqtSignal(str, str)  # map_name, error_message
    finished_loading = pyqtSignal()

    def __init__(self, maps: dict, cache_manager: 'CacheManager', cache_scraper=None):
        super().__init__()
        self.maps = maps
        self.cache_manager = cache_manager
        self._cache_scraper = cache_scraper
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        from urllib.parse import urlparse

        log_buffer.log('Preview', f'Loading texture pack with {len(self.maps)} maps')

        for map_name, map_id in self.maps.items():
            if self._stop_requested:
                return

            try:
                data = self.cache_manager.get_asset(str(map_id), 1)
                hash_val = ''

                if data:
                    asset_info = self.cache_manager.get_asset_info(str(map_id), 1)
                    hash_val = asset_info.get('hash', '') if asset_info else ''
                    log_buffer.log('Preview', f'Loaded {map_name} from cache')
                else:
                    if self._stop_requested:
                        return

                    log_buffer.log('Preview', f'Fetching {map_name} from API')
                    # Use scraper's bypass fetch if available (bypasses hosts file redirect)
                    if self._cache_scraper is not None:
                        cookie = _get_roblosecurity()
                        extra = {}
                        if cookie:
                            extra['Cookie'] = f'.ROBLOSECURITY={cookie};'
                        data = self._cache_scraper._https_get(
                            'assetdelivery.roblox.com',
                            f'/v1/asset/?id={map_id}',
                            extra_headers=extra or None,
                        )
                        if not data:
                            self.texture_error.emit(map_name, 'API returned no data')
                            continue
                    else:
                        # Fallback: direct requests (only works when proxy is not running)
                        import requests as _requests

                        api_url = f'https://assetdelivery.roblox.com/v1/asset/?id={map_id}'
                        headers = {'User-Agent': 'Mozilla/5.0'}
                        cookie = _get_roblosecurity()
                        if cookie:
                            headers['Cookie'] = f'.ROBLOSECURITY={cookie};'
                        response = _requests.get(api_url, headers=headers, timeout=10)
                        if response.status_code == 200 and response.content:
                            data = response.content
                        else:
                            self.texture_error.emit(map_name, f'API error: {response.status_code}')
                            continue

                if self._stop_requested:
                    return

                self.texture_loaded.emit(map_name, str(map_id), hash_val, data)

            except Exception as e:
                if not self._stop_requested:
                    log_buffer.log('Preview', f'Texture {map_name} error: {e}')
                    self.texture_error.emit(map_name, str(e))

        if not self._stop_requested:
            log_buffer.log('Preview', 'Texture pack loading complete')
            self.finished_loading.emit()


class AssetLoaderThread(QThread):
    """Worker thread for downloading assets from Roblox API and storing them in the cache."""

    progress = pyqtSignal(int, int)  # (current, total)
    asset_loaded = pyqtSignal(str, str, int)  # (asset_id, name, asset_type)
    finished_loading = pyqtSignal(int, int)  # (loaded_count, failed_count)
    status_message = pyqtSignal(str)  # status text for the dialog

    def __init__(self, asset_ids: list[int], cache_manager: 'CacheManager', cache_scraper=None):
        super().__init__()
        self.asset_ids = asset_ids
        self.cache_manager = cache_manager
        self._cache_scraper = cache_scraper
        self._stop_requested = False

    def stop(self):
        self._stop_requested = True

    def run(self):
        import time

        import requests

        total = len(self.asset_ids)
        loaded_count = 0
        failed_count = 0

        if not self.asset_ids or self._stop_requested:
            self.finished_loading.emit(0, 0)
            return

        # Get authentication cookie
        cookie = _get_roblosecurity()

        # Build session
        sess = requests.Session()
        sess.trust_env = False
        sess.proxies = {}
        sess.headers.update(
            {
                'User-Agent': 'Roblox/WinInet',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Referer': 'https://www.roblox.com/',
                'Origin': 'https://www.roblox.com',
            }
        )
        if cookie:
            try:
                sess.cookies.set('.ROBLOSECURITY', cookie)
            except Exception:
                sess.headers['Cookie'] = f'.ROBLOSECURITY={cookie};'

        # Phase 1: Batch-fetch asset metadata (name, type, creator, timestamps) in groups of 50
        self.status_message.emit('Fetching asset info...')
        log_buffer.log('Scraper', f'[Load Asset] Fetching info for {format_count(total, "asset")}')

        asset_metadata = {}  # asset_id_str -> {name, type, creator_id, creator_type, created_at, updated_at}
        batch_size = 50
        str_ids = [str(aid) for aid in self.asset_ids]

        for i in range(0, len(str_ids), batch_size):
            if self._stop_requested:
                self.finished_loading.emit(loaded_count, failed_count)
                return

            batch = str_ids[i : i + batch_size]
            query = ','.join(batch)
            url = f'https://develop.roblox.com/v1/assets?assetIds={query}'

            try:
                response = sess.get(url, timeout=10)
                response.raise_for_status()
                data = response.json().get('data', [])
                for item in data:
                    aid = item.get('id')
                    if aid is None:
                        continue
                    creator_obj = item.get('creator') or {}
                    creator_id = None
                    creator_type = None
                    if isinstance(creator_obj, dict) and creator_obj:
                        creator_id = creator_obj.get('targetId')
                        creator_type = creator_obj.get('typeId')
                    if creator_id is None:
                        creator_id = item.get('creatorTargetId')
                    if creator_type is None:
                        creator_type = item.get('creatorType')
                    try:
                        if creator_type is not None:
                            creator_type = int(creator_type)
                    except Exception:
                        creator_type = None
                    try:
                        if creator_id is not None:
                            creator_id = int(creator_id)
                    except Exception:
                        creator_id = None

                    asset_metadata[str(aid)] = {
                        'name': item.get('name', 'Unknown'),
                        'type': item.get('typeId') or item.get('assetTypeId') or 1,
                        'creator_id': creator_id,
                        'creator_type': creator_type,
                        'created_at': item.get('created') or '',
                        'updated_at': item.get('updated') or '',
                    }
                log_buffer.log(
                    'Scraper',
                    f'[Load Asset] Fetched metadata for batch {i // batch_size + 1}',
                )
            except Exception as e:
                log_buffer.log('Scraper', f'[Load Asset] Failed to fetch metadata batch: {e}')

        # Phase 2: Resolve creator names
        creators_to_resolve = {}
        for meta in asset_metadata.values():
            cid = meta.get('creator_id')
            ctype = meta.get('creator_type')
            if cid is not None and ctype is not None and cid not in creators_to_resolve:
                creators_to_resolve[cid] = ctype

        creator_names = {}
        if creators_to_resolve:
            self.status_message.emit('Resolving creator names...')
            log_buffer.log(
                'Scraper',
                f'[Load Asset] Resolving {format_count(creators_to_resolve, "creator name")}',
            )

            # Batch-resolve users
            user_ids = [cid for cid, ctype in creators_to_resolve.items() if ctype == 1]
            group_ids = [cid for cid, ctype in creators_to_resolve.items() if ctype == 2]

            if user_ids:
                try:
                    resp = sess.post(
                        'https://users.roblox.com/v1/users',
                        json={'userIds': user_ids, 'excludeBannedUsers': False},
                        timeout=10,
                    )
                    resp.raise_for_status()
                    for entry in resp.json().get('data', []):
                        uid = entry.get('id')
                        name = entry.get('name') or entry.get('displayName') or 'Unknown'
                        if uid is not None:
                            creator_names[uid] = name
                except Exception as e:
                    log_buffer.log('Scraper', f'[Load Asset] Failed to fetch user names: {e}')

            for gid in group_ids:
                if self._stop_requested:
                    break
                try:
                    resp = sess.get(
                        f'https://groups.roblox.com/v1/groups/{gid}',
                        timeout=10,
                    )
                    resp.raise_for_status()
                    name = resp.json().get('name', 'Unknown')
                    creator_names[gid] = name
                except Exception as e:
                    log_buffer.log('Scraper', f'[Load Asset] Failed to fetch group {gid}: {e}')

        # Store creator names back into asset_metadata
        for meta in asset_metadata.values():
            cid = meta.get('creator_id')
            if cid is not None and cid in creator_names:
                meta['creator_name'] = creator_names[cid]

        # Phase 3: Download each asset's data and store in cache IN PARALLEL
        # Use ThreadPoolExecutor for concurrent downloads to dramatically improve speed.
        # The V1 assetdelivery endpoint doesn't support batch data download, so we
        # parallelize individual requests. 6 workers gives good throughput without
        # hitting rate limits too aggressively.
        self.status_message.emit('Downloading assets...')
        log_buffer.log(
            'Scraper',
            f'[Load Asset] Starting parallel download of {format_count(total, "asset")}',
        )

        import threading as _threading
        from concurrent.futures import ThreadPoolExecutor, as_completed

        _progress_lock = _threading.Lock()
        _progress_count = [0]  # mutable counter for closure

        def _download_one(aid_str: str) -> tuple[str, bool]:
            """Download a single asset. Returns (aid_str, success)."""
            if self._stop_requested:
                return aid_str, False

            meta = asset_metadata.get(aid_str)
            asset_type = meta['type'] if meta else 1
            asset_name = meta['name'] if meta else 'Unknown'

            try:
                if self._cache_scraper is not None:
                    extra = {}
                    if cookie:
                        extra['Cookie'] = f'.ROBLOSECURITY={cookie};'
                    data, _status = self._cache_scraper._fetch_asset_with_place_id_retry(
                        aid_str,
                        extra_headers=extra or None,
                    )
                else:
                    api_url = f'https://assetdelivery.roblox.com/v1/asset/?id={aid_str}'
                    dl_headers = {'User-Agent': 'Roblox/WinInet'}
                    if cookie:
                        dl_headers['Cookie'] = f'.ROBLOSECURITY={cookie};'
                    resp = sess.get(api_url, headers=dl_headers, timeout=15, allow_redirects=True)
                    data = resp.content if resp.status_code == 200 else None

                    # Attempt place-ID retry on 403 using pre-fetched creator metadata
                    if data is None and resp.status_code == 403 and meta:
                        cid = meta.get('creator_id')
                        ctype = meta.get('creator_type')
                        if cid is not None and ctype is not None:
                            try:
                                from ..proxy.addons.cache_scraper import (
                                    CREATOR_GAME_MAX_SCAN,
                                    CREATOR_GAME_PAGE_LIMITS,
                                    creator_game_base_paths,
                                )

                                seen_pids = set()
                                attempted_paths = set()
                                for limit in CREATOR_GAME_PAGE_LIMITS:
                                    found_before_limit = len(seen_pids)
                                    max_pages = max(1, (CREATOR_GAME_MAX_SCAN + limit - 1) // limit)
                                    for g_path in creator_game_base_paths(
                                        int(cid), int(ctype), limit
                                    ):
                                        if g_path in attempted_paths:
                                            continue
                                        attempted_paths.add(g_path)
                                        cursor = ''
                                        for _page in range(max_pages):
                                            path = g_path + (f'&cursor={cursor}' if cursor else '')
                                            g_r = sess.get(
                                                f'https://games.roblox.com{path}',
                                                headers={'Accept': 'application/json'},
                                                timeout=10,
                                            )
                                            if g_r.status_code != 200:
                                                break
                                            resp_json = g_r.json()
                                            games = resp_json.get('data', [])
                                            for game in games:
                                                rp = game.get('rootPlace')
                                                if rp and rp.get('id'):
                                                    pid = int(rp['id'])
                                                    if pid in seen_pids:
                                                        continue
                                                    seen_pids.add(pid)
                                                    retry_h = {
                                                        **dl_headers,
                                                        'Roblox-Place-Id': str(pid),
                                                    }
                                                    r2 = sess.get(
                                                        api_url,
                                                        headers=retry_h,
                                                        timeout=15,
                                                        allow_redirects=True,
                                                    )
                                                    if r2.status_code == 200 and r2.content:
                                                        data = r2.content
                                                        log_buffer.log(
                                                            'Scraper',
                                                            f'[Load Asset] Place-ID bypass succeeded for {aid_str}',
                                                        )
                                                        break  # Found working place ID
                                            if data:
                                                break
                                            cursor = resp_json.get('nextPageCursor') or ''
                                            if not cursor:
                                                break
                                        if data:
                                            break
                                    if data or len(seen_pids) > found_before_limit:
                                        break
                            except Exception:
                                pass

                if data:
                    self.cache_manager.store_asset(
                        aid_str,
                        asset_type,
                        data,
                        url=f'https://assetdelivery.roblox.com/v1/asset/?id={aid_str}',
                    )
                    log_buffer.log('Scraper', f'[Load Asset] Stored asset {aid_str} ({asset_name})')
                    return aid_str, True
                else:
                    log_buffer.log('Scraper', f'[Load Asset] No data returned for asset {aid_str}')
                    return aid_str, False

            except Exception as e:
                log_buffer.log('Scraper', f'[Load Asset] Failed to download asset {aid_str}: {e}')
                return aid_str, False

        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = {pool.submit(_download_one, aid_str): aid_str for aid_str in str_ids}

            for future in as_completed(futures):
                if self._stop_requested:
                    pool.shutdown(wait=False, cancel_futures=True)
                    break

                aid_str, success = future.result()
                if success:
                    loaded_count += 1
                    meta = asset_metadata.get(aid_str)
                    asset_name = meta['name'] if meta else 'Unknown'
                    self.asset_loaded.emit(aid_str, asset_name, meta['type'] if meta else 1)
                else:
                    failed_count += 1

                with _progress_lock:
                    _progress_count[0] += 1
                    done = _progress_count[0]
                self.progress.emit(done, total)
                self.status_message.emit(f'Downloaded {done}/{total} assets')

        # Re-stamp cached_at timestamps to preserve the user's original input order.
        # Parallel downloads finish in arbitrary order, so the auto-generated timestamps
        # from store_asset() don't reflect the intended sequence.
        # We assign monotonically increasing timestamps (1ms apart) so that:
        #   first ID in list  → earliest timestamp → bottom of descending sort
        #   last ID in list   → latest timestamp   → top of descending sort
        from datetime import datetime, timedelta

        base_time = datetime.now()
        with self.cache_manager._lock:
            for order_idx, aid_str in enumerate(str_ids):
                meta = asset_metadata.get(aid_str)
                asset_type = meta['type'] if meta else 1
                asset_key = f'{asset_type}_{aid_str}'
                entry = self.cache_manager.index['assets'].get(asset_key)
                if entry is not None:
                    # Offset: first ID gets base_time, last ID gets base_time + N ms
                    entry['cached_at'] = (base_time + timedelta(milliseconds=order_idx)).isoformat()
            self.cache_manager._schedule_index_commit()

        # Store resolved metadata so the name resolver picks it up
        self._resolved_metadata = asset_metadata
        self._resolved_creator_names = creator_names

        log_buffer.log(
            'Scraper',
            f'[Load Asset] Complete: {loaded_count} loaded, {failed_count} failed',
        )
        self.finished_loading.emit(loaded_count, failed_count)


class CategoryFilterPopup(QMenu):
    filters_changed = pyqtSignal(set)

    def __init__(self, parent=None, active_filters=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QMenu { background-color: palette(window); border: 1px solid palette(mid); border-radius: 4px; color: palette(window-text); }
            QWidget#FilterContainer { background-color: palette(window); }
            QCheckBox { padding: 1px; color: palette(window-text); font-size: 12px; }
            QCheckBox::indicator { width: 14px; height: 14px; }
        """)

        self.active_filters = set(active_filters) if active_filters else set()
        self._updating = False

        self.container = QWidget()
        self.container.setObjectName('FilterContainer')
        layout = QVBoxLayout(self.container)
        layout.setContentsMargins(10, 10, 10, 10)

        grid = QGridLayout()
        grid.setHorizontalSpacing(4)
        grid.setVerticalSpacing(4)

        self.categories = {
            '3D Models': [4, 10, 39, 40, 32, 17, 79, 75],
            'Images/Textures': [1, 13, 63, 21, 22, 18],
            'Audio/Video': [3, 62, 33],
            'Animations': [
                24,
                ('R6Animation', 'R6 Animation'),
                ('R15Animation', 'R15 Animation'),
                ('NonPlayerAnimation', 'Non-player Animation'),
                48,
                49,
                50,
                51,
                52,
                53,
                54,
                55,
                56,
                61,
                78,
            ],
            'Avatar Parts': [16, 25, 26, 27, 28, 29, 30, 31],
            'Clothing': [2, 11, 12, 8, 19],
            'Accessories': [
                41,
                42,
                43,
                44,
                45,
                46,
                47,
                57,
                58,
                64,
                65,
                66,
                67,
                68,
                69,
                70,
                71,
                72,
                76,
                77,
            ],
            'Scripts/Data': [5, 6, 7, 37, 38, 80, 59, 74, 73, 35, 34, 9, 'Json'],
        }

        self.checkboxes = {}
        self.category_checkboxes = {}

        col = 0
        row = 0
        from PyQt6.QtGui import QFontMetrics

        fm = QFontMetrics(self.font())

        for cat_name, type_ids in self.categories.items():
            cat_frame = QFrame()
            cat_frame.setObjectName('CategoryCard')
            cat_frame.setStyleSheet("""
                QFrame#CategoryCard {
                    border: 1px solid palette(mid);
                    border-radius: 6px;
                    background-color: palette(base);
                }
            """)
            vbox = QVBoxLayout(cat_frame)
            vbox.setContentsMargins(6, 6, 6, 6)
            vbox.setSpacing(3)

            cat_cb = QCheckBox(cat_name)
            cat_cb.setStyleSheet('font-weight: bold; color: #55aaff;')
            cat_cb.setTristate(True)
            self.category_checkboxes[cat_name] = cat_cb
            vbox.addWidget(cat_cb)

            line = QFrame()
            line.setFrameShape(QFrame.Shape.HLine)
            line.setFrameShadow(QFrame.Shadow.Sunken)
            line.setStyleSheet(
                'background-color: palette(mid); margin-bottom: 2px; margin-top: 2px;'
            )
            vbox.addWidget(line)

            cat_types = []
            for tid in type_ids:
                if isinstance(tid, tuple):
                    # (key, display_name) pair - key is stored in filters, name is shown in UI
                    tid, name = tid
                elif isinstance(tid, str):
                    # String detected-type entry (e.g. 'Json')
                    name = tid
                elif tid in CacheManager.ASSET_TYPES:
                    name = CacheManager.ASSET_TYPES[tid]
                else:
                    continue

                # Keep labels compact so the popup cannot balloon across the screen.
                max_w = 130

                elided = fm.elidedText(name, Qt.TextElideMode.ElideRight, max_w)
                cb = QCheckBox(elided)
                if elided != name:
                    cb.setToolTip(name)
                cb.setChecked(tid in self.active_filters)
                self.checkboxes[tid] = cb
                vbox.addWidget(cb)
                cat_types.append(tid)

            cat_cb.clicked.connect(
                lambda checked, t=cat_types, c=cat_name: self._on_category_clicked(t, c)
            )
            for tid in cat_types:
                cb = self.checkboxes[tid]
                cb.clicked.connect(
                    lambda checked, t=tid, c=cat_name: self._on_type_clicked(t, c, checked)
                )

            self._update_category_state(cat_name)
            vbox.addStretch()
            grid.addWidget(cat_frame, row, col)
            col += 1
            if col >= 4:
                col = 0
                row += 1

        layout.addLayout(grid)

        btn_layout = QHBoxLayout()
        clear_btn = QPushButton('Clear Filters')
        clear_btn.setStyleSheet(
            'padding: 5px 15px; border: 1px solid palette(mid); border-radius: 3px;'
        )
        clear_btn.clicked.connect(self._clear_all)
        btn_layout.addWidget(clear_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        self.scroll_area = QScrollArea()
        self.scroll_area.setObjectName('FilterScrollArea')
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll_area.setWidget(self.container)

        self._natural_content_size = self.container.sizeHint()
        self._set_popup_content_size(self._natural_content_size.height())

        action = QWidgetAction(self)
        action.setDefaultWidget(self.scroll_area)
        self.addAction(action)

    def _set_popup_content_size(self, max_height):
        natural = self._natural_content_size
        height = min(natural.height(), max(220, max_height))
        width = natural.width()
        if natural.height() > height:
            width += self.scroll_area.verticalScrollBar().sizeHint().width()
        self.scroll_area.setFixedSize(width, height)

    def constrain_to_available_geometry(self, available_geometry, anchor_y=None):
        """Bound the popup to the visible screen area and enable vertical scroll."""
        if available_geometry is None:
            return

        if anchor_y is None:
            available_height = available_geometry.height()
        else:
            space_below = available_geometry.bottom() - anchor_y
            space_above = anchor_y - available_geometry.top()
            available_height = max(space_below, space_above)

        self._set_popup_content_size(max(220, available_height - 12))
        self.adjustSize()

    def set_active_filters(self, active_filters):
        """Update the popup checks without rebuilding the widget."""
        self.active_filters = set(active_filters) if active_filters else set()
        self._updating = True
        for tid, cb in self.checkboxes.items():
            cb.blockSignals(True)
            cb.setChecked(tid in self.active_filters)
            cb.blockSignals(False)
        for cat_name in self.categories:
            self._update_category_state(cat_name)
        self._updating = False

    def mouseReleaseEvent(self, a0):
        # Prevent the menu from closing if the user clicks inside the container but not on a specific checkbox
        if a0 is None:
            return
        action = self.actionAt(a0.pos())
        if isinstance(action, QWidgetAction) and action.defaultWidget() == self.scroll_area:
            # We clicked inside the container area
            return
        super().mouseReleaseEvent(a0)

    def _on_category_clicked(self, type_ids, cat_name):
        if self._updating:
            return
        self._updating = True

        checked_count = sum(
            1 for tid in type_ids if tid in self.checkboxes and self.checkboxes[tid].isChecked()
        )
        total_count = sum(1 for tid in type_ids if tid in self.checkboxes)
        new_state = checked_count < total_count

        for tid in type_ids:
            if tid in self.checkboxes:
                cb = self.checkboxes[tid]
                cb.blockSignals(True)
                cb.setChecked(new_state)
                cb.blockSignals(False)
                if new_state:
                    self.active_filters.add(tid)
                else:
                    self.active_filters.discard(tid)

        self._update_category_state(cat_name)
        self._updating = False
        self.filters_changed.emit(self.active_filters)

    def _on_type_clicked(self, tid, cat_name, checked):
        if self._updating:
            return
        self._updating = True
        if checked:
            self.active_filters.add(tid)
        else:
            self.active_filters.discard(tid)

        self._update_category_state(cat_name)
        self._updating = False
        self.filters_changed.emit(self.active_filters)

    def _update_category_state(self, cat_name):
        cat_cb = self.category_checkboxes[cat_name]
        type_ids = self.categories[cat_name]
        checked_count = sum(
            1 for tid in type_ids if tid in self.checkboxes and self.checkboxes[tid].isChecked()
        )
        total_count = sum(1 for tid in type_ids if tid in self.checkboxes)

        cat_cb.blockSignals(True)
        if checked_count == 0:
            cat_cb.setCheckState(Qt.CheckState.Unchecked)
        elif checked_count == total_count and total_count > 0:
            cat_cb.setCheckState(Qt.CheckState.Checked)
        else:
            cat_cb.setCheckState(Qt.CheckState.PartiallyChecked)
        cat_cb.blockSignals(False)

    def _clear_all(self):
        if self._updating:
            return
        self._updating = True
        self.active_filters.clear()
        for cb in self.checkboxes.values():
            cb.blockSignals(True)
            cb.setChecked(False)
            cb.blockSignals(False)
        for cat_name in self.categories:
            self._update_category_state(cat_name)
        self._updating = False
        self.filters_changed.emit(self.active_filters)


# --- Column definitions used across the scraper tab ---
# Column 0 is always the ▼ toggle/counter — not user-configurable.
# Columns 1+ are the data columns the user can show/hide.
COL_TOGGLE_WIDTH = 14
SCRAPER_COLUMNS = [
    # (key, label, default_visible, default_width)
    ('hash_name', 'Hash/Name', True, 200),
    ('creator', 'Creator', False, 120),  # off by default
    ('asset_id', 'Asset ID', True, 100),
    ('type', 'Type', True, 120),
    ('size', 'Size', True, 70),
    ('cached_at', 'Cached At', True, 135),
    ('updated_at', 'Updated At', False, 180),
    ('created_at', 'Created At', False, 180),
    ('url', 'URL', False, 300),  # off by default
]
# Logical index → column key  (index 0 = toggle column, 1+ = data columns)
_COL_IDX_TO_KEY = ['_toggle'] + [c[0] for c in SCRAPER_COLUMNS]
# Column key → logical index
_COL_KEY_TO_IDX = {'_toggle': 0, **{c[0]: i + 1 for i, c in enumerate(SCRAPER_COLUMNS)}}

# Search column definitions for the column-picker button
_SEARCH_COLS = [
    # (key, label, default_active)
    ('id', 'Asset ID', True),
    ('type', 'Type', True),
    ('name', 'Name', True),
    ('creator', 'Creator', True),
    ('hash', 'Hash', True),
    ('cached_at', 'Cached At', True),
    ('updated_at', 'Updated At', False),
    ('created_at', 'Created At', False),
    ('url', 'URL', False),
]
_ALL_SEARCH_COL_KEYS = frozenset(k for k, *_ in _SEARCH_COLS)
_DEFAULT_SEARCH_COL_KEYS = frozenset(k for k, _label, default in _SEARCH_COLS if default)


class ColumnFilterPopup(QMenu):
    """Simple popup to pick which fields are included in the text search."""

    cols_changed = pyqtSignal(set)

    def __init__(self, parent=None, active_cols=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QMenu { background-color: palette(window); border: 1px solid palette(mid);
                    border-radius: 4px; color: palette(window-text); }
            QWidget#ColContainer { background-color: palette(window); }
            QCheckBox { padding: 2px 4px; color: palette(window-text); font-size: 12px; }
            QCheckBox::indicator { width: 14px; height: 14px; }
        """)
        self.active_cols = (
            set(active_cols) if active_cols is not None else set(_DEFAULT_SEARCH_COL_KEYS)
        )

        container = QWidget()
        container.setObjectName('ColContainer')
        vbox = QVBoxLayout(container)
        vbox.setContentsMargins(10, 10, 10, 10)
        vbox.setSpacing(4)

        self.checkboxes: dict = {}
        for key, label, _default in _SEARCH_COLS:
            cb = QCheckBox(label)
            cb.setChecked(key in self.active_cols)
            cb.stateChanged.connect(lambda state, k=key: self._on_toggle(k, bool(state)))
            self.checkboxes[key] = cb
            vbox.addWidget(cb)

        btn_row = QHBoxLayout()
        all_btn = QPushButton('All')
        all_btn.setFixedHeight(22)
        all_btn.clicked.connect(self._select_all)
        none_btn = QPushButton('None')
        none_btn.setFixedHeight(22)
        none_btn.clicked.connect(self._select_none)
        btn_row.addWidget(all_btn)
        btn_row.addWidget(none_btn)
        vbox.addLayout(btn_row)

        wa = QWidgetAction(self)
        wa.setDefaultWidget(container)
        self.addAction(wa)

    def _on_toggle(self, key: str, checked: bool):
        if checked:
            self.active_cols.add(key)
        else:
            self.active_cols.discard(key)
        self.cols_changed.emit(set(self.active_cols))

    def _select_all(self):
        self.active_cols = set(_ALL_SEARCH_COL_KEYS)
        for cb in self.checkboxes.values():
            cb.blockSignals(True)
            cb.setChecked(True)
            cb.blockSignals(False)
        self.cols_changed.emit(set(self.active_cols))

    def _select_none(self):
        self.active_cols.clear()
        for cb in self.checkboxes.values():
            cb.blockSignals(True)
            cb.setChecked(False)
            cb.blockSignals(False)
        self.cols_changed.emit(set(self.active_cols))


class ColumnVisibilityMenu(QMenu):
    """
    A non-closing QMenu that lets the user toggle which Scraper columns are
    visible.  Styled identically to the ObjViewer options menu (native Qt
    checkable actions).  The menu only closes when the user clicks outside it.
    """

    visibility_changed = pyqtSignal(dict)  # {col_key: bool}

    def __init__(self, column_visibility: dict, parent=None):
        super().__init__(parent)
        self._col_visibility = dict(column_visibility)
        self._actions: dict[str, QAction] = {}
        self._building = True

        for key, label, _default, _w in SCRAPER_COLUMNS:
            action = QAction(label, self)
            action.setCheckable(True)
            action.setChecked(self._col_visibility.get(key, True))
            action.toggled.connect(lambda checked, k=key: self._on_toggled(k, checked))
            self.addAction(action)
            self._actions[key] = action

        self._building = False

    # ------------------------------------------------------------------
    # Prevent the menu from closing when the user clicks a checkable item.
    # It will still close on Escape or clicking outside.
    # ------------------------------------------------------------------
    def mouseReleaseEvent(self, a0):
        if a0 is None:
            return
        if a0.button() != Qt.MouseButton.LeftButton:
            a0.ignore()
            return
        action = self.actionAt(a0.pos())
        if action and action.isCheckable():
            action.toggle()  # manually toggle without closing
            return
        super().mouseReleaseEvent(a0)

    def _on_toggled(self, key: str, checked: bool):
        if self._building:
            return

        self._col_visibility[key] = checked

        # Enforce: at least one column must remain visible
        any_visible = any(self._col_visibility.values())
        if not any_visible:
            # Revert this action and restore Hash/Name
            self._building = True
            self._col_visibility[key] = True
            self._actions[key].setChecked(True)
            self._col_visibility['hash_name'] = True
            self._actions['hash_name'].setChecked(True)
            self._building = False

        self.visibility_changed.emit(dict(self._col_visibility))

    def update_from(self, col_visibility: dict):
        """Sync action states from an external dict (e.g. after config load)."""
        self._building = True
        for key, action in self._actions.items():
            action.setChecked(col_visibility.get(key, True))
        self._col_visibility = dict(col_visibility)
        self._building = False


class CacheViewerTab(QWidget):
    """Tab for viewing and managing cached Roblox assets."""

    # Signal to request table sync from background threads (thread-safe)
    _sync_table_requested = pyqtSignal()

    def __init__(
        self,
        cache_manager: CacheManager,
        cache_scraper=None,
        parent=None,
        config_manager=None,
    ):
        super().__init__(parent)
        self.cache_manager = cache_manager
        self.cache_scraper = cache_scraper
        self.config_manager = config_manager
        self._active_filters = set()
        self._active_search_cols: set = self._load_search_cols()
        self._last_asset_count = 0  # Track for change detection
        self._selected_asset_id: str | None = None  # Track selected asset by ID
        self._show_names = config_manager.show_names if config_manager is not None else True
        self._show_creator_id = (
            config_manager.show_creator_id if config_manager is not None else False
        )
        self._asset_info: dict[str, dict] = {}  # asset_id -> resolved metadata, hash, row
        self._current_pixmap = None  # Store current image for resize

        # OPTIMIZATION: Cache asset_id -> row mapping for O(1) lookups instead of O(n) linear search
        # Updated whenever table structure changes (populate, sort). Validates on read for thread-safety.
        self._asset_row_cache: dict[str, int] = {}
        self._modified_rbxm_drafts: dict[tuple[str, object], dict] = {}
        self._rbxm_preview_asset_key: tuple[str, object] | None = None
        self._rbxm_preview_cached_at = ''

        # Worker threads for async preview loading
        self._image_loader: ImageLoaderThread | None = None
        self._mesh_loader: MeshLoaderThread | None = None
        self._animation_loader: AnimationLoaderThread | None = None
        self._texturepack_loader: TexturePackLoaderThread | None = None

        # Search worker thread
        self._search_worker: SearchWorkerThread | None = None
        self._pending_search_text: str = ''
        self._is_searching: bool = False

        # Delete worker thread
        self._delete_worker: DeleteWorkerThread | None = None

        # Asset loader worker thread
        self._asset_loader: AssetLoaderThread | None = None
        self._is_deleting: bool = False

        # Type correction is lazy: only rows near the viewport are probed.
        # Include the cache hash in each key so a replaced payload is checked
        # again even when its asset ID and type stay the same.
        self._type_probe_pending: dict[tuple[str, int, str], tuple[str, int, str]] = {}
        self._type_probe_inflight: set[tuple[str, int, str]] = set()
        self._type_probe_checked: set[tuple[str, int, str]] = set()
        self._type_probe_worker: TypeProbeWorker | None = None

        # Blacklisted asset IDs (excluded from table)
        if config_manager is not None:
            self._blacklisted_ids: set[str] = set(config_manager.scraper_blacklist)
            if self._blacklisted_ids:
                log_buffer.log(
                    'Scraper',
                    f'Loaded blacklist: {format_count(self._blacklisted_ids, "ID")} active — {", ".join(sorted(self._blacklisted_ids, key=lambda x: int(x) if x.isdigit() else 0))}',
                )
        else:
            self._blacklisted_ids: set[str] = set()

        # Texturepack data for context menu
        self._texturepack_data: dict = {}  # map_name -> {id, hash, data}
        self._texturepack_xml: str = ''  # Original XML
        # Track whether we've installed the global event filter for audio hotkeys
        self._audio_key_filter_installed = False

        # Column visibility – loaded from config, validated, then applied
        self._col_visibility: dict[str, bool] = self._load_col_visibility()
        # Column widths (pixels) – None means "use default"
        self._col_widths: dict[str, int | None] = self._load_col_widths()
        # Toggle column (col 0) width – start with legacy constant, will be recalculated
        self._col_toggle_width: int = COL_TOGGLE_WIDTH
        # Currently active sort column (logical index). Defaults to Cached At.
        self._sort_col_idx: int = _COL_KEY_TO_IDX['cached_at']
        self._sort_order = Qt.SortOrder.DescendingOrder
        # Guard against re-entrant sort-indicator resets when blocking col-0 sort
        self._in_sort_guard: bool = False
        # Reference to the shared non-closing visibility menu (created lazily)
        self._col_visibility_menu: ColumnVisibilityMenu | None = None
        # Guard: prevent re-entrant column resize saves during programmatic resizes
        self._resizing_cols: bool = False

        self._setup_ui()
        self.set_proxy_features_enabled(self._proxy_features_enabled())
        self._refresh_timer = QTimer()
        self._refresh_timer.timeout.connect(self._check_for_updates)
        self._refresh_timer.start(3000)  # Check every 3 seconds

        # Search debounce timer (longer delay to batch rapid keystrokes)
        self._search_debounce = QTimer()
        self._search_debounce.setSingleShot(True)
        self._search_debounce.timeout.connect(self._do_search)

        # Filter debounce timer
        self._filter_debounce = QTimer()
        self._filter_debounce.setSingleShot(True)
        self._filter_debounce.timeout.connect(self._refresh_assets)

        self._type_probe_debounce = QTimer()
        self._type_probe_debounce.setSingleShot(True)
        self._type_probe_debounce.timeout.connect(self._queue_visible_type_probes)

        # Load persisted resolved names from index
        self._load_persisted_names()

        # Connect the table sync signal (thread-safe way to update from background threads)
        self._sync_table_requested.connect(self._sync_visible_rows_with_asset_info)

        # Refresh to show persisted names
        QTimer.singleShot(0, self._refresh_assets)

        # Start name resolver daemon thread
        threading.Thread(target=self._name_resolver_loop, daemon=True).start()

    def closeEvent(self, event):
        """Stop the lightweight type-probe worker before the tab is destroyed."""
        if hasattr(self, '_type_probe_debounce'):
            self._type_probe_debounce.stop()
        worker = getattr(self, '_type_probe_worker', None)
        if worker is not None:
            worker.stop()
            worker.wait()
            self._type_probe_worker = None
        super().closeEvent(event)

    # ------------------------------------------------------------------
    # Column visibility / width helpers
    # ------------------------------------------------------------------

    def _default_col_visibility(self) -> dict[str, bool]:
        return {key: default_vis for key, _label, default_vis, _w in SCRAPER_COLUMNS}

    def _load_col_visibility(self) -> dict[str, bool]:
        """Load column visibility from config. Fall back to defaults, validate."""
        defaults = self._default_col_visibility()
        if self.config_manager is None:
            return defaults
        saved = self.config_manager.settings.get('scraper_column_visibility', {})
        merged = {**defaults, **{k: bool(v) for k, v in saved.items() if k in defaults}}
        # Validate: at least one visible
        if not any(merged.values()):
            # All off – fall back to Hash/Name only (per spec)
            merged = {key: False for key, *_ in SCRAPER_COLUMNS}
            merged['hash_name'] = True

        return merged

    def _load_col_widths(self) -> dict[str, int | None]:
        """Load saved column widths from config."""
        defaults: dict[str, int | None] = {key: None for key, *_ in SCRAPER_COLUMNS}
        if self.config_manager is None:
            return defaults
        saved = self.config_manager.settings.get('scraper_column_widths', {})
        merged = {}
        for key, _label, _vis, default_w in SCRAPER_COLUMNS:
            w = saved.get(key)
            merged[key] = int(w) if isinstance(w, (int, float)) and w > 0 else None
        return merged

    def _recalc_toggle_width(self, total_rows: int | None = None):
        """Recalculate and apply the minimal width for column 0 so numeric
        row counters never get truncated. Uses the table font metrics and
        applies a small padding for spacing.
        """
        try:
            if total_rows is None:
                total_rows = self.table.rowCount()
            # At least show '1' width if empty to leave room for header arrow
            total_rows = max(1, int(total_rows))
            fm = self.table.fontMetrics()
            largest_text = str(total_rows)
            text_w = fm.horizontalAdvance(largest_text)
            arrow_w = fm.horizontalAdvance('▼')
            padding = 10 if sys.platform == 'darwin' else 7
            w = max(COL_TOGGLE_WIDTH, text_w + padding, arrow_w + padding)
            self._col_toggle_width = int(w)
            header = self.table.horizontalHeader()
            header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(0, self._col_toggle_width)
        except Exception:
            # Fall back silently to the legacy constant on any error
            self._col_toggle_width = COL_TOGGLE_WIDTH
            try:
                self.table.setColumnWidth(0, COL_TOGGLE_WIDTH)
            except Exception:
                pass

    def _renumber_counters(self):
        """Renumber the left-most counter column so it shows 1..N in the
        current visible order. This should be called after any sort or
        when the visible ordering changes.
        """
        try:
            # Block signals to avoid spurious selection/changed events
            self.table.blockSignals(True)
            row_count = self.table.rowCount()
            for r in range(row_count):
                old = self.table.item(r, 0)
                flags = old.flags() if old is not None else Qt.ItemFlag.ItemIsEnabled
                align = old.textAlignment() if old is not None else Qt.AlignmentFlag.AlignCenter
                new = NumericSortItem(r, str(r + 1))
                new.setFlags(flags)
                new.setTextAlignment(align)
                self.table.setItem(r, 0, new)
        except Exception:
            pass
        finally:
            self.table.blockSignals(False)

        # OPTIMIZATION: Update row cache after sort completes so next sync uses fresh positions
        self._update_asset_row_cache()

    def _save_col_settings(self):
        """Persist column visibility and widths to config."""
        if self.config_manager is None:
            return
        self.config_manager.settings['scraper_column_visibility'] = dict(self._col_visibility)
        self.config_manager.settings['scraper_column_widths'] = dict(self._col_widths)
        self.config_manager.save()

    def _apply_column_visibility(self, initial: bool = False):
        """Show/hide table data columns and update resize modes.

        Column 0 (▼ toggle/counter) is always visible and Fixed — never touched here.
        The last *visible* data column (index ≥ 1) gets Stretch so it fills the
        remaining table width with no seam on its right edge.  Every other visible
        data column is Interactive so the user can drag its seam.

        If the currently active sort column is hidden, reset the sort to
        'Cached At'.
        """
        header = self.table.horizontalHeader()

        # Find which data column will be last visible.
        last_visible_idx = -1
        for i, (key, *_) in enumerate(SCRAPER_COLUMNS, start=1):
            if self._col_visibility.get(key, True):
                last_visible_idx = i

        for i, (key, *_) in enumerate(SCRAPER_COLUMNS, start=1):
            visible = self._col_visibility.get(key, True)
            header.setSectionHidden(i, not visible)
            if visible:
                if i == last_visible_idx:
                    header.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
                else:
                    header.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)

        # If sort column just became hidden, reset to Cached At.
        sort_key = (
            _COL_IDX_TO_KEY[self._sort_col_idx]
            if self._sort_col_idx < len(_COL_IDX_TO_KEY)
            else None
        )
        if sort_key and sort_key != '_toggle' and not self._col_visibility.get(sort_key, True):
            self._sort_col_idx = _COL_KEY_TO_IDX['cached_at']
            self._sort_order = Qt.SortOrder.DescendingOrder
            self.table.sortByColumn(self._sort_col_idx, Qt.SortOrder.DescendingOrder)

        if not initial:
            self._save_col_settings()
            QTimer.singleShot(0, self._auto_snap_splitter)

    # ------------------------------------------------------------------
    # Column-visibility menu helpers
    # ------------------------------------------------------------------

    def _get_or_create_col_menu(self) -> 'ColumnVisibilityMenu':
        """Return (and lazily create) the shared ColumnVisibilityMenu."""
        if self._col_visibility_menu is None:
            self._col_visibility_menu = ColumnVisibilityMenu(self._col_visibility, self)
            self._col_visibility_menu.visibility_changed.connect(self._on_col_visibility_changed)
        else:
            # Keep it in sync with any external changes
            self._col_visibility_menu.update_from(self._col_visibility)
        return self._col_visibility_menu

    def _on_header_section_clicked(self, logical_index: int):
        """Open the visibility menu when the ▼ column (index 0) is clicked."""
        if logical_index == 0:
            menu = self._get_or_create_col_menu()
            # Position below the ▼ header section
            header = self.table.horizontalHeader()
            x = header.sectionPosition(0)
            pos = header.mapToGlobal(header.rect().bottomLeft())
            pos.setX(pos.x() + x)
            menu.exec(pos)

    def _show_col_visibility_from_header(self, pos):
        """Right-click on any header section: open menu at cursor."""
        menu = self._get_or_create_col_menu()
        menu.exec(QCursor.pos())

    def _on_col_visibility_changed(self, new_visibility: dict):
        """Called when the user toggles a column in the visibility menu."""
        self._col_visibility = new_visibility
        self._apply_column_visibility()

    # ------------------------------------------------------------------
    # Column resize tracking
    # ------------------------------------------------------------------

    def _on_sort_indicator_changed(self, logical_index: int, order):
        """Block sort on col 0 (▼ toggle); track sort column for all others."""
        if self._in_sort_guard:
            return
        if logical_index == 0:
            # Column 0 is the toggle — restore the previous sort immediately
            self._in_sort_guard = True
            self.table.sortByColumn(self._sort_col_idx, self._sort_order)
            self._in_sort_guard = False
            return
        self._sort_col_idx = logical_index
        self._sort_order = order
        # After the internal Qt sort completes (this signal fires before
        # Qt performs the actual sort), renumber the left-most counter
        # column so it always shows 1..N in the current visible order.
        QTimer.singleShot(0, self._renumber_counters)
        QTimer.singleShot(0, self._schedule_visible_type_probes)

    def _on_column_resized(self, logical_index: int, _old_size: int, new_size: int):
        """Save user-dragged column widths to config."""
        if self._resizing_cols:
            return
        # Col 0 is Fixed, last visible is Stretch — neither should be persisted
        if logical_index == 0:
            return
        header = self.table.horizontalHeader()
        if header.sectionResizeMode(logical_index) == QHeaderView.ResizeMode.Stretch:
            return
        key = _COL_IDX_TO_KEY[logical_index]
        self._col_widths[key] = new_size
        self._save_col_settings()
        QTimer.singleShot(0, self._auto_snap_splitter)

    # ------------------------------------------------------------------
    # Splitter auto-snap
    # ------------------------------------------------------------------

    def _auto_snap_splitter(self):
        """Resize the splitter so the preview gets as much space as possible.

        Column 0 is a Fixed-width toggle column (COL_TOGGLE_WIDTH).
        The vertical header is hidden — its counter role is filled by col 0.
        The last visible data column is always Stretch; we use only its header
        label minimum width when computing table_min so that an over-wide
        user session doesn't prevent the preview from opening at the right size.
        """
        if self.preview_panel.isHidden():
            return

        total = self.splitter.width()
        if total <= 0:
            return

        header = self.table.horizontalHeader()

        # Find last visible data column (Stretch mode)
        last_visible_idx = -1
        for i in range(len(SCRAPER_COLUMNS), 0, -1):
            if not header.isSectionHidden(i):
                last_visible_idx = i
                break

        # Col 0: fixed toggle/counter width (always visible)
        col_w = self._col_toggle_width

        for i in range(1, len(SCRAPER_COLUMNS) + 1):
            if header.isSectionHidden(i):
                continue
            if i == last_visible_idx:
                key = SCRAPER_COLUMNS[i - 1][0]
                if key == 'url':
                    fm = header.fontMetrics()
                    label = SCRAPER_COLUMNS[i - 1][1]
                    col_w += fm.horizontalAdvance(label) + 24
                else:
                    col_w += self.table.sizeHintForColumn(i) + 20
            else:
                col_w += self.table.columnWidth(i)

        sb_margin = self.table.verticalScrollBar().sizeHint().width() + 4
        table_min = col_w + sb_margin
        splitter_handle = self.splitter.handleWidth()

        if table_min + splitter_handle < total:
            self.splitter.setSizes([table_min, total - table_min - splitter_handle])
        else:
            table_w = max(int(total * 0.6), table_min)
            preview_w = max(total - table_w - splitter_handle, 50)
            self.splitter.setSizes([table_w, preview_w])

    # ------------------------------------------------------------------
    # resizeEvent – update splitter continuously as main window resizes
    # ------------------------------------------------------------------

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # Snap splitter in real-time if preview is open
        if not self.preview_panel.isHidden():
            self._auto_snap_splitter()

    def changeEvent(self, event):
        super().changeEvent(event)
        if event.type() == QEvent.Type.PaletteChange:
            self._update_table_alt_palette()

    def _update_table_alt_palette(self):
        """Apply a slightly darker alternate-row colour in dark mode, or reset in light/system mode."""
        pal = self.palette()
        is_dark = pal.color(QPalette.ColorRole.Window).lightness() < 128
        if is_dark:
            table_pal = self.table.palette()
            table_pal.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
            self.table.setPalette(table_pal)
        else:
            self.table.setPalette(QPalette())  # inherit from application

    def _sanitize_filename(self, name: str) -> str:
        """Replace characters that are illegal in Windows filenames with Unicode look‑alikes."""
        char_map = {
            '/': '∕',  # U+2215  (division slash)
            '\\': '⧵',  # U+29F5  (reverse solidus operator)
            ':': '꞉',  # U+A789  (modifier letter colon)
            '*': '∗',  # U+2217  (asterisk operator)
            '?': '？',  # U+FF1F  (fullwidth question mark)
            '"': '＂',  # U+FF02  (fullwidth quotation mark)
            '<': '＜',  # U+FF1C  (fullwidth less‑than sign)
            '>': '＞',  # U+FF1E  (fullwidth greater‑than sign)
            '|': '｜',  # U+FF5C  (fullwidth vertical line)
        }
        return ''.join(char_map.get(c, c) for c in name)

    def _setup_ui(self):
        """Setup the UI."""
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        # Filters (includes scraper toggle and stats)
        self._create_filters(layout)

        # Splitter for table and preview
        self.splitter = QSplitter(Qt.Orientation.Horizontal)

        # Left side: Asset table
        table_widget = QWidget()
        table_layout = QVBoxLayout()
        table_layout.setContentsMargins(0, 0, 0, 0)
        self._create_table(table_layout)
        table_widget.setLayout(table_layout)
        self.splitter.addWidget(table_widget)

        # Right side: Preview panel
        self.preview_panel = self._create_preview_panel()
        self.splitter.addWidget(self.preview_panel)

        # Set splitter sizes (table gets more space initially)
        self.splitter.setSizes([600, 300])

        # Initially hide the preview panel (as requested: hide if no asset selected)
        self.preview_panel.setHidden(True)

        # Connect splitter moved to rescale image
        self.splitter.splitterMoved.connect(self._on_splitter_moved)

        layout.addWidget(self.splitter, stretch=1)

        # Actions
        self._create_actions(layout)

        self.setLayout(layout)
        # Don't refresh here - wait for the queued refresh after persisted names are loaded
        # self._refresh_assets()

    def _create_filters(self, parent_layout):
        """Create filter controls."""
        filter_group = QGroupBox('Filters')
        filter_group.setStyleSheet('QGroupBox::title { padding-left: 5px; }')
        filter_layout = QHBoxLayout()

        # Search box first
        filter_layout.addWidget(QLabel('Search:'))
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText('Search columns')
        self.search_box.textChanged.connect(self._on_search_text_changed)
        filter_layout.addWidget(self.search_box)

        # Type selector second
        self.filter_btn = QPushButton('Type: All Types')
        self.filter_btn.clicked.connect(self._show_filter_popup)
        filter_layout.addWidget(self.filter_btn)

        # Search columns picker
        self.search_col_btn = QPushButton('Search columns: All')
        self.search_col_btn.clicked.connect(self._show_search_col_popup)
        self._update_search_col_btn()
        filter_layout.addWidget(self.search_col_btn)

        filter_layout.addStretch()

        sep1 = QLabel('|')
        sep1.setStyleSheet('padding-bottom: 6px;')
        filter_layout.addWidget(sep1)

        # Cache scraper toggle - reflect actual scraper state
        self.scraper_toggle = QCheckBox('Enable Cache Scraper')
        scraper_enabled = self.cache_scraper.enabled if self.cache_scraper else False
        self.scraper_toggle.setChecked(scraper_enabled)
        self.scraper_toggle.stateChanged.connect(self._toggle_scraper)
        filter_layout.addWidget(self.scraper_toggle)

        sep2 = QLabel('|')
        sep2.setStyleSheet('padding-bottom: 6px;')
        filter_layout.addWidget(sep2)

        # Stats labels
        self.stats_total_label = QLabel('Total: 0 assets')
        filter_layout.addWidget(self.stats_total_label)

        sep3 = QLabel('|')
        sep3.setStyleSheet('padding-bottom: 6px;')
        filter_layout.addWidget(sep3)

        self.stats_size_label = QLabel('Size: 0 B')
        filter_layout.addWidget(self.stats_size_label)

        filter_group.setLayout(filter_layout)
        parent_layout.addWidget(filter_group)

    def _show_filter_popup(self):
        self.popup = CategoryFilterPopup(self, self._active_filters)
        self.popup.filters_changed.connect(self._on_filters_changed)

        # Position the popup relative to the filter button, keeping it on the
        # same monitor.  The critical rule: NEVER pass a coordinate that is
        # outside the button's screen geometry to QMenu.exec() — Qt interprets
        # an off-screen position as "find nearest available space", which may
        # jump to a completely different monitor.
        #
        # Strategy:
        #   1. Get the screen the button lives on.
        #   2. Force-size the popup so sizeHint() is accurate.
        #   3. Prefer below the button; flip above if it overflows bottom.
        #   4. Clamp X so the right edge stays within the screen.
        #   5. If neither above nor below fits, pin to bottom of screen on same monitor.
        from PyQt6.QtCore import QPoint
        from PyQt6.QtGui import QScreen

        # Force layout so sizeHint reflects real dimensions
        self.popup.adjustSize()

        btn_rect = self.filter_btn.rect()
        btn_bottom = self.filter_btn.mapToGlobal(btn_rect.bottomLeft())
        btn_top = self.filter_btn.mapToGlobal(btn_rect.topLeft())

        screen: QScreen | None = self.filter_btn.screen()
        if screen is None:
            app = QApplication.instance()
            if app:
                screen = app.screenAt(btn_bottom)

        if screen is None:
            # No screen info — just show below and trust Qt
            self.popup.exec(btn_bottom)
            return

        sg = screen.availableGeometry()
        self.popup.constrain_to_available_geometry(sg, btn_bottom.y())
        ph = self.popup.sizeHint().height()
        pw = self.popup.sizeHint().width()

        # X: left-align with button, clamp so right edge stays on screen
        x = btn_bottom.x()
        if x + pw > sg.right():
            x = sg.right() - pw
        x = max(x, sg.left())

        # Y: below preferred; flip above if it overflows the bottom of this screen
        if btn_bottom.y() + ph <= sg.bottom():
            y = btn_bottom.y()
        elif btn_top.y() - ph >= sg.top():
            y = btn_top.y() - ph
        else:
            # Neither fits fully — pin to screen bottom so popup is on correct monitor
            y = sg.bottom() - ph
            y = max(y, sg.top())

        self.popup.exec(QPoint(x, y))

    def _on_filters_changed(self, filters):
        self._active_filters = set(filters)
        count = len(self._active_filters)
        if count == 0:
            self.filter_btn.setText('Type: All Types')
        elif count == 1:
            tid = next(iter(self._active_filters))
            name = tid if isinstance(tid, str) else CacheManager.ASSET_TYPES.get(tid, str(tid))
            self.filter_btn.setText(f'Type: {name}')
        else:
            self.filter_btn.setText(f'{count} Filters...')

        self._filter_debounce.start(300)

    # Search columns picker

    def _load_search_cols(self) -> set:
        if self.config_manager is None:
            return set(_DEFAULT_SEARCH_COL_KEYS)
        saved = self.config_manager.settings.get('scraper_search_columns', None)
        if saved is None:
            return set(_DEFAULT_SEARCH_COL_KEYS)
        valid = {k for k in saved if k in _ALL_SEARCH_COL_KEYS}
        return valid if valid else set(_DEFAULT_SEARCH_COL_KEYS)

    def _save_search_cols(self):
        if self.config_manager is None:
            return
        self.config_manager.settings['scraper_search_columns'] = sorted(self._active_search_cols)
        self.config_manager.save()

    def _update_search_col_btn(self):
        cols = self._active_search_cols
        if cols >= _ALL_SEARCH_COL_KEYS:
            self.search_col_btn.setText('Search columns: All')
        elif not cols:
            self.search_col_btn.setText('Search columns: None')
        elif len(cols) == 1:
            key = next(iter(cols))
            label = next((l for k, l, _default in _SEARCH_COLS if k == key), key)
            self.search_col_btn.setText(f'Search columns: {label}')
        else:
            self.search_col_btn.setText(f'Search columns: {len(cols)} selected')

    def _show_search_col_popup(self):
        from PyQt6.QtCore import QPoint
        from PyQt6.QtGui import QScreen

        self._col_popup = ColumnFilterPopup(self, self._active_search_cols)
        self._col_popup.cols_changed.connect(self._on_search_cols_changed)

        self._col_popup.adjustSize()
        btn = self.search_col_btn
        btn_rect = btn.rect()
        btn_bottom = btn.mapToGlobal(btn_rect.bottomLeft())
        btn_top = btn.mapToGlobal(btn_rect.topLeft())

        screen: QScreen | None = btn.screen()
        if screen is None:
            self._col_popup.exec(btn_bottom)
            return

        sg = screen.availableGeometry()
        ph = self._col_popup.sizeHint().height()
        pw = self._col_popup.sizeHint().width()

        x = btn_bottom.x()
        if x + pw > sg.right():
            x = sg.right() - pw
        x = max(x, sg.left())

        if btn_bottom.y() + ph <= sg.bottom():
            y = btn_bottom.y()
        elif btn_top.y() - ph >= sg.top():
            y = btn_top.y() - ph
        else:
            y = max(sg.bottom() - ph, sg.top())

        self._col_popup.exec(QPoint(x, y))

    def _on_search_cols_changed(self, cols: set):
        self._active_search_cols = cols
        self._update_search_col_btn()
        self._save_search_cols()
        self._search_debounce.start(300)

    def _create_table(self, parent_layout):
        """Create asset table."""
        self.table = QTableWidget()
        self.table.setColumnCount(len(_COL_IDX_TO_KEY))
        self.table.setHorizontalHeaderLabels(
            ['▼'] + [label for _key, label, _vis, _width in SCRAPER_COLUMNS]
        )

        header = self.table.horizontalHeader()

        # Column 0: ▼ toggle — Fixed width, never sorted, never resized by user
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        # Use dynamic width based on number of rows so the numeric counter never
        # gets truncated. The actual width will be recalculated when rows are
        # populated via `_recalc_toggle_width`.
        self.table.setColumnWidth(0, self._col_toggle_width)

        # Apply saved (or default) widths for data columns (1-6)
        self._resizing_cols = True
        for i, (key, _label, _vis, default_w) in enumerate(SCRAPER_COLUMNS, start=1):
            w = self._col_widths.get(key) or default_w
            self.table.setColumnWidth(i, w)
        self._resizing_cols = False

        # Apply visibility + resize modes for data columns (last visible → Stretch)
        self._apply_column_visibility(initial=True)

        # Hide the native row-number vertical header — col 0 now shows the counter
        self.table.verticalHeader().hide()

        # ── Intercept clicks on col 0 to open the visibility menu ──────────
        # sortIndicatorChanged fires before Qt's internal sort call, so we can
        # restore the previous sort inside the guard without a visible flicker.
        header.sortIndicatorChanged.connect(self._on_sort_indicator_changed)
        # sectionClicked: open the menu when col 0 is clicked
        header.sectionClicked.connect(self._on_header_section_clicked)

        # Right-click on any header section also opens the visibility menu
        header.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        header.customContextMenuRequested.connect(self._show_col_visibility_from_header)

        # Save column widths when the user drags a seam
        header.sectionResized.connect(self._on_column_resized)

        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        # Apply a slightly darker alternating-row colour in dark mode; this is
        # managed by _update_table_alt_palette() and kept in sync via changeEvent.
        self._update_table_alt_palette()
        self.table.currentItemChanged.connect(self._on_selection_changed)
        self.table.verticalScrollBar().valueChanged.connect(self._schedule_visible_type_probes)
        # Prevent column 0 (counter) from ever becoming the current item.
        # If Qt lands on column 0 (e.g. during keyboard nav), silently redirect
        # focus to column 1 of the same row so there is only one selection anchor.
        self.table.currentCellChanged.connect(self._redirect_counter_focus)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._show_context_menu)

        parent_layout.addWidget(self.table)

    def _create_preview_panel(self):
        """Create preview panel for viewing assets."""
        preview_widget = QWidget()
        preview_layout = QVBoxLayout()
        preview_layout.setContentsMargins(0, 0, 0, 0)

        self.preview_group = QWidget()
        preview_group_layout = QVBoxLayout()
        preview_group_layout.setContentsMargins(0, 0, 0, 0)
        preview_group_layout.setSpacing(4)

        self.preview_title_label = QLabel('Preview')
        preview_group_layout.addWidget(self.preview_title_label)

        # Scrollable container for all preview content
        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(True)
        self.preview_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.preview_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        # Container widget inside scroll area
        self.preview_container = QWidget()
        self.preview_container_layout = QVBoxLayout()
        self.preview_container_layout.setContentsMargins(5, 5, 5, 5)

        # 3D Viewer for meshes
        self.obj_viewer = ObjViewerPanel(config_manager=self.config_manager)
        self.obj_viewer.clear_requested.connect(self._clear_preview)
        self.preview_container_layout.addWidget(self.obj_viewer)

        # Loading indicator
        self.loading_label = QLabel('Loading...')
        self.loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_label.setStyleSheet(
            'QLabel { background-color: palette(base); color: #888; font-size: 14px; padding: 20px; }'
        )
        self.preview_container_layout.addWidget(self.loading_label)
        self.loading_label.hide()

        # Image viewer (will show/hide as needed)
        self.image_label = QLabel('Select an asset to preview')
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet('QLabel { background-color: palette(base); color: #888; }')
        self.image_label.setScaledContents(False)
        self.image_label.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.image_label.customContextMenuRequested.connect(self._show_image_context_menu)
        self.preview_container_layout.addWidget(self.image_label)

        # Audio player container with centering wrapper
        self.audio_player = None  # Created dynamically when needed
        self.audio_wrapper = QWidget()
        audio_wrapper_layout = QVBoxLayout()
        audio_wrapper_layout.setContentsMargins(0, 0, 0, 0)
        audio_wrapper_layout.addStretch(1)
        self.audio_container = QWidget()
        self.audio_container_layout = QVBoxLayout()
        self.audio_container_layout.setContentsMargins(0, 0, 0, 0)
        self.audio_container.setLayout(self.audio_container_layout)
        audio_wrapper_layout.addWidget(self.audio_container)
        audio_wrapper_layout.addStretch(1)
        self.audio_wrapper.setLayout(audio_wrapper_layout)
        self.preview_container_layout.addWidget(self.audio_wrapper)

        # Animation viewer
        self.animation_viewer = AnimationViewerPanel(config_manager=self.config_manager)
        self.preview_container_layout.addWidget(self.animation_viewer)

        # Text viewer for other types
        self.text_viewer = QTextEdit()
        self.text_viewer.setReadOnly(True)
        self.text_viewer.setPlaceholderText('Select an asset to preview')
        self.preview_container_layout.addWidget(self.text_viewer)
        self._text_viewer_default_font = self.text_viewer.font()
        self._text_viewer_default_wrap = QTextEdit.LineWrapMode.WidgetWidth

        # JSON viewer for JSON files
        self.json_viewer = CacheJsonViewer()
        self.preview_container_layout.addWidget(self.json_viewer)

        # RBXM/RBXMX structure viewer for Roblox model files
        self.rbxm_viewer = RbxmPreviewWidget()
        self.preview_container_layout.addWidget(self.rbxm_viewer)

        # Font viewer for font files
        self.font_wrapper = QWidget()
        font_wrapper_layout = QVBoxLayout()
        font_wrapper_layout.setContentsMargins(0, 0, 0, 0)
        font_wrapper_layout.addStretch(1)
        self.font_container = QWidget()
        self.font_container_layout = QVBoxLayout()
        self.font_container_layout.setContentsMargins(0, 0, 0, 0)
        self.font_container.setLayout(self.font_container_layout)
        font_wrapper_layout.addWidget(self.font_container)
        font_wrapper_layout.addStretch(1)
        self.font_wrapper.setLayout(font_wrapper_layout)
        self.preview_container_layout.addWidget(self.font_wrapper)

        # Texture pack container (dynamically created)
        self.texturepack_widget = None

        # Set up scroll area
        self.preview_container.setLayout(self.preview_container_layout)
        self.preview_scroll.setWidget(self.preview_container)
        preview_group_layout.addWidget(self.preview_scroll)

        # Initially hide all preview widgets
        self.obj_viewer.hide()
        self.audio_wrapper.hide()
        self.animation_viewer.hide()
        self.text_viewer.hide()
        self.json_viewer.hide()
        self.rbxm_viewer.hide()

        self.preview_group.setLayout(preview_group_layout)
        preview_layout.addWidget(self.preview_group)

        preview_widget.setLayout(preview_layout)
        return preview_widget

    def _create_actions(self, parent_layout):
        """Create action buttons."""
        actions_layout = QHBoxLayout()
        actions_layout.setContentsMargins(8, 4, 8, 4)

        delete_db_btn = QPushButton('Delete DB')
        delete_db_btn.clicked.connect(self._clear_cache)
        actions_layout.addWidget(delete_db_btn)

        delete_cache_btn = QPushButton('Clear Cache')
        delete_cache_btn.clicked.connect(self._delete_roblox_cache)
        actions_layout.addWidget(delete_cache_btn)

        self.stop_preview_btn = QPushButton('Stop Preview')
        self.stop_preview_btn.clicked.connect(self._stop_preview)
        self.stop_preview_btn.hide()
        actions_layout.addWidget(self.stop_preview_btn)

        self.rbxm_view_btn = QPushButton('Swap to RBXM View')
        self.rbxm_view_btn.clicked.connect(self._swap_to_rbxm_view)
        self.rbxm_view_btn.hide()
        actions_layout.addWidget(self.rbxm_view_btn)

        actions_layout.addStretch()

        blacklist_btn = QPushButton('Blacklist IDs...')
        blacklist_btn.clicked.connect(self._show_blacklist_dialog)
        actions_layout.addWidget(blacklist_btn)

        load_asset_btn = QPushButton('Load Asset...')
        load_asset_btn.clicked.connect(self._show_load_asset_dialog)
        actions_layout.addWidget(load_asset_btn)

        open_cache_btn = QPushButton('Open Cache Folder')
        open_cache_btn.clicked.connect(lambda: open_folder(self.cache_manager.cache_dir))
        actions_layout.addWidget(open_cache_btn)

        open_export_btn = QPushButton('Open Export Folder')
        open_export_btn.clicked.connect(lambda: open_folder(self.cache_manager.export_dir))
        actions_layout.addWidget(open_export_btn)

        parent_layout.addLayout(actions_layout)

    def _check_for_updates(self):
        """Check if cache has new assets and update stats only."""
        try:
            stats = self.cache_manager.get_cache_stats()
            total_assets = stats['total_assets']
            total_size = self._format_size(stats['total_size'])
            self.stats_total_label.setText(f'Total: {total_assets} assets')
            self.stats_size_label.setText(f'Size: {total_size}')

            # Only refresh table if asset count changed
            if total_assets != self._last_asset_count:
                self._last_asset_count = total_assets
                self._refresh_assets()
        except Exception:
            pass  # Ignore errors during background refresh

    def _refresh_assets(self):
        """Refresh the asset list using search worker for all searches."""
        # Stop any existing search
        if self._search_worker is not None:
            self._search_worker.stop()
            self._search_worker.quit()
            self._search_worker.wait()
            self._search_worker = None

        # Get search text
        search_text = self.search_box.text().strip()

        # Get filter type
        filter_types = self._active_filters

        # Get assets
        assets = self.cache_manager.list_assets(filter_types)

        # Apply blacklist filter
        if self._blacklisted_ids:
            assets = [a for a in assets if a['id'] not in self._blacklisted_ids]

        # Ensure all assets have _asset_info entries so the background name
        # resolver can discover and resolve them even when a search filter
        # hides them from the table.
        for a in assets:
            aid = a['id']
            if aid not in self._asset_info:
                self._asset_info[aid] = {
                    'hash': a.get('hash', ''),
                    'resolved_name': None,
                    'creator_id': None,
                    'creator_name': None,
                    'creator_type': None,
                    'created_at': a.get('resolved_created_at'),
                    'updated_at': a.get('resolved_updated_at'),
                    'row': None,
                }

        # For empty search, show all immediately
        if not search_text:
            self._populate_table(assets)
            return

        # Always use worker thread for searches to prevent UI freezing
        self._is_searching = True
        self._search_worker = SearchWorkerThread(
            assets, search_text, self._asset_info, self._active_search_cols
        )
        self._search_worker.results_ready.connect(self._on_search_complete)
        self._search_worker.finished.connect(self._on_search_finished)
        self._search_worker.start()

    def _populate_table(self, assets: list):
        """Populate the table with assets."""
        # ── Save scroll anchor ────────────────────────────────────────────
        # Capture the asset_id of the row at the top of the visible viewport
        # so we can scroll back to it after rebuilding the table.
        # This prevents the "user teleportation" bug where inserting new rows
        # resets or jumps the scroll position unexpectedly.
        _anchor_asset_id: str | None = None
        _vsb = self.table.verticalScrollBar()
        _saved_scroll = _vsb.value()
        _top_index = self.table.indexAt(self.table.viewport().rect().topLeft())
        if _top_index.isValid():
            _top_row = _top_index.row()
            _id_item = self.table.item(_top_row, 1)  # col 1 carries the asset dict in UserRole
            if _id_item is not None:
                _asset_data = _id_item.data(Qt.ItemDataRole.UserRole)
                if isinstance(_asset_data, dict):
                    _anchor_asset_id = _asset_data.get('id')

        # Disable updates while populating (major performance boost)
        self.table.blockSignals(True)
        self.table.setUpdatesEnabled(False)
        self.table.setSortingEnabled(False)

        # Track row to restore selection
        row_to_select: int | None = None

        try:
            # Clear old item memory in C++ before allocating new rows
            self.table.clearContents()
            self.table.setRowCount(0)

            # Update table
            self.table.setRowCount(len(assets))

            # Recalculate toggle column width to fit the largest row number
            # without truncation.
            self._recalc_toggle_width(len(assets))

            for row, asset in enumerate(assets):
                asset_id = asset['id']
                hash_val = asset.get('hash', '')

                # Track if this is the previously selected asset
                if self._selected_asset_id and asset_id == self._selected_asset_id:
                    row_to_select = row

                # Initialize or update asset info tracking
                if asset_id not in self._asset_info:
                    self._asset_info[asset_id] = {
                        'hash': hash_val,
                        'resolved_name': None,
                        'creator_id': None,
                        'creator_name': None,
                        'creator_type': None,
                        'created_at': asset.get('resolved_created_at'),
                        'updated_at': asset.get('resolved_updated_at'),
                        'row': row,
                    }
                else:
                    self._asset_info[asset_id]['row'] = row
                    if (
                        self._asset_info[asset_id].get('created_at') is None
                        and asset.get('resolved_created_at') is not None
                    ):
                        self._asset_info[asset_id]['created_at'] = asset.get('resolved_created_at')
                    if (
                        self._asset_info[asset_id].get('updated_at') is None
                        and asset.get('resolved_updated_at') is not None
                    ):
                        self._asset_info[asset_id]['updated_at'] = asset.get('resolved_updated_at')

                # Column 0: row counter (1-based), not selectable, centred
                counter_item = NumericSortItem(row, str(row + 1))
                counter_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                # Enabled but NOT selectable and NOT focusable - prevents the counter
                # column from acting as an independent selection anchor when using
                # keyboard navigation, which caused the double-selection UI bug.
                counter_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemNeverHasChildren)
                self.table.setItem(row, 0, counter_item)

                # Column 1: Hash/Name — also carries the asset UserRole payload
                info = self._asset_info[asset_id]
                if self._show_names and info.get('resolved_name'):
                    display_val = info['resolved_name']
                else:
                    display_val = hash_val
                name_item = QTableWidgetItem(display_val)
                name_item.setData(Qt.ItemDataRole.UserRole, asset)
                self.table.setItem(row, 1, name_item)

                # Column 2: Creator
                creator_item = QTableWidgetItem(self._creator_display(info))
                self.table.setItem(row, 2, creator_item)

                # Column 3: Asset ID
                id_item = QTableWidgetItem(asset_id)
                self.table.setItem(row, 3, id_item)

                # Column 4: Type
                # Use persisted metadata only while building the table. Payload
                # correction is lazy and runs for rows near the viewport.
                type_name = (
                    asset.get('detected_type')
                    or asset.get('type_name')
                    or self.cache_manager.get_asset_type_name(asset['type'])
                )
                fm = self.table.fontMetrics()
                max_w = max(100, int(self.width() * 0.15))
                elided_type = fm.elidedText(type_name, Qt.TextElideMode.ElideRight, max_w)
                type_item = QTableWidgetItem(elided_type)
                if elided_type != type_name:
                    type_item.setToolTip(type_name)
                self.table.setItem(row, 4, type_item)

                # Column 5: Size
                # For TexturePack show the combined on-disk slot KTX2 sizes so the
                # user sees the real texture data footprint, not the tiny XML size.
                size = asset.get('raw_size', asset.get('size', 0))
                if asset['type'] == 63:
                    try:
                        from ..utils.paths import APP_CACHE_DIR

                        _slot_dir = APP_CACHE_DIR / 'texpack_slots'
                        _tp_slot_size = sum(
                            f.stat().st_size for f in _slot_dir.glob(f'{asset_id}_slot*.ktx2')
                        )
                        if _tp_slot_size > 0:
                            size = _tp_slot_size
                    except Exception:
                        pass
                size_str = self._format_size(size)
                size_item = NumericSortItem(size, size_str)
                self.table.setItem(row, 5, size_item)

                # Column 6: Cached At
                cached_at = _format_table_timestamp(asset.get('cached_at'))
                cached_item = QTableWidgetItem(cached_at)
                self.table.setItem(row, _COL_KEY_TO_IDX['cached_at'], cached_item)

                # Column 7: Updated At
                updated_at = _format_table_timestamp(
                    info.get('updated_at') or asset.get('resolved_updated_at')
                )
                updated_item = QTableWidgetItem(updated_at)
                self.table.setItem(row, _COL_KEY_TO_IDX['updated_at'], updated_item)

                # Column 8: Created At
                created_at = _format_table_timestamp(
                    info.get('created_at') or asset.get('resolved_created_at')
                )
                created_item = QTableWidgetItem(created_at)
                self.table.setItem(row, _COL_KEY_TO_IDX['created_at'], created_item)

                # Column 9: URL
                url = asset.get('url', '')
                url_item = QTableWidgetItem(url)
                self.table.setItem(row, _COL_KEY_TO_IDX['url'], url_item)

        finally:
            # Re-enable updates
            self.table.blockSignals(False)
            self.table.setUpdatesEnabled(True)
            self.table.setSortingEnabled(True)

        # Ensure counters reflect the visible ordering (in case a sort
        # operation occurred while populating). Defer to the event loop
        # so any pending sort completes first.
        QTimer.singleShot(0, self._renumber_counters)

        # Restore selection if the asset still exists
        if row_to_select is not None:
            self.table.blockSignals(True)
            self.table.selectRow(row_to_select)
            self.table.blockSignals(False)

        # ── Restore scroll anchor ─────────────────────────────────────────
        # Rules:
        #   1. If user was at the very top (scroll == 0), stay at the top.
        #      New assets arriving should not push the user away from the top.
        #   2. If user was scrolled down and anchor asset is still visible,
        #      restore it to the top of the viewport.
        #   3. If anchor asset is gone (filter changed), go to top — do NOT
        #      use the saved pixel value which maps to a random row in the new set.
        if _saved_scroll == 0:
            # Was at top — stay at top (don't chase anchor, just leave it)
            _vsb.setValue(0)
        elif _anchor_asset_id is not None:
            _new_anchor_row: int | None = None
            for _r in range(self.table.rowCount()):
                _it = self.table.item(_r, 1)
                if _it is not None:
                    _d = _it.data(Qt.ItemDataRole.UserRole)
                    if isinstance(_d, dict) and _d.get('id') == _anchor_asset_id:
                        _new_anchor_row = _r
                        break
            if _new_anchor_row is not None:
                self.table.scrollTo(
                    self.table.model().index(_new_anchor_row, 0),
                    self.table.ScrollHint.PositionAtTop,
                )
            # else: filter changed, anchor gone — leave at top (row 0)

        # Update stats
        try:
            stats = self.cache_manager.get_cache_stats()
            total_assets = stats['total_assets']
            total_size = self._format_size(stats['total_size'])

            self.stats_total_label.setText(f'Total: {total_assets} assets')
            self.stats_size_label.setText(f'Size: {total_size}')

            self._last_asset_count = total_assets
        except Exception:
            pass

        # OPTIMIZATION: Update row cache after table populate so background thread can use cached lookups
        self._update_asset_row_cache()
        self._schedule_visible_type_probes()

    def _schedule_visible_type_probes(self, *_args):
        """Debounce type correction requests caused by scrolling or sorting."""
        if hasattr(self, '_type_probe_debounce'):
            self._type_probe_debounce.start(60)

    def _queue_visible_type_probes(self):
        """Queue type checks for the visible rows and a small scroll-ahead buffer."""
        row_count = self.table.rowCount()
        if row_count == 0:
            return

        viewport_height = max(1, self.table.viewport().height())
        top_row = self.table.rowAt(0)
        bottom_row = self.table.rowAt(viewport_height - 1)
        if top_row < 0:
            top_row = 0
        if bottom_row < 0:
            bottom_row = row_count - 1

        visible_rows = max(1, bottom_row - top_row + 1)
        prefetch_rows = max(50, visible_rows * 2)
        start_row = max(0, top_row - prefetch_rows)
        end_row = min(row_count, bottom_row + prefetch_rows + 1)

        for row in range(start_row, end_row):
            name_item = self.table.item(row, 1)
            if name_item is None:
                continue

            asset = name_item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(asset, dict) or asset.get('type') not in (1, 13):
                continue
            if asset.get('detected_type'):
                continue

            asset_id = str(asset.get('id', ''))
            if not asset_id:
                continue
            cache_hash = str(asset.get('hash', ''))
            key = (asset_id, int(asset['type']), cache_hash)
            if key in self._type_probe_checked or key in self._type_probe_inflight:
                continue
            self._type_probe_pending[key] = key

        self._start_next_type_probe()

    def _start_next_type_probe(self):
        """Start one bounded header-probe batch, leaving later rows queued."""
        if self._type_probe_worker is not None or not self._type_probe_pending:
            return

        keys = list(self._type_probe_pending)[:128]
        for key in keys:
            self._type_probe_pending.pop(key, None)
            self._type_probe_inflight.add(key)

        worker = TypeProbeWorker(self.cache_manager, keys)
        worker.results_ready.connect(self._on_type_probe_results)
        worker.finished.connect(self._on_type_probe_finished)
        self._type_probe_worker = worker
        worker.start()

    def _on_type_probe_results(self, results: list):
        """Apply header-probe results and update only rows still in the table."""
        self.table.setUpdatesEnabled(False)
        try:
            for asset_id, asset_type, cache_hash, detected_type in results:
                key = (asset_id, asset_type, cache_hash)
                self._type_probe_inflight.discard(key)
                self._type_probe_checked.add(key)

                if not detected_type:
                    continue

                current_info = self.cache_manager.get_asset_info(asset_id, asset_type) or {}
                if str(current_info.get('hash', '')) != cache_hash:
                    continue

                # Persist the correction once, after the cheap header probe,
                # so future sessions do not need to inspect this payload.
                self.cache_manager.set_detected_type(asset_id, asset_type, detected_type)

                row = self._asset_row_cache.get(asset_id)
                if row is None or row >= self.table.rowCount():
                    continue

                name_item = self.table.item(row, 1)
                asset = name_item.data(Qt.ItemDataRole.UserRole) if name_item else None
                if (
                    not isinstance(asset, dict)
                    or str(asset.get('hash', '')) != cache_hash
                    or asset.get('type') != asset_type
                ):
                    continue

                asset['detected_type'] = detected_type
                asset['type_name'] = detected_type
                type_item = self.table.item(row, 4)
                if type_item is None:
                    continue

                fm = self.table.fontMetrics()
                max_w = max(100, int(self.width() * 0.15))
                elided_type = fm.elidedText(
                    detected_type, Qt.TextElideMode.ElideRight, max_w
                )
                type_item.setText(elided_type)
                type_item.setToolTip(detected_type if elided_type != detected_type else '')
        finally:
            self.table.setUpdatesEnabled(True)
            self.table.viewport().update()

    def _on_type_probe_finished(self):
        """Release the completed worker and continue queued viewport probes."""
        worker = self._type_probe_worker
        self._type_probe_worker = None
        if worker is not None:
            worker.deleteLater()
        self._start_next_type_probe()

    def _format_size(self, size_bytes: int) -> str:
        """Format size in bytes to human-readable string."""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f'{size_bytes:.1f} {unit}'
            size_bytes /= 1024.0
        return f'{size_bytes:.1f} TB'

    def _toggle_scraper(self, state):
        """Toggle cache scraper on/off."""
        enabled = bool(state)
        owner = getattr(self, '_replacer_window_ref', None)
        if owner is None:
            owner = self.window()
        tray = getattr(owner, '_system_tray', None)
        if tray is not None and hasattr(tray, '_set_cache_scraper_enabled'):
            tray._set_cache_scraper_enabled(enabled)
            return
        if self.cache_scraper:
            self.cache_scraper.set_enabled(enabled)

    def _proxy_features_enabled(self) -> bool:
        if self.config_manager is None:
            return True
        return bool(getattr(self.config_manager, 'proxy_features_enabled', True))

    def set_proxy_features_enabled(self, enabled: bool):
        """Keep scraper browsing available while blocking proxy-only actions."""
        if hasattr(self, 'scraper_toggle'):
            self.scraper_toggle.setEnabled(enabled)
            self.scraper_toggle.setToolTip(
                '' if enabled else 'Enable proxy features in Settings to use the cache scraper.'
            )

    def set_cache_scraper_enabled(self, enabled: bool):
        """Update the scraper toggle without re-emitting the toggle signal."""
        if hasattr(self, 'scraper_toggle'):
            self.scraper_toggle.blockSignals(True)
            self.scraper_toggle.setChecked(enabled)
            self.scraper_toggle.blockSignals(False)

    def _on_search_text_changed(self):
        """Handle search text change - debounce to avoid too many searches."""
        self._search_debounce.stop()
        self._search_debounce.start(300)  # 300ms debounce

    def _do_search(self):
        """Execute the actual search after debounce using worker thread."""
        # Stop any existing search
        if self._search_worker is not None:
            self._search_worker.stop()
            self._search_worker.quit()
            self._search_worker.wait()
            self._search_worker = None

        search_text = self.search_box.text().strip()

        # Get filter type and assets
        filter_types = self._active_filters
        assets = self.cache_manager.list_assets(filter_types)

        # For empty search, show all immediately
        if not search_text:
            self._populate_table(assets)
            return

        # Always use worker thread to prevent UI freezing
        self._is_searching = True
        self._search_worker = SearchWorkerThread(
            assets, search_text, self._asset_info, self._active_search_cols
        )
        self._search_worker.results_ready.connect(self._on_search_complete)
        self._search_worker.finished.connect(self._on_search_finished)
        self._search_worker.start()

    def _on_search_complete(self, filtered_assets: list):
        """Handle search results from worker thread."""
        self._populate_table(filtered_assets)

    def _on_search_finished(self):
        """Handle search worker thread finished."""
        self._is_searching = False

    def _on_deletion_complete(self, deleted_count: int, failed_count: int):
        """Handle deletion completion from worker thread."""
        self._refresh_assets()

        total = deleted_count + failed_count
        if failed_count == 0:
            QMessageBox.information(
                self, 'Success', f'Deleted {format_count(deleted_count, "asset")}'
            )
        else:
            QMessageBox.warning(
                self,
                'Partial Success',
                f'Deleted {deleted_count}/{format_count(total, "asset")}. {format_count(failed_count, "asset")} failed to delete.',
            )

        log_buffer.log(
            'Scraper',
            f'Batch deletion completed: {deleted_count} deleted, {failed_count} failed',
        )

    def _on_deletion_finished(self):
        """Handle deletion worker thread finished."""
        self._is_deleting = False

    def _load_persisted_names(self):
        """Load persisted resolved names from index.json."""
        loaded_count = 0
        for asset_key, asset_data in self.cache_manager.index['assets'].items():
            asset_id = asset_data['id']
            resolved_name = asset_data.get('resolved_name')
            creator_id = asset_data.get('resolved_creator_id')
            creator_name = asset_data.get('resolved_creator_name')
            creator_type = asset_data.get('resolved_creator_type')
            created_at = asset_data.get('resolved_created_at')
            updated_at = asset_data.get('resolved_updated_at')
            if (
                resolved_name is not None
                or creator_id is not None
                or created_at is not None
                or updated_at is not None
            ):
                if asset_id not in self._asset_info:
                    self._asset_info[asset_id] = {
                        'hash': asset_data.get('hash', ''),
                        'resolved_name': resolved_name,
                        'creator_id': creator_id,
                        'creator_name': creator_name,
                        'creator_type': creator_type,
                        'created_at': created_at,
                        'updated_at': updated_at,
                        'row': None,
                    }
                    loaded_count += 1
                else:
                    if resolved_name is not None:
                        self._asset_info[asset_id]['resolved_name'] = resolved_name
                    if creator_id is not None:
                        self._asset_info[asset_id]['creator_id'] = creator_id
                        self._asset_info[asset_id]['creator_name'] = creator_name
                        self._asset_info[asset_id]['creator_type'] = creator_type
                    if created_at is not None:
                        self._asset_info[asset_id]['created_at'] = created_at
                    if updated_at is not None:
                        self._asset_info[asset_id]['updated_at'] = updated_at
        log_buffer.log(
            'Scraper',
            f'[Cache Viewer] Loaded {loaded_count} persisted asset names from index',
        )

    def _creator_display(self, info: dict) -> str:
        """Return the display text for the creator column based on current toggle state."""
        creator_name = info.get('creator_name')
        creator_id = info.get('creator_id')
        if self._show_creator_id:
            if creator_id is not None:
                return str(creator_id)
            return creator_name or ''
        if creator_name is not None:
            return creator_name
        if creator_id is not None:
            return str(creator_id)
        return ''

    def _on_show_creator_id_toggled(self, checked: bool):
        """Handle Show User ID toggle — refresh the creator column for all rows."""
        self._show_creator_id = checked
        if self.config_manager is not None:
            self.config_manager.show_creator_id = checked
        self.table.setUpdatesEnabled(False)
        try:
            for asset_id, info in self._asset_info.items():
                row = info.get('row')
                if row is None or row >= self.table.rowCount():
                    continue
                creator_item = self.table.item(row, 2)
                if creator_item:
                    creator_item.setText(self._creator_display(info))
        finally:
            self.table.setUpdatesEnabled(True)

    def _on_show_names_toggled(self, checked: bool):
        """Handle Show Names toggle."""
        self._show_names = checked
        if self.config_manager is not None:
            self.config_manager.show_names = checked

        # Disable updates for performance
        self.table.setUpdatesEnabled(False)
        try:
            # Update all rows to show either resolved name or hash
            for asset_id, info in self._asset_info.items():
                row = info.get('row')
                if row is None:
                    continue
                if row >= self.table.rowCount():
                    continue

                if checked and info.get('resolved_name'):
                    display_val = info['resolved_name']
                else:
                    display_val = info.get('hash', '')

                item = self.table.item(row, 1)  # Hash/Name is now col 1
                if item:
                    item.setText(display_val)
        finally:
            # Re-enable updates
            self.table.setUpdatesEnabled(True)

    def _update_asset_row_cache(self):
        """Update the asset_id->row mapping cache after table structure changes.

        Called after table populate or sort operations. This enables O(1) lookups
        instead of O(n) linear searches in _find_row_for_asset.

        OPTIMIZATION: Caches asset positions so the background name resolver thread
        doesn't have to linearly search the table on every sync.
        """
        self._asset_row_cache.clear()
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)  # Name column has UserRole data
            if item:
                asset_data = item.data(Qt.ItemDataRole.UserRole)
                if asset_data:
                    asset_id = asset_data.get('id')
                    if asset_id:
                        self._asset_row_cache[asset_id] = row

    def _find_row_for_asset(self, asset_id: str) -> int | None:
        """Find the actual row index for an asset.

        OPTIMIZATION: Uses cached asset_id->row mapping for O(1) lookup when valid.
        Falls back to linear search (with validation) if cache miss/stale, which also
        updates the cache automatically.

        Args:
            asset_id: The asset ID to find

        Returns:
            The current row index if found, None otherwise
        """
        # Try cache first (O(1) path - common case)
        if asset_id in self._asset_row_cache:
            row = self._asset_row_cache[asset_id]
            # Validate cache is still correct (handles sort/filter invalidation)
            if row < self.table.rowCount():
                item = self.table.item(row, 1)
                if item:
                    asset_data = item.data(Qt.ItemDataRole.UserRole)
                    if asset_data and asset_data.get('id') == asset_id:
                        return row  # Cache hit!
            # Cache is stale, fall through to linear search and update

        # Linear search (O(n) path - fallback, also updates cache on hit)
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)  # Name column (col 1) has UserRole data
            if item:
                asset_data = item.data(Qt.ItemDataRole.UserRole)
                if asset_data and asset_data.get('id') == asset_id:
                    self._asset_row_cache[asset_id] = row  # Update cache for next time
                    return row
        return None

    def _sync_visible_rows_with_asset_info(self):
        """Update visible table rows with resolved names/creators from _asset_info.

        Called after the background name-resolver finishes a batch.

        Performance contract: O(k) where k = number of assets with new data.
        Never falls back to O(n) linear scan — if an asset isn't in
        _asset_row_cache it's simply not in the current view (filtered/sorted
        out) and we skip it.  The cache is always rebuilt by
        _update_asset_row_cache() after every _populate_table call, so a
        cache miss genuinely means "not visible", not "cache stale".
        """
        row_count = self.table.rowCount()
        if row_count == 0:
            return

        self.table.setUpdatesEnabled(False)
        try:
            for asset_id, info in self._asset_info.items():
                # Fast O(1) cache lookup — no linear scan ever.
                row = self._asset_row_cache.get(asset_id)
                if row is None or row >= row_count:
                    continue  # Not in current view; skip.

                # Validate cache is still correct (sort/filter may shift rows).
                # Validation is O(1) — just one item() call.
                item = self.table.item(row, 1)
                if not item:
                    continue
                asset_data = item.data(Qt.ItemDataRole.UserRole)
                if not asset_data or asset_data.get('id') != asset_id:
                    # Cache is stale for this asset — skip rather than scan.
                    # It will be corrected on the next _populate_table call.
                    continue

                # Update name column if resolved
                if self._show_names and info.get('resolved_name'):
                    if item.text() != info['resolved_name']:
                        item.setText(info['resolved_name'])

                # Update creator column if resolved
                if info.get('creator_name') is not None or info.get('creator_id') is not None:
                    creator_item = self.table.item(row, 2)
                    if creator_item:
                        desired = self._creator_display(info)
                        if creator_item.text() != desired:
                            creator_item.setText(desired)

                # Update Roblox asset timestamps if resolved
                updated_item = self.table.item(row, _COL_KEY_TO_IDX['updated_at'])
                updated_at = _format_table_timestamp(info.get('updated_at'))
                if updated_item and updated_item.text() != updated_at:
                    updated_item.setText(updated_at)
                created_item = self.table.item(row, _COL_KEY_TO_IDX['created_at'])
                created_at = _format_table_timestamp(info.get('created_at'))
                if created_item and created_item.text() != created_at:
                    created_item.setText(created_at)
        finally:
            self.table.setUpdatesEnabled(True)
            self.table.viewport().update()

        # If a search is active, re-run it so that assets whose names were
        # just resolved (and now match the query) appear in the results.
        if self.search_box.text().strip():
            self._search_debounce.start(400)

    def _update_row_name(self, asset_id: str, name: str):
        """Update a single row's name cell (thread-safe via QTimer)."""
        info = self._asset_info.get(asset_id)
        if not info:
            return
        row = info.get('row')
        if row is None or row >= self.table.rowCount():
            return
        # Only update if Show Names is enabled
        if self._show_names:
            item = self.table.item(row, 1)  # Hash/Name is col 1
            if item:
                item.setText(name)
                # Force immediate repaint of this row
                self.table.viewport().update()

    def _update_row_creator(self, asset_id: str, creator_id: int | None, creator_name: str | None):
        """Update a single row's creator cell (thread-safe via QTimer).

        Args:
            asset_id: The asset ID
            creator_id: The numeric creator ID (for fallback display)
            creator_name: The resolved creator name (preferred display)
        """
        info = self._asset_info.get(asset_id)
        if not info:
            return
        row = info.get('row')
        if row is None or row >= self.table.rowCount():
            return
        item = self.table.item(row, 2)  # Creator is col 2
        if item:
            item.setText(self._creator_display(info))
            # Force immediate repaint of this row
            self.table.viewport().update()

    def _save_resolved_name_to_index(self, asset_id: str, name: str):
        """Save resolved name to index.json for persistence."""
        asset_keys = list(self.cache_manager.index['assets'].keys())
        for asset_key in asset_keys:
            if asset_key not in self.cache_manager.index['assets']:
                continue
            asset_data = self.cache_manager.index['assets'][asset_key]
            if asset_data['id'] == asset_id:
                asset_data['resolved_name'] = name
                break

    def _save_resolved_creator_to_index(
        self,
        asset_id: str,
        creator_id: int | None,
        creator_name: str | None,
        creator_type: int | None,
    ):
        """Save resolved creator info to index.json for persistence."""
        asset_keys = list(self.cache_manager.index['assets'].keys())
        for asset_key in asset_keys:
            if asset_key not in self.cache_manager.index['assets']:
                continue
            asset_data = self.cache_manager.index['assets'][asset_key]
            if asset_data['id'] == asset_id:
                asset_data['resolved_creator_id'] = creator_id
                asset_data['resolved_creator_name'] = creator_name
                asset_data['resolved_creator_type'] = creator_type
                break

    def _save_resolved_timestamps_to_index(
        self, asset_id: str, created_at: str | None, updated_at: str | None
    ):
        """Save Roblox asset created/updated timestamps to index.json for persistence."""
        asset_keys = list(self.cache_manager.index['assets'].keys())
        for asset_key in asset_keys:
            if asset_key not in self.cache_manager.index['assets']:
                continue
            asset_data = self.cache_manager.index['assets'][asset_key]
            if asset_data['id'] == asset_id:
                asset_data['resolved_created_at'] = created_at or ''
                asset_data['resolved_updated_at'] = updated_at or ''
                break

    def _get_roblosecurity(self) -> str | None:
        from ..utils.roblox_auth import get_roblosecurity

        return get_roblosecurity()

    def _fetch_asset_names(
        self, asset_ids: list[str], cookie: str | None
    ) -> dict[str, dict] | None:
        """Fetch asset names and creator info from Roblox Develop API (batch up to 50).

        Returns a dict keyed by asset_id with values:
            {'name': str, 'creator_id': int|None, 'creator_type': int|None}
        """
        import requests

        if not asset_ids:
            return None

        # Build session with auth
        sess = requests.Session()
        sess.trust_env = False
        sess.proxies = {}
        sess.headers.update(
            {
                'User-Agent': 'Roblox/WinInet',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Referer': 'https://www.roblox.com/',
                'Origin': 'https://www.roblox.com',
            }
        )
        if cookie:
            try:
                # Prefer setting cookie on the session so requests handles it properly
                sess.cookies.set('.ROBLOSECURITY', cookie)
            except Exception:
                # Fallback to header if cookie set fails
                sess.headers['Cookie'] = f'.ROBLOSECURITY={cookie};'

        # Build query: assetIds=123,456,789
        query = ','.join(str(aid) for aid in asset_ids)
        url = f'https://develop.roblox.com/v1/assets?assetIds={query}'

        try:
            response = sess.get(url, timeout=10)
            response.raise_for_status()
        except Exception as e:
            log_buffer.log('Scraper', f'[Name Resolver] Failed to fetch names: {e}')
            return None

        data = response.json().get('data', [])

        result = {}
        for item in data:
            aid = item.get('id')
            if aid is None:
                continue

            # Newer API returns a nested 'creator' object; older APIs used
            # flat 'creatorTargetId' and 'creatorType' fields. Support both.
            creator_obj = item.get('creator') or {}
            creator_id = None
            creator_type = None

            # New format: {'type': 'User'|'Group', 'typeId': 1|2, 'targetId': <id>}
            if isinstance(creator_obj, dict) and creator_obj:
                creator_id = creator_obj.get('targetId')
                creator_type = creator_obj.get('typeId')

            # Fallback to legacy flat fields
            if creator_id is None:
                creator_id = item.get('creatorTargetId')
            if creator_type is None:
                creator_type = item.get('creatorType')

            # Normalise numeric types (ensure int or None)
            try:
                if creator_type is not None:
                    creator_type = int(creator_type)
            except Exception:
                creator_type = None
            try:
                if creator_id is not None:
                    creator_id = int(creator_id)
            except Exception:
                creator_id = None

            result[str(aid)] = {
                'name': item.get('name', 'Unknown'),
                'creator_id': creator_id,
                'creator_type': creator_type,  # 1 = User, 2 = Group
                'created_at': item.get('created') or '',
                'updated_at': item.get('updated') or '',
            }

        return result

    def _fetch_creator_names(self, creators: dict[int, int], sess) -> dict[int, str]:
        """Resolve creator IDs to display names.

        Args:
            creators: dict mapping creator_id (int) → creator_type (int)
                      creator_type 1 = User, 2 = Group
            sess: requests.Session to reuse

        Returns:
            dict mapping creator_id (int) → creator display name (str)
        """
        import requests

        result: dict[int, str] = {}
        if not creators:
            return result

        user_ids = [cid for cid, ctype in creators.items() if ctype == 1]
        group_ids = [cid for cid, ctype in creators.items() if ctype == 2]

        # Batch-resolve users via POST /v1/users
        if user_ids:
            try:
                resp = sess.post(
                    'https://users.roblox.com/v1/users',
                    json={'userIds': user_ids, 'excludeBannedUsers': False},
                    timeout=10,
                )
                resp.raise_for_status()
                for entry in resp.json().get('data', []):
                    uid = entry.get('id')
                    name = entry.get('name') or entry.get('displayName') or 'Unknown'
                    if uid is not None:
                        result[uid] = name

            except Exception as e:
                # If user batch lookup fails, continue without user names
                log_buffer.log('Scraper', f'[Name Resolver] Failed to fetch user names: {e}')

        # Resolve groups one-by-one (no batch endpoint on v1)
        for gid in group_ids:
            try:
                resp = sess.get(
                    f'https://groups.roblox.com/v1/groups/{gid}',
                    timeout=10,
                )
                resp.raise_for_status()
                name = resp.json().get('name', 'Unknown')
                result[gid] = name

            except Exception as e:
                # If a single group lookup fails, skip that group
                log_buffer.log('Scraper', f'[Name Resolver] Failed to fetch group {gid}: {e}')

        return result

    def _name_resolver_loop(self):
        """Background thread to resolve asset names and creator names."""
        import time

        import requests

        while True:
            # Skip if Show Names is OFF
            if not self._show_names:
                time.sleep(0.2)
                continue

            # Get authentication cookie
            cookie = self._get_roblosecurity()
            if not cookie:
                # No cookie - wait longer to avoid spam
                time.sleep(5)
                continue

            try:
                # Build pending list - assets without resolved names
                # Build pending list - assets without resolved names.
                # Prioritise assets in visible rows, then resolve the rest so that
                # search-by-name works even for assets not currently displayed.
                _row_count = self.table.rowCount()
            except RuntimeError:
                # Widget has been deleted (app shutting down)
                break

            visible = []
            hidden = []
            for asset_id, info in self._asset_info.items():
                if not _asset_metadata_needs_resolution(info):
                    continue
                row = info.get('row')
                if row is not None and row < _row_count:
                    visible.append(asset_id)
                else:
                    hidden.append(asset_id)
            pending = visible + hidden

            if not pending:
                time.sleep(0.2)
                continue

            # Batch size and delay
            batch_size = 50
            delay = 0.2 if len(pending) > 50 else 0.5

            # Take the first batch
            batch = pending[:batch_size]

            # Fetch names + creator IDs
            try:
                asset_data_map = self._fetch_asset_names(batch, cookie)
            except Exception as e:
                log_buffer.log('Scraper', f'[Name Resolver] Fetch failed: {e}')
                time.sleep(delay)
                continue

            if not asset_data_map:
                time.sleep(delay)
                continue

            # Build a reusable session for creator lookups (same auth headers)
            sess = requests.Session()
            sess.trust_env = False
            sess.proxies = {}
            sess.headers.update(
                {
                    'User-Agent': 'Roblox/WinInet',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'Referer': 'https://www.roblox.com/',
                    'Origin': 'https://www.roblox.com',
                }
            )
            sess.headers['Cookie'] = f'.ROBLOSECURITY={cookie};'

            # Collect creator IDs that need name resolution
            creators_to_resolve: dict[int, int] = {}  # creator_id → creator_type
            for asset_id, data in asset_data_map.items():
                cid = data.get('creator_id')
                ctype = data.get('creator_type')
                if cid is not None and ctype is not None and cid not in creators_to_resolve:
                    creators_to_resolve[cid] = ctype

            log_buffer.log(
                'Scraper',
                f'[Name Resolver] Collected {format_count(creators_to_resolve, "unique creator ID")} to resolve',
            )

            # Fetch creator display names
            creator_names: dict[int, str] = {}
            if creators_to_resolve:
                try:
                    creator_names = self._fetch_creator_names(creators_to_resolve, sess)
                except Exception as e:
                    log_buffer.log('Scraper', f'[Name Resolver] Creator fetch failed: {e}')

            log_buffer.log(
                'Scraper',
                f'[Name Resolver] Resolved {format_count(creator_names, "creator name")}',
            )

            # Update cache and UI
            for asset_id, data in asset_data_map.items():
                info = self._asset_info.get(asset_id)
                if not info:
                    continue

                name = data.get('name', 'Unknown')
                creator_id = data.get('creator_id')
                creator_type = data.get('creator_type')
                creator_name = creator_names.get(creator_id) if creator_id is not None else None
                created_at = data.get('created_at') or ''
                updated_at = data.get('updated_at') or ''
                # Store resolved name in memory
                info['resolved_name'] = name
                info['creator_id'] = creator_id
                info['creator_type'] = creator_type
                info['creator_name'] = creator_name
                info['created_at'] = created_at
                info['updated_at'] = updated_at

                # Save to index.json for persistence
                self._save_resolved_name_to_index(asset_id, name)
                self._save_resolved_creator_to_index(
                    asset_id, creator_id, creator_name, creator_type
                )
                self._save_resolved_timestamps_to_index(asset_id, created_at, updated_at)

            # Save index after batch update (less frequent saves)
            try:
                self.cache_manager._save_index()
            except Exception as e:
                log_buffer.log('Scraper', f'[Name Resolver] Failed to save index: {e}')

            # CRITICAL: After resolving a batch, immediately sync all visible rows with the updated data
            # This ensures that the last asset (and all assets) show their resolved names/creators
            # without waiting for the next _populate_table call
            # Emit signal which is thread-safe and connected to the sync slot
            self._sync_table_requested.emit()

            time.sleep(delay)

    def _get_selected_asset(self) -> dict | None:
        """Get the currently selected asset."""
        current_row = self.table.currentRow()
        if current_row < 0:
            return None

        id_item = self.table.item(current_row, 1)  # col 1 = Hash/Name (carries UserRole)
        if not id_item:
            return None

        return id_item.data(Qt.ItemDataRole.UserRole)

    def _export_selected(self):
        """Export the selected asset."""
        asset = self._get_selected_asset()
        if not asset:
            QMessageBox.warning(self, 'No Selection', 'Please select an asset to export')
            return

        # Ask for export location
        default_name = f'{asset["id"]}.bin'
        file_path, _ = QFileDialog.getSaveFileName(
            self, 'Export Asset', default_name, 'All Files (*)'
        )

        if not file_path:
            return

        from pathlib import Path

        # Sanitize resolved name if present (though the user's chosen filename already safe)
        asset_id = asset['id']
        resolved_name = None
        if asset_id in self._asset_info:
            resolved_name = self._asset_info[asset_id].get('resolved_name')
        safe_name = self._sanitize_filename(resolved_name) if resolved_name else None

        export_path = self.cache_manager.export_asset(
            asset['id'], asset['type'], Path(file_path), resolved_name=safe_name
        )

        if export_path:
            log_buffer.log('Scraper', f'Exported asset {asset["id"]} to {export_path}')
            self._show_export_complete_message(
                'Success',
                f'Asset exported to:\n{export_path}',
                [export_path],
            )
        else:
            QMessageBox.critical(self, 'Error', 'Failed to export asset')

    def _get_export_open_target(self, exported_paths):
        """Return the Explorer target and whether it should be selected."""
        import os
        from pathlib import Path

        existing_paths = []
        for path in exported_paths:
            if not path:
                continue
            p = Path(path)
            if p.exists():
                existing_paths.append(p)

        if not existing_paths:
            return self.cache_manager.export_dir, False

        if len(existing_paths) == 1:
            path = existing_paths[0]
            return path, path.is_file()

        containers = [path if path.is_dir() else path.parent for path in existing_paths]
        if all(container == containers[0] for container in containers):
            return containers[0], False

        common_parent = Path(os.path.commonpath([str(container) for container in containers]))
        return common_parent, False

    def _open_export_target(self, exported_paths):
        """Open exported output in Explorer, selecting a single exported file when possible."""
        import subprocess
        from pathlib import Path

        target, select_file = self._get_export_open_target(exported_paths)
        target = Path(target)

        def _fallback_open_folder():
            # Multi-tier fallback: parent of selected file -> computed target -> root export dir.
            if select_file:
                open_folder(target.parent)
                return
            open_folder(target if target.is_dir() else self.cache_manager.export_dir)

        try:
            if select_file:
                if target.is_file():
                    subprocess.Popen(
                        ['explorer.exe', '/select,', str(target.resolve())],
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
                    )
                else:
                    _fallback_open_folder()
            else:
                open_folder(target if target.is_dir() else self.cache_manager.export_dir)
        except Exception as exc:
            log_buffer.log('Export', f'Could not open export target {target}: {exc}')
            try:
                _fallback_open_folder()
            except Exception as fallback_exc:
                log_buffer.log(
                    'Export',
                    f'Fallback open failed for export target {target}: {fallback_exc}',
                )

    def _show_export_complete_message(self, title: str, message: str, exported_paths):
        """Show an export completion dialog with a shortcut to the destination folder."""
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setWindowTitle(title)
        msg.setText(message)
        open_button = msg.addButton('Open in Explorer', QMessageBox.ButtonRole.ActionRole)
        msg.addButton(QMessageBox.StandardButton.Ok)
        msg.exec()

        if msg.clickedButton() == open_button:
            self._open_export_target(exported_paths)

    def _export_all(self):
        """Export all visible assets."""
        # Get current filter
        filter_types = self._active_filters
        assets = self.cache_manager.list_assets(filter_types)

        # Apply search filter across all columns (same as _refresh_assets)
        search_text = self.search_box.text().strip().lower()
        if search_text:
            filtered = []
            for a in assets:
                asset_id = a['id'].lower()
                type_name = a['type_name'].lower()
                url = a.get('url', '').lower()
                hash_val = a.get('hash', '').lower()
                size_str = self._format_size(a.get('raw_size', a.get('size', 0))).lower()
                cached_at = a.get('cached_at', '').lower()
                cached_at_display = _format_table_timestamp(a.get('cached_at')).lower()
                created_at = (a.get('resolved_created_at') or '').lower()
                updated_at = (a.get('resolved_updated_at') or '').lower()
                created_at_display = _format_table_timestamp(a.get('resolved_created_at')).lower()
                updated_at_display = _format_table_timestamp(a.get('resolved_updated_at')).lower()

                resolved_name = ''
                if asset_id in self._asset_info:
                    info = self._asset_info[asset_id]
                    name = info.get('resolved_name')
                    resolved_name = name.lower() if name else ''
                    created_at = (info.get('created_at') or created_at).lower()
                    updated_at = (info.get('updated_at') or updated_at).lower()
                    created_at_display = _format_table_timestamp(
                        info.get('created_at') or created_at
                    ).lower()
                    updated_at_display = _format_table_timestamp(
                        info.get('updated_at') or updated_at
                    ).lower()

                if (
                    search_text in asset_id
                    or search_text in type_name
                    or search_text in url
                    or search_text in hash_val
                    or search_text in resolved_name
                    or search_text in size_str
                    or search_text in cached_at
                    or search_text in cached_at_display
                    or search_text in updated_at
                    or search_text in updated_at_display
                    or search_text in created_at
                    or search_text in created_at_display
                ):
                    filtered.append(a)
            assets = filtered

        if not assets:
            QMessageBox.warning(self, 'No Assets', 'No assets to export')
            return

        reply = QMessageBox.question(
            self,
            'Export All',
            f'Export {format_count(assets, "asset")} to the export folder?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )

        if reply != QMessageBox.StandardButton.Yes:
            return

        exported_count = 0
        exported_paths = []
        for asset in assets:
            asset_id = asset['id']
            resolved_name = None
            if asset_id in self._asset_info:
                resolved_name = self._asset_info[asset_id].get('resolved_name')
            safe_name = self._sanitize_filename(resolved_name) if resolved_name else None

            export_path = self.cache_manager.export_asset(
                asset['id'], asset['type'], resolved_name=safe_name
            )
            if export_path:
                exported_count += 1
                exported_paths.append(export_path)

        log_buffer.log('Scraper', f'Exported {exported_count}/{len(assets)} assets')
        location, _ = self._get_export_open_target(exported_paths)
        self._show_export_complete_message(
            'Export Complete',
            f'Exported {format_count(exported_count, "asset")}\n\nLocation: {location}',
            exported_paths,
        )

    def _delete_selected(self):
        """Delete the selected assets using background worker thread."""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, 'No Selection', 'Please select assets to delete')
            return

        # Collect assets to delete
        assets_to_delete = []
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, 1)
            if item:
                asset = item.data(Qt.ItemDataRole.UserRole)
                if asset:
                    assets_to_delete.append(asset)

        if not assets_to_delete:
            return

        # Confirm deletion
        count = len(assets_to_delete)
        reply = QMessageBox.question(
            self,
            'Delete Assets',
            f'Delete {format_count(count, "asset")}?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )

        if reply == QMessageBox.StandardButton.Yes:
            # Use background worker thread for fast batch deletion
            self._is_deleting = True
            self._delete_worker = DeleteWorkerThread(assets_to_delete, self.cache_manager)
            self._delete_worker.deletion_complete.connect(self._on_deletion_complete)
            self._delete_worker.finished.connect(self._on_deletion_finished)
            self._delete_worker.start()

    def _clear_cache(self):
        """Delete the entire cache database and files (old Delete DB functionality)."""
        reply = QMessageBox.question(
            self,
            'Delete Database',
            'This will delete all cached assets AND the database index.\nThis cannot be undone. Continue?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                import shutil

                # Stop any header probes before replacing the database.  A
                # worker that finishes against the old index can otherwise
                # repopulate the viewer while the reset is in progress.
                if hasattr(self, '_type_probe_debounce'):
                    self._type_probe_debounce.stop()
                type_probe_worker = self._type_probe_worker
                if type_probe_worker is not None:
                    type_probe_worker.stop()
                    type_probe_worker.wait()
                    self._type_probe_worker = None
                self._type_probe_pending.clear()
                self._type_probe_inflight.clear()
                self._type_probe_checked.clear()

                # Delete DB is also a process-state reset: evict payloads
                # retained by CacheManager and invalidate/cancel scraper work
                # that was queued for the old database.
                self.cache_manager.clear_memory_cache()
                if self.cache_scraper:
                    reset_scraper = getattr(self.cache_scraper, 'reset_for_cache_clear', None)
                    if callable(reset_scraper):
                        reset_scraper()
                    else:
                        self.cache_scraper.clear_tracking()

                cache_dir = self.cache_manager.cache_dir
                if cache_dir.exists():
                    shutil.rmtree(cache_dir)
                    cache_dir.mkdir(parents=True, exist_ok=True)
                # Reset the index
                self.cache_manager.index = {'assets': {}}
                self.cache_manager._save_index()
                self._last_asset_count = 0
                self._asset_info.clear()
                self._refresh_assets()
                log_buffer.log('Scraper', 'Database deleted and reset')
                QMessageBox.information(self, 'Success', 'Database deleted successfully')
            except Exception as e:
                QMessageBox.critical(self, 'Error', f'Failed to delete database: {e}')

    def _delete_roblox_cache(self):
        """Delete Roblox cache using system tray method."""
        from ..gui import DeleteCacheWindow

        window = DeleteCacheWindow()
        window.show()

    def _redirect_counter_focus(
        self, current_row: int, current_col: int, previous_row: int, previous_col: int
    ) -> None:
        """If Qt moves focus onto column 0 (the counter), immediately redirect it
        to column 1 of the same row.  This ensures there is always exactly one
        selection anchor and prevents the double-selection / jump bug that occurs
        during keyboard navigation when column 0 is non-selectable.
        """
        if current_col == 0 and current_row >= 0:
            self.table.blockSignals(True)
            self.table.setCurrentCell(current_row, 1)
            self.table.blockSignals(False)

    def _on_selection_changed(self):
        """Handle table selection change to preview asset."""
        self._remember_current_rbxm_draft()
        asset = self._get_selected_asset()
        if not asset:
            self._selected_asset_id = None
            self._clear_preview()
            return

        # Track if preview was hidden before showing it
        was_hidden = self.preview_panel.isHidden()
        self.preview_panel.show()

        # Auto-snap splitter ONLY if it was previously hidden (first selection)
        if was_hidden:
            QTimer.singleShot(0, self._auto_snap_splitter)

        # Track selected asset ID for persistence across refreshes
        self._selected_asset_id = asset['id']

        # Stop all loaders first
        self._stop_all_loaders()

        # Hide all preview widgets first
        self.obj_viewer.hide()
        self.image_label.hide()
        self.loading_label.hide()
        self.audio_wrapper.hide()
        self.animation_viewer.hide()
        self.text_viewer.hide()
        self.json_viewer.hide()
        self.rbxm_viewer.hide()
        self.font_wrapper.hide()
        self.rbxm_view_btn.hide()

        # Clean up texture pack widget
        if self.texturepack_widget is not None:
            self.texturepack_widget.deleteLater()
            self.texturepack_widget = None

        # Stop any playing audio
        if self.audio_player:
            self.audio_player.stop()
            self.audio_player.deleteLater()
            self.audio_player = None
        # Remove global audio key event filter if installed
        try:
            if self._audio_key_filter_installed:
                from PyQt6.QtWidgets import QApplication

                QApplication.instance().removeEventFilter(self)
                self._audio_key_filter_installed = False
        except Exception:
            pass

        # Stop animation playback
        self.animation_viewer.stop()

        asset_type = asset['type']
        asset_id = asset['id']

        # Update preview group title to show resolved name or hash for clarity
        try:
            info = self._asset_info.get(asset_id, {})
            resolved = info.get('resolved_name') if info else None
            display = resolved or asset.get('hash') or str(asset_id)
            # Trim long names/hashes to keep the UI tidy
            if len(display) > 60:
                display = display[:57] + '...'
            self.preview_title_label.setText(f'Preview: {display}')
        except Exception:
            try:
                self.preview_title_label.setText('Preview')
            except Exception:
                pass

        try:
            # Get asset data
            data = self.cache_manager.get_asset(asset_id, asset_type)
            if not data:
                self._show_text_preview(f'Failed to load asset {asset_id}')
                return
            detected_type_name = self.cache_manager.get_type_name_for_asset(asset_id, asset_type)
            if detected_type_name != self.cache_manager.get_asset_type_name(asset_type):
                asset['type_name'] = detected_type_name
                type_item = self.table.item(self.table.currentRow(), 4)
                if type_item is not None:
                    type_item.setText(detected_type_name)
            if asset_type == 63:  # TexturePack
                self._show_loading()
                self._preview_texturepack(data, asset_id)
                return
            is_rbx_document = is_rbx_model_data(data)
            if asset_type in (24, 39) and is_rbx_document:
                self.rbxm_view_btn.show()
            elif is_rbx_document:
                self._preview_rbxm(data, asset)
                return
            is_mesh_payload = mesh_processing.is_mesh_data(data)

            # Show loading for async previews
            if is_mesh_payload or asset_type in [
                4,
                39,
                1,
                13,
                63,
            ]:  # Mesh, SolidModel, Image, Decal, TexturePack
                self._show_loading()

            # Preview based on type
            if is_mesh_payload or asset_type == 4:  # Mesh
                self._preview_mesh(data, asset_id)
            elif asset_type == 39:  # SolidModel
                self._preview_solidmodel(data, asset_id)
            elif detected_type_name == 'Audio':  # Payload is audio despite assetTypeId
                self._preview_audio(data, asset_id)
            elif asset_type in [1, 13]:  # Image, Decal
                self._preview_image(data)
            elif asset_type == 3:  # Audio
                self._preview_audio(data, asset_id)
            elif asset_type == 24:  # Animation
                self._preview_animation(data, asset_id)
            elif asset_type == 74:  # FontFace - actual font file
                self._preview_font(data)
            elif asset_type == 73:  # FontFamily - JSON metadata
                is_json, _ = self._is_json_data(data)
                if is_json:
                    self._preview_json(data, asset)
                else:
                    self._show_text_preview('FontFamily data could not be parsed as JSON')
            else:
                # Check if unknown/model-like asset is actually RBXM/RBXMX before JSON/text fallbacks.
                if is_rbx_model_data(data):
                    self._preview_rbxm(data, asset)
                else:
                    is_json, _ = self._is_json_data(data)
                    if is_json:
                        self._preview_json(data, asset)
                    else:
                        # Show as hex dump for other types
                        self._preview_hex(data, asset)

        except Exception as e:
            self._show_text_preview(f'Error previewing asset: {e}')

    def _show_context_menu(self, position):
        """Show right-click context menu."""
        menu = QMenu(self)

        # Get selected rows
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        send_replace_action = menu.addAction('Replace')
        send_replace_with_action = menu.addAction('Replace with')
        proxy_enabled = self._proxy_features_enabled()
        send_replace_action.setEnabled(proxy_enabled)
        send_replace_with_action.setEnabled(proxy_enabled)

        # Export submenu with format options
        export_menu = menu.addMenu('Export Selected')

        # Get selected assets and types to determine available formats
        selected_assets = []
        asset_types = set()
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, 1)
            if item:
                asset = item.data(Qt.ItemDataRole.UserRole)
                if asset:
                    selected_assets.append(asset)
                    asset_types.add(asset['type'])

        # Determine available formats (intersection of all selected types)
        available_formats = None
        for asset in selected_assets:
            formats = set(
                self.cache_manager.get_available_export_formats_for_asset(
                    asset['id'],
                    asset['type'],
                )
            )
            if available_formats is None:
                available_formats = formats
            else:
                available_formats &= formats

        if not available_formats:
            available_formats = {'raw', 'bin'}

        modified_asset = None
        if len(selected_rows) == 1:
            row = selected_rows[0].row()
            item = self.table.item(row, 1)
            if item:
                candidate = item.data(Qt.ItemDataRole.UserRole)
                if (
                    candidate
                    and candidate.get('type') != 9
                    and self._get_modified_rbxm_draft(candidate) is not None
                ):
                    modified_asset = candidate
                    available_formats = set(available_formats)
                    available_formats.update(
                        {'converted_modified_rbxm', 'converted_modified_rbxmx'}
                    )

        # Add format options
        export_actions = {}
        format_labels = {
            'converted_rigged_glb': 'Rigged Mesh (.glb)',
            'converted_obj': 'Converted (.obj)',
            'converted_rbxmx': 'Converted - KeyframeSequence (.rbxmx)',
            'converted_rbxmx_curve': 'Converted - CurveAnimation (.rbxmx)',
            'converted_rbxmx_model': 'Converted (.rbxmx)',
            'converted_document_rbxm': 'Roblox Document (.rbxm)',
            'converted_document_rbxmx': 'Roblox Document (.rbxmx)',
            'converted_document_rbxl': 'Roblox Place (.rbxl)',
            'converted_modified_rbxm': 'Converted (Modified .rbxm)',
            'converted_modified_rbxmx': 'Converted (Modified .rbxmx)',
            'converted_png': 'Converted (.png)',
            'converted_audio': 'Converted (.ogg/.mp3)',
            'converted': 'Converted (.xml)',
            'converted_images': 'Converted (Images)',
            'slot_ktx2': 'Slot KTX2 Files',
            'bin': 'Binary (decompressed)',
            'raw': 'Raw (original cache)',
        }
        for fmt in [
            'converted_modified_rbxm',
            'converted_modified_rbxmx',
            'converted_document_rbxl',
            'converted_document_rbxm',
            'converted_document_rbxmx',
            'slot_ktx2',
            'converted_rigged_glb',
            'converted_obj',
            'converted_rbxmx_model',
            'converted_rbxmx',
            'converted_rbxmx_curve',
            'converted_png',
            'converted_audio',
            'converted',
            'converted_images',
            'bin',
            'raw',
        ]:
            if fmt in available_formats:
                action = export_menu.addAction(format_labels[fmt])
                export_actions[action] = fmt

        menu.addSeparator()

        # Copy submenu
        copy_menu = menu.addMenu('Copy')
        copy_hash_action = copy_menu.addAction('Hash/Name')
        copy_id_action = copy_menu.addAction('Asset ID')
        copy_url_action = copy_menu.addAction('URL')
        copy_menu.addSeparator()
        copy_creator_name_action = copy_menu.addAction('Creator Name')
        copy_creator_id_action = copy_menu.addAction('Creator ID')

        # Add "Copy Converted" if at least one selected asset supports conversion
        copy_converted_action = None
        if any(f.startswith('converted') for f in available_formats):
            copy_menu.addSeparator()
            copy_converted_action = copy_menu.addAction('Converted Data')

        # Add Open Creator action below the Copy menu
        open_creator_action = menu.addAction('Open Creator')

        # Export as game dump
        copy_dump_action = menu.addAction('Export as Game Dump')

        # Convert animation rig - only when exactly one Animation is selected
        convert_anim_action = None
        _convert_anim_asset = None
        if len(selected_rows) == 1 and asset_types == {24}:
            row = selected_rows[0].row()
            item = self.table.item(row, 1)
            if item:
                _convert_anim_asset = item.data(Qt.ItemDataRole.UserRole)
                if _convert_anim_asset:
                    try:
                        from ..utils.anim_converter import detect_rig, rbxm_to_rbxmx

                        _anim_data = self.cache_manager.get_asset(
                            _convert_anim_asset['id'], _convert_anim_asset['type']
                        )
                        if _anim_data:
                            _rig = detect_rig(_anim_data)
                            _target_rig = 'R6' if _rig == 'R15' else 'R15'
                            convert_anim_action = menu.addAction(f'Convert to {_target_rig}')
                    except Exception:
                        pass

        menu.addSeparator()
        delete_action = menu.addAction('Delete Selected')

        # Execute menu
        action = menu.exec(self.table.viewport().mapToGlobal(position))

        if action == send_replace_action:
            self._add_selected_to_replacer()
        elif action == send_replace_with_action:
            self._add_latest_as_replace_with()
        elif action in export_actions:
            _fmt = export_actions[action]
            if _fmt == 'slot_ktx2':
                # Export slot KTX2 files for all selected TexturePack rows
                for row_index in selected_rows:
                    _row = row_index.row()
                    _item = self.table.item(_row, 1)
                    if _item:
                        _asset = _item.data(Qt.ItemDataRole.UserRole)
                        if _asset and _asset.get('type') == 63:
                            self._export_texpack_slot_ktx2(str(_asset['id']))
            elif _fmt in {'converted_modified_rbxm', 'converted_modified_rbxmx'} and modified_asset:
                path = self._export_modified_rbxm_asset(modified_asset, _fmt)
                if path:
                    self._show_export_complete_message(
                        'Export Complete',
                        f'Exported modified RBXM/RBXMX\n\nLocation: {path.parent}',
                        [path],
                    )
            else:
                self._export_selected_multiple(export_format=_fmt)
        elif action == delete_action:
            self._delete_selected()
        elif action == copy_hash_action:
            self._copy_column(1)  # Hash/Name
        elif action == copy_id_action:
            self._copy_column(3)  # Asset ID (shifted by Creator col)
        elif action == copy_url_action:
            self._copy_column(_COL_KEY_TO_IDX['url'])
        elif action == copy_creator_name_action:
            self._copy_creator_info('name')
        elif action == copy_creator_id_action:
            self._copy_creator_info('id')
        elif action == open_creator_action:
            self._open_creator_in_browser()
        elif copy_converted_action is not None and action == copy_converted_action:
            self._copy_converted()
        elif action == copy_dump_action:
            self._export_as_game_dump()
        elif action is not None and action == convert_anim_action and _convert_anim_asset:
            self._convert_animation_rig(_convert_anim_asset, _target_rig)

    def _convert_animation_rig(self, asset: dict, target: str):
        """Convert an animation between R6 and R15 and save to a user-chosen path."""
        import threading
        from pathlib import Path

        from PyQt6.QtWidgets import QFileDialog

        asset_id = asset.get('id', 'animation')
        default_name = f'{asset_id}_{target.lower()}.rbxmx'
        out_str, _ = QFileDialog.getSaveFileName(
            self,
            'Save Converted Animation',
            default_name,
            'Roblox Animation (*.rbxmx);;All files (*.*)',
        )
        if not out_str:
            return

        def _do_convert():
            import re
            import sys
            import xml.etree.ElementTree as _ET

            try:
                from ..utils.anim_converter import rbxm_to_rbxmx
                from ..utils.rig_data import R6_JOINTS, R6_PARTS, R15_JOINTS, R15_PARTS
            except Exception as e:
                QMessageBox.warning(self, 'Convert Error', f'Failed to load converter: {e}')
                return

            anim_data = self.cache_manager.get_asset(asset['id'], asset['type'])
            if not anim_data:
                QMessageBox.warning(self, 'Convert Error', 'Could not load asset data.')
                return

            if anim_data.startswith(b'<roblox!'):
                try:
                    anim_data = rbxm_to_rbxmx(anim_data)
                except Exception as e:
                    QMessageBox.warning(self, 'Convert Error', f'.rbxm conversion failed: {e}')
                    return

            try:
                from ..utils.r15_to_r6 import (
                    convert_keyframe_r6_to_r15,
                    convert_keyframe_r15_to_r6,
                    sanitize_xml,
                )

                root = _ET.fromstring(sanitize_xml(anim_data))
                etree = _ET.ElementTree(root)

                ks = root.find("Item[@class='KeyframeSequence']")
                if ks is None:
                    QMessageBox.warning(self, 'Convert Error', 'No KeyframeSequence found.')
                    return
                keyframes = ks.findall("Item[@class='Keyframe']")
                if not keyframes:
                    QMessageBox.warning(self, 'Convert Error', 'No Keyframes found.')
                    return

                if target == 'R6':
                    for kf in keyframes:
                        convert_keyframe_r15_to_r6(kf, R6_PARTS, R6_JOINTS, R15_PARTS, R15_JOINTS)
                else:
                    for kf in keyframes:
                        convert_keyframe_r6_to_r15(kf, R6_PARTS, R6_JOINTS, R15_PARTS, R15_JOINTS)

                etree.write(out_str, encoding='utf-8', xml_declaration=True)
            except Exception as e:
                QMessageBox.warning(self, 'Convert Error', f'Conversion failed: {e}')

        threading.Thread(target=_do_convert, daemon=True).start()

    def _export_as_game_dump(self):
        """Export selected assets as a game dump JSON grouped by type.

        Produces {TypeName: {AssetName: assetId, ...}, ...} — the same format
        that the PreJsons Browser accepts when importing a custom dump.
        """
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        by_type: dict[str, dict] = {}
        name_counts: dict[tuple, int] = {}

        for idx in sorted(selected_rows, key=lambda x: x.row()):
            row = idx.row()
            item = self.table.item(row, 1)  # col 1 carries the asset dict in UserRole
            if not item:
                continue
            asset = item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(asset, dict):
                continue

            asset_id = asset.get('id') or asset.get('asset_id')
            try:
                asset_id = int(asset_id)
            except TypeError, ValueError:
                continue

            name = item.text() or 'Unknown'
            type_name = self.cache_manager.get_type_name_for_asset(asset_id, asset.get('type', ''))

            bucket = by_type.setdefault(type_name, {})
            key = name
            count_key = (type_name, name)
            if key in bucket:
                name_counts[count_key] = name_counts.get(count_key, 1) + 1
                key = f'{name} ({name_counts[count_key]})'
            bucket[key] = asset_id

        if not by_type:
            return

        result = {t: by_type[t] for t in sorted(by_type)}
        from PyQt6.QtWidgets import QFileDialog

        path, _ = QFileDialog.getSaveFileName(
            self,
            'Export Game Dump',
            'game_dump.json',
            'JSON Files (*.json);;All Files (*)',
        )
        if not path:
            return
        with open(path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(result, indent=2))
        total = sum(len(v) for v in result.values())
        log_buffer.log('Scraper', f'Exported game dump ({total} assets) to {path}')
        from pathlib import Path

        self._show_export_complete_message(
            'Export Complete',
            f'Exported game dump with {format_count(total, "asset")} to:\n{path}',
            [Path(path)],
        )

    def _copy_column(self, column: int):
        """Copy column contents for selected rows."""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        values = []
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, column)
            if item:
                values.append(item.text())

        if values:
            from PyQt6.QtWidgets import QApplication

            clipboard = QApplication.clipboard()
            clipboard.setText('\n'.join(values))
            log_buffer.log('Scraper', f'Copied {format_count(values, "value")} to clipboard')

    def _copy_creator_info(self, mode: str):
        """Copy creator name or creator ID for selected rows.

        Args:
            mode: 'name' to copy creator display name, 'id' to copy creator ID.
        """
        from PyQt6.QtWidgets import QApplication

        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        values = []
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, 1)  # Hash/Name carries UserRole asset data
            if not item:
                continue
            asset = item.data(Qt.ItemDataRole.UserRole)
            if not asset:
                continue
            info = self._asset_info.get(asset['id'])
            if not info:
                continue
            if mode == 'name':
                val = info.get('creator_name') or ''
            else:
                val = str(info.get('creator_id') or '')
            if val:
                values.append(val)

        if values:
            QApplication.clipboard().setText('\n'.join(values))
            label = 'creator ID' if mode == 'id' else f'creator {mode}'
            log_buffer.log('Scraper', f'Copied {format_count(values, label)} to clipboard')

    def _open_creator_in_browser(self):
        """Open the creator pages for the selected assets in the default browser."""
        import webbrowser

        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        opened = 0
        seen = set()
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, 1)
            if not item:
                continue
            asset = item.data(Qt.ItemDataRole.UserRole)
            if not asset:
                continue
            info = self._asset_info.get(asset['id'])
            if not info:
                continue
            creator_id = info.get('creator_id')
            creator_type_val = info.get('creator_type')
            # creator_type may be numeric (1=user, 2=group) or a string; normalise to a boolean
            if isinstance(creator_type_val, int):
                is_group = creator_type_val == 2
            else:
                try:
                    is_group = (
                        'group' in (str(creator_type_val) or '').lower()
                        or 'community' in (str(creator_type_val) or '').lower()
                    )
                except Exception:
                    is_group = False
            if not creator_id:
                continue
            key = (('group' if is_group else 'user'), str(creator_id))
            if key in seen:
                continue
            seen.add(key)
            try:
                if is_group:
                    url = f'https://www.roblox.com/communities/{creator_id}'
                else:
                    url = f'https://www.roblox.com/users/{creator_id}'
                webbrowser.open(url)
                opened += 1
            except Exception:
                log_buffer.log('Scraper', f'Failed to open creator {creator_id} in browser')

        if opened:
            log_buffer.log('Scraper', f'Opened {format_count(opened, "creator page")} in browser')

    def _copy_converted(self):
        """Copy converted files to clipboard as Windows file objects."""
        import tempfile
        from pathlib import Path

        from PyQt6.QtCore import QMimeData, QUrl
        from PyQt6.QtWidgets import QApplication

        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        # Only process first selected asset
        row = selected_rows[0].row()
        item = self.table.item(row, 1)
        if not item:
            return

        asset = item.data(Qt.ItemDataRole.UserRole)
        if not asset:
            return

        asset_id = asset['id']
        asset_type = asset['type']

        # Get resolved name if available
        resolved_name = None
        if asset_id in self._asset_info:
            resolved_name = self._asset_info[asset_id].get('resolved_name')

        try:
            # Get asset data
            data = self.cache_manager.get_asset(asset_id, asset_type)
            if not data:
                QMessageBox.warning(self, 'Error', f'Failed to load asset {asset_id}')
                return

            # Create temp directory for converted files
            temp_dir = Path(tempfile.gettempdir()) / 'fleasion_clipboard'
            temp_dir.mkdir(exist_ok=True)

            temp_file = None
            base_name = resolved_name if resolved_name else asset_id
            safe_base = self._sanitize_filename(base_name)

            # Convert based on type and save to temp file
            if mesh_processing.is_mesh_data(data):  # Mesh payload - save as OBJ file
                try:
                    obj_content = mesh_processing.convert(data)
                    if obj_content:
                        filename = f'{safe_base}.obj'
                        temp_file = temp_dir / filename
                        temp_file.write_text(obj_content, encoding='utf-8')
                    else:
                        QMessageBox.warning(self, 'Error', 'Failed to convert mesh to OBJ')
                        return
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'Mesh conversion error: {e}')
                    return

            elif asset_type in (1, 13):  # Image, Decal - save as PNG
                try:
                    _KTX_MAGIC = (
                        b'\xabKTX 11\xbb\r\n\x1a\n',
                        b'\xabKTX 20\xbb\r\n\x1a\n',
                    )
                    export_data = data
                    if data[:12] in _KTX_MAGIC:
                        from .tools.ktx_to_png import convert as _ktx_convert

                        converted = _ktx_convert(data)
                        if converted:
                            export_data = converted
                    filename = f'{safe_base}.png'
                    temp_file = temp_dir / filename
                    temp_file.write_bytes(export_data)
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'Image save error: {e}')
                    return

            elif asset_type == 3:  # Audio - save as OGG/MP3
                try:
                    # Determine extension
                    if data.startswith(b'OggS'):
                        ext = 'ogg'
                    elif data.startswith(b'ID3') or data.startswith(b'\xff\xfb'):
                        ext = 'mp3'
                    else:
                        ext = 'ogg'

                    filename = f'{safe_base}.{ext}'
                    temp_file = temp_dir / filename
                    temp_file.write_bytes(data)
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'Audio save error: {e}')
                    return

            elif asset_type == 24:  # Animation - save as RBXMX
                try:
                    # Decompress if needed
                    if data.startswith(b'\x1f\x8b'):
                        data = gzip_module.decompress(data)

                    filename = f'{safe_base}.rbxmx'
                    temp_file = temp_dir / filename
                    temp_file.write_bytes(data)
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'Animation save error: {e}')
                    return

            elif asset_type == 63:  # TexturePack - save XML
                try:
                    filename = f'{safe_base}_texturepack.xml'
                    temp_file = temp_dir / filename
                    temp_file.write_bytes(data)
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'TexturePack save error: {e}')
                    return

            elif asset_type == 39:  # SolidModel - convert to OBJ and save
                try:
                    import gzip as gzip_module

                    from .tools.solidmodel_converter.converter import (
                        _export_obj_from_doc,
                        deserialize_rbxm,
                    )

                    decompressed = data
                    if data.startswith(b'\x1f\x8b'):
                        decompressed = gzip_module.decompress(data)

                    # Deserialize and export to a temporary OBJ file then copy into our temp_dir
                    doc = deserialize_rbxm(decompressed)
                    with tempfile.NamedTemporaryFile(suffix='.obj', delete=False) as f:
                        temp_obj_path = Path(f.name)

                    try:
                        _export_obj_from_doc(doc, temp_obj_path, decompose=False)
                        obj_content = temp_obj_path.read_text(encoding='utf-8')
                        filename = f'{safe_base}.obj'
                        temp_file = temp_dir / filename
                        temp_file.write_text(obj_content, encoding='utf-8')
                    finally:
                        try:
                            if temp_obj_path.exists():
                                temp_obj_path.unlink()
                        except Exception:
                            pass
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'SolidModel conversion error: {e}')
                    return

            else:
                try:
                    from .roblox_document import (
                        export_roblox_document,
                        get_roblox_document_export_formats,
                    )

                    document_formats = get_roblox_document_export_formats(
                        data, asset_type=asset_type
                    )
                    if document_formats:
                        export_format = (
                            'converted_document_rbxl'
                            if 'converted_document_rbxl' in document_formats
                            else 'converted_document_rbxmx'
                        )
                        export_data, ext = export_roblox_document(
                            data, export_format, asset_type=asset_type
                        )
                        filename = f'{safe_base}{ext}'
                        temp_file = temp_dir / filename
                        temp_file.write_bytes(export_data)
                except Exception as e:
                    QMessageBox.warning(self, 'Error', f'Roblox document save error: {e}')
                    return

            # Copy file to clipboard
            if temp_file and temp_file.exists():
                mime_data = QMimeData()
                mime_data.setUrls([QUrl.fromLocalFile(str(temp_file))])
                QApplication.clipboard().setMimeData(mime_data)
                log_buffer.log('Scraper', f'Copied file to clipboard: {temp_file.name}')
                QMessageBox.information(
                    self,
                    'Success',
                    f'File copied to clipboard:\n{temp_file.name}\n\nYou can now paste it anywhere.',
                )

        except Exception as e:
            QMessageBox.warning(self, 'Error', f'Copy error: {e}')

    def _export_selected_multiple(self, export_format: str = 'converted'):
        """Export multiple selected assets."""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, 'No Selection', 'Please select assets to export')
            return

        # Collect assets to export
        assets_to_export = []
        for row_index in selected_rows:
            row = row_index.row()
            item = self.table.item(row, 1)
            if item:
                asset = item.data(Qt.ItemDataRole.UserRole)
                if asset:
                    assets_to_export.append(asset)

        if not assets_to_export:
            return

        # Export all with sanitized resolved names
        exported_count = 0
        exported_paths = []
        for asset in assets_to_export:
            asset_id = asset['id']
            resolved_name = None
            if asset_id in self._asset_info:
                resolved_name = self._asset_info[asset_id].get('resolved_name')
            safe_name = self._sanitize_filename(resolved_name) if resolved_name else None

            export_path = self.cache_manager.export_asset(
                asset['id'],
                asset['type'],
                resolved_name=safe_name,
                export_format=export_format,
            )
            if export_path:
                exported_count += 1
                exported_paths.append(export_path)

        log_buffer.log(
            'Scraper',
            f'Exported {exported_count}/{len(assets_to_export)} assets as {export_format}',
        )
        location, _ = self._get_export_open_target(exported_paths)
        self._show_export_complete_message(
            'Export Complete',
            f'Exported {format_count(exported_count, "asset")} as {export_format}\n\nLocation: {location}',
            exported_paths,
        )

    @staticmethod
    def _rbxm_asset_key(asset: dict) -> tuple[str, object]:
        return (str(asset.get('id', '')), asset.get('type'))

    @staticmethod
    def _rbxm_asset_cached_at(asset: dict) -> str:
        return str(asset.get('cached_at') or '')

    def _remember_current_rbxm_draft(self) -> None:
        key = getattr(self, '_rbxm_preview_asset_key', None)
        if key is None or not hasattr(self, 'rbxm_viewer'):
            return
        document = getattr(self.rbxm_viewer, 'document', None)
        if document is None or not self.rbxm_viewer.is_modified():
            return
        self._modified_rbxm_drafts[key] = {
            'cached_at': getattr(self, '_rbxm_preview_cached_at', ''),
            'document': document,
        }

    def _get_modified_rbxm_draft(self, asset: dict):
        self._remember_current_rbxm_draft()
        key = self._rbxm_asset_key(asset)
        draft = self._modified_rbxm_drafts.get(key)
        if not draft:
            return None
        cached_at = self._rbxm_asset_cached_at(asset)
        if draft.get('cached_at', '') != cached_at:
            self._modified_rbxm_drafts.pop(key, None)
            if key == getattr(self, '_rbxm_preview_asset_key', None):
                self._rbxm_preview_asset_key = None
                self._rbxm_preview_cached_at = ''
                try:
                    self.rbxm_viewer._set_dirty(False)
                except Exception:
                    pass
            return None
        return draft.get('document')

    def _export_modified_rbxm_asset(self, asset: dict, export_format: str):
        try:
            asset_id = str(asset.get('id', ''))
            asset_type = asset.get('type')
            draft_document = self._get_modified_rbxm_draft(asset)
            if draft_document is None:
                QMessageBox.warning(
                    self,
                    'No Changes',
                    'The selected asset has no in-memory RBXM/RBXMX modifications.',
                )
                return None

            type_name = (
                self.cache_manager.get_asset_type_name(asset_type)
                if isinstance(asset_type, int)
                else 'RBXM'
            )
            export_dir = self.cache_manager.export_dir / 'converted' / type_name
            export_dir.mkdir(parents=True, exist_ok=True)

            resolved_name = None
            if asset_id in self._asset_info:
                resolved_name = self._asset_info[asset_id].get('resolved_name')
            base_name = self._sanitize_filename(resolved_name) if resolved_name else asset_id
            suffix = '_MODIFIED'

            if export_format == 'converted_modified_rbxm':
                data = self.rbxm_viewer.export_rbxm_bytes(draft_document)
                output_path = export_dir / f'{base_name}{suffix}.rbxm'
            else:
                data = self.rbxm_viewer.export_rbxmx_bytes(draft_document)
                output_path = export_dir / f'{base_name}{suffix}.rbxmx'

            output_path.write_bytes(data)
            log_buffer.log('Scraper', f'Exported modified RBXM/RBXMX to {output_path}')
            return output_path
        except Exception as e:
            QMessageBox.warning(self, 'Export Error', f'Failed to export modified RBXM/RBXMX: {e}')
            log_buffer.log('Scraper', f'Failed to export modified RBXM/RBXMX: {e}')
            return None

    def _add_selected_to_replacer(self):
        """Add selected asset IDs to replacer."""
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            return

        asset_ids = []
        for row_index in selected_rows:
            row = row_index.row()
            # Asset ID is in column 3 (columns: 0 marker, 1 Hash/Name, 2 Creator, 3 Asset ID)
            id_item = self.table.item(row, 3)
            if id_item:
                asset_ids.append(id_item.text())

        if not asset_ids:
            return

        replacer_window = getattr(self, '_replacer_window_ref', None)
        if replacer_window:
            # Add to existing IDs if there are any
            current_text = replacer_window.replace_entry.text().strip()
            if current_text:
                new_text = current_text + ', ' + ', '.join(asset_ids)
            else:
                new_text = ', '.join(asset_ids)
            replacer_window.replace_entry.setText(new_text)

            log_buffer.log('Scraper', f'Added {format_count(asset_ids, "asset ID")} to replacer')
            QMessageBox.information(
                self,
                'Added to Replacer',
                f'Added {format_count(asset_ids, "asset ID")} to replacer:\n{", ".join(asset_ids[:5])}{"..." if len(asset_ids) > 5 else ""}',
            )
        else:
            # Fallback: copy to clipboard if not in replacer window
            from PyQt6.QtWidgets import QApplication

            clipboard = QApplication.clipboard()
            clipboard.setText(', '.join(asset_ids))

            log_buffer.log('Scraper', f'Copied {format_count(asset_ids, "asset ID")} to clipboard')
            QMessageBox.information(
                self,
                'Copied to Clipboard',
                f'Copied {format_count(asset_ids, "asset ID")} to clipboard:\n{", ".join(asset_ids[:5])}{"..." if len(asset_ids) > 5 else ""}',
            )

    def _add_latest_as_replace_with(self):
        """Send the latest selected asset ID to the Replace With field."""
        row = self.table.currentIndex().row()
        if row < 0:
            return

        id_item = self.table.item(row, 3)
        if not id_item:
            return
        asset_id = id_item.text()

        replacer_window = getattr(self, '_replacer_window_ref', None)
        if replacer_window:
            replacer_window.replacement_entry.setText(asset_id)
            log_buffer.log('Scraper', f'Set Replace With to asset ID {asset_id}')
            QMessageBox.information(
                self,
                'Replace With Set',
                f'Replace With set to asset ID {asset_id}',
            )
        else:
            from PyQt6.QtWidgets import QApplication

            QApplication.clipboard().setText(asset_id)
            log_buffer.log(
                'Scraper',
                f'Copied asset ID {asset_id} to clipboard (no replacer window found)',
            )
            QMessageBox.information(
                self,
                'Copied to Clipboard',
                f'Copied asset ID {asset_id} to clipboard',
            )

    def _stop_preview(self):
        """Stop current preview and hide button."""
        self._selected_asset_id = None
        self._clear_preview()
        self.stop_preview_btn.hide()
        self.table.clearSelection()
        self.table.setCurrentItem(None)
        # Show default preview message
        self.image_label.setText('Select an asset to preview')
        self.image_label.show()

    def _clear_preview(self):
        """Clear all preview widgets and stop any running loaders."""
        self._remember_current_rbxm_draft()

        # Stop all worker threads first
        self._stop_all_loaders()

        # Hide and clear UI widgets
        self.obj_viewer.hide()
        self.obj_viewer.clear()
        self.image_label.clear()

        # Completely hide the preview window as requested
        self.preview_panel.hide()
        # Reset preview group title back to default
        try:
            if hasattr(self, 'preview_group'):
                self.preview_title_label.setText('Preview')
        except Exception:
            pass

        # Deselect currently tracked asset in tree/internal state
        self._selected_asset_id = None
        self.table.clearSelection()
        self.table.setCurrentItem(None)

        self._current_pixmap = None
        self.audio_wrapper.hide()
        if self.audio_player:
            self.audio_player.stop()
            self.audio_player.deleteLater()
            self.audio_player = None
        self.animation_viewer.hide()
        self.animation_viewer.clear()
        self.text_viewer.hide()
        self.text_viewer.clear()
        self.rbxm_viewer.hide()
        self.rbxm_viewer.clear()
        self._rbxm_preview_asset_key = None
        self._rbxm_preview_cached_at = ''
        self.rbxm_view_btn.hide()

        # Clean up texture pack widgets
        if self.texturepack_widget is not None:
            self.texturepack_widget.deleteLater()
            self.texturepack_widget = None

    def _stop_all_loaders(self):
        """Stop all running preview loader threads."""
        if self._image_loader is not None:
            self._image_loader.stop()
            self._image_loader.quit()
            self._image_loader.wait()
            self._image_loader = None

        if self._mesh_loader is not None:
            self._mesh_loader.stop()
            self._mesh_loader.quit()
            self._mesh_loader.wait()
            self._mesh_loader = None

        if self._animation_loader is not None:
            self._animation_loader.stop()
            self._animation_loader.quit()
            self._animation_loader.wait()
            self._animation_loader = None

        if self._texturepack_loader is not None:
            self._texturepack_loader.stop()
            self._texturepack_loader.quit()
            self._texturepack_loader.wait()
            self._texturepack_loader = None

    def eventFilter(self, obj, event):
        """Global event filter to catch space key and toggle audio play/pause."""
        try:
            if event.type() == QEvent.Type.KeyPress:
                # Space toggles play/pause when audio preview is active
                if event.key() == Qt.Key.Key_Space:
                    from PyQt6.QtWidgets import QApplication

                    focus_widget = QApplication.focusWidget()
                    if isinstance(focus_widget, (QLineEdit, QTextEdit, QPlainTextEdit)):
                        return super().eventFilter(obj, event)

                    if self.audio_player and self.audio_wrapper.isVisible():
                        try:
                            # Toggle play/pause on the audio widget
                            self.audio_player._toggle_play_pause()
                        except Exception:
                            pass
                        return True
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def _remove_audio_key_filter(self):
        """Remove global audio key event filter if installed."""
        try:
            if self._audio_key_filter_installed:
                from PyQt6.QtWidgets import QApplication

                QApplication.instance().removeEventFilter(self)
                self._audio_key_filter_installed = False
        except Exception:
            pass

    def _on_splitter_moved(self, pos: int, index: int):
        """Handle splitter resize to rescale image."""
        if self._current_pixmap is not None and self.image_label.isVisible():
            self._scale_and_show_image(self._current_pixmap)

    def _show_loading(self):
        """Show loading indicator."""
        self.loading_label.show()

    def _hide_loading(self):
        """Hide loading indicator."""
        self.loading_label.hide()

    def _swap_to_rbxm_view(self):
        """Switch the current Animation/SolidModel preview to raw RBXM structure."""
        asset = self._get_selected_asset()
        if not asset:
            return
        asset_type = asset.get('type')
        if asset_type not in (24, 39):
            return
        asset_id = asset.get('id')
        data = self.cache_manager.get_asset(asset_id, asset_type)
        if not data or not is_rbx_model_data(data):
            return

        self._stop_all_loaders()
        self.obj_viewer.hide()
        self.image_label.hide()
        self.loading_label.hide()
        self.audio_wrapper.hide()
        self.animation_viewer.hide()
        self.animation_viewer.stop()
        self.text_viewer.hide()
        self.json_viewer.hide()
        self.font_wrapper.hide()
        self.rbxm_view_btn.hide()

        title = 'Animation structure' if asset_type == 24 else 'SolidModel structure'
        self._preview_rbxm(data, asset, title_prefix=title)

    def _preview_mesh(self, data: bytes, asset_id: str):
        """Preview a mesh asset in 3D using background thread."""
        # Track which asset this loader is for so we can ignore stale results
        self._mesh_loader_asset_id = asset_id
        self._mesh_loader = MeshLoaderThread(data, asset_id)
        self._mesh_loader.mesh_ready.connect(self._on_mesh_ready)
        self._mesh_loader.error.connect(lambda e: self._show_text_preview(f'Mesh error: {e}'))
        self._mesh_loader.start()

    def _on_mesh_ready(self, obj_content: str):
        """Handle mesh loaded from background thread."""
        # Ignore if selection has changed since loader started
        try:
            if getattr(self, '_mesh_loader_asset_id', None) != self._selected_asset_id:
                log_buffer.log('Preview', 'Stale mesh result ignored')
                return
        except Exception:
            pass

        self._hide_loading()
        self.obj_viewer.load_obj(obj_content, '')
        self.obj_viewer.show()
        self.stop_preview_btn.show()

    def _preview_solidmodel(self, data: bytes, asset_id: str):
        """Preview a SolidModel asset in 3D using background thread."""
        # Track which asset this loader is for so we can ignore stale results
        self._mesh_loader_asset_id = asset_id
        self._mesh_loader = SolidModelLoaderThread(data, asset_id)
        self._mesh_loader.mesh_ready.connect(self._on_mesh_ready)
        self._mesh_loader.error.connect(
            lambda e, d=data, aid=asset_id: self._on_solidmodel_preview_error(d, aid, e)
        )
        self._mesh_loader.start()

    def _on_solidmodel_preview_error(self, data: bytes, asset_id: str, error: str):
        """Fallback from 3D SolidModel preview to the RBXM structure viewer."""
        if getattr(self, '_selected_asset_id', None) != asset_id:
            log_buffer.log('Preview', 'Stale SolidModel error ignored')
            return
        if is_rbx_model_data(data):
            self._preview_rbxm(
                data,
                {'id': asset_id, 'type': 39, 'type_name': 'SolidModel'},
                title_prefix='SolidModel structure',
            )
            return
        self._show_text_preview(f'SolidModel error: {error}')

    def _preview_image(self, data: bytes):
        """Preview an image asset using background thread."""
        # Track current selection so we ignore stale image results
        self._image_loader_asset_id = getattr(self, '_selected_asset_id', None)
        self._image_loader = ImageLoaderThread(data)
        self._image_loader.image_ready.connect(self._on_image_ready)
        self._image_loader.error.connect(lambda e: self._show_text_preview(f'Image error: {e}'))
        self._image_loader.start()

    def _on_image_ready(self, pixmap: QPixmap):
        """Handle image loaded from background thread."""
        # Ignore if selection has changed since loader started
        try:
            if getattr(self, '_image_loader_asset_id', None) != self._selected_asset_id:
                log_buffer.log('Preview', 'Stale image result ignored')
                return
        except Exception:
            pass

        self._hide_loading()
        self._current_pixmap = pixmap
        self._scale_and_show_image(pixmap)
        self.image_label.show()
        self.stop_preview_btn.show()

    def _scale_and_show_image(self, pixmap: QPixmap):
        """Scale pixmap to fit container and display it."""
        container_width = self.preview_scroll.viewport().width() - 20
        container_height = self.preview_scroll.viewport().height() - 20

        if container_width < 100:
            container_width = 400
        if container_height < 100:
            container_height = 400

        # Scale to fit within container while maintaining aspect ratio
        scaled = pixmap.scaled(
            container_width,
            container_height,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )

        self.image_label.setPixmap(scaled)

    def _show_image_context_menu(self, pos):
        """Show context menu for image preview."""
        if self._current_pixmap is None or self._current_pixmap.isNull():
            return

        menu = QMenu(self)
        copy_action = menu.addAction('Copy Image')

        action = menu.exec(self.image_label.mapToGlobal(pos))
        if action == copy_action:
            copy_pixmap_to_clipboard(self._current_pixmap)

    def _preview_texturepack(self, data: bytes, asset_id: str):
        """Preview a texture pack by showing all texture maps."""
        import xml.etree.ElementTree as ET

        try:
            # Clean up previous texture pack if any
            if self.texturepack_widget is not None:
                self.texturepack_widget.deleteLater()
                self.texturepack_widget = None
            if self._texturepack_loader is not None:
                self._texturepack_loader.stop()
                self._texturepack_loader.quit()
                self._texturepack_loader.wait()
                self._texturepack_loader = None

            # Parse XML to get texture map IDs
            xml_text = data.decode('utf-8', errors='replace')
            self._texturepack_xml = xml_text  # Store for context menu
            root = ET.fromstring(xml_text)

            # Extract texture map IDs using the GLOBAL fixed index system.
            # The index for each map type is constant regardless of the asset's
            # XML tag ordering:
            #   0 = Color, 1 = Normal, 2 = Metalness, 3 = Roughness,
            #   4 = Emissive, 5 = Height
            # These global indices are what the user puts in replace_ids
            # (e.g. "108049038086346:3" for roughness on ANY pack).
            # GI ≥ 2 are routed through the ORM compositor on the backend.
            _TAG_TO_GLOBAL_INDEX = {
                'color': 0,
                'albedo': 0,
                'diffuse': 0,
                'basecolor': 0,
                'normal': 1,
                'normalmap': 1,
                'bumpmap': 1,
                'metalness': 2,
                'orm': 2,
                'roughness': 3,
                'emissive': 4,
                'emissivemap': 4,
                'height': 5,
                'heightmap': 5,
                'displacement': 5,
            }
            maps = {}  # display_name -> map_id_str
            maps_indices = {}  # display_name -> global_index (fixed, asset-independent)
            for child in root:
                tag_lower = child.tag.lower().lstrip('{').split('}')[-1]
                global_idx = _TAG_TO_GLOBAL_INDEX.get(tag_lower)
                if global_idx is None:
                    continue
                text = (child.text or '').strip()
                if text.isdigit() and text != '0':
                    display_name = tag_lower.capitalize()
                    maps[display_name] = text
                    maps_indices[display_name] = global_idx

            if not maps:
                self._show_text_preview(f'No texture maps found in texture pack {asset_id}')
                return

            # Clear texture data storage
            self._texturepack_data = {}

            # Create container widget for texture pack preview
            self.texturepack_widget = QWidget()
            tp_layout = QVBoxLayout()
            tp_layout.setContentsMargins(0, 0, 0, 0)
            tp_layout.setSpacing(10)

            # Store references for async loading
            self._tp_image_labels = {}
            self._tp_pixmaps = {}  # Store pixmaps for copy

            # Create placeholder for each texture map
            for map_name, map_id in maps.items():
                map_index = maps_indices.get(map_name, '?')
                slot_key = f'{asset_id}:{map_index}'
                # Header: Name  |  sub-asset ID  |  slot X  (slot X is what goes in replace_ids)
                header = QLabel(f'{map_name}  |  {asset_id}:{map_index}')
                header.setStyleSheet('font-weight: bold; color: #888; padding: 5px;')
                header.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
                tp_layout.addWidget(header)

                # Image placeholder with context menu
                img_label = QLabel('Loading...')
                img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
                img_label.setStyleSheet(
                    'background-color: palette(base); padding: 10px; min-height: 100px;'
                )
                img_label.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
                img_label.setProperty('map_name', map_name)
                img_label.setProperty('map_id', map_id)
                img_label.setProperty('map_index', map_index)
                img_label.setProperty('slot_key', slot_key)
                img_label.customContextMenuRequested.connect(
                    lambda pos, lbl=img_label: self._show_texturepack_context_menu(pos, lbl)
                )
                tp_layout.addWidget(img_label)
                self._tp_image_labels[map_name] = img_label

            tp_layout.addStretch()
            self.texturepack_widget.setLayout(tp_layout)
            self.preview_container_layout.addWidget(self.texturepack_widget)
            self.texturepack_widget.show()
            self.stop_preview_btn.show()

            # Start async loading of textures
            self._texturepack_loader = TexturePackLoaderThread(
                maps, self.cache_manager, self.cache_scraper
            )
            self._texturepack_loader.texture_loaded.connect(self._on_texturepack_texture_loaded)
            self._texturepack_loader.texture_error.connect(self._on_texturepack_texture_error)
            self._texturepack_loader.start()

        except Exception as e:
            self._show_text_preview(f'Texture pack preview error: {e}')

    def _on_texturepack_texture_loaded(
        self, map_name: str, map_id: str, hash_val: str, data: bytes
    ):
        """Handle loaded texture from texture pack."""
        # Hide loading on first texture
        self._hide_loading()

        try:
            if map_name not in self._tp_image_labels:
                return

            img_label = self._tp_image_labels[map_name]

            # Check if widget still exists
            try:
                _ = img_label.isVisible()
            except RuntimeError:
                return

            # Store texture data for context menu
            self._texturepack_data[map_name] = {
                'id': map_id,
                'hash': hash_val,
                'data': data,
            }
            # Update label property with hash
            img_label.setProperty('map_hash', hash_val)

            # Load image
            image = Image.open(io.BytesIO(data))
            if image.mode not in ('RGB', 'RGBA'):
                image = image.convert('RGBA')
            elif image.mode == 'RGB':
                image = image.convert('RGBA')

            # Scale up small images to 512x512 minimum
            min_size = 512
            if image.width < min_size or image.height < min_size:
                # Scale to at least 512 on the smaller dimension
                scale_factor = max(min_size / image.width, min_size / image.height)
                new_width = int(image.width * scale_factor)
                new_height = int(image.height * scale_factor)
                image = image.resize((new_width, new_height), Image.Resampling.NEAREST)

            qimage = QImage(
                image.tobytes(),
                image.width,
                image.height,
                QImage.Format.Format_RGBA8888,
            )
            pixmap = QPixmap.fromImage(qimage)

            # Store original pixmap for copy
            self._tp_pixmaps[map_name] = pixmap

            # Scale to fit container
            container_width = self.preview_scroll.viewport().width() - 30
            if container_width < 100:
                container_width = 400

            if pixmap.width() > container_width:
                scaled = pixmap.scaledToWidth(
                    container_width, Qt.TransformationMode.SmoothTransformation
                )
            else:
                scaled = pixmap

            img_label.setPixmap(scaled)
            img_label.setStyleSheet('')

        except Exception as e:
            self._on_texturepack_texture_error(map_name, str(e))

    def _on_texturepack_texture_error(self, map_name: str, error: str):
        """Handle texture load error."""
        try:
            if map_name not in self._tp_image_labels:
                return

            img_label = self._tp_image_labels[map_name]

            try:
                _ = img_label.isVisible()
            except RuntimeError:
                return

            img_label.setText(f'Error: {error}')
            img_label.setStyleSheet('color: #ff6b6b; padding: 10px;')
        except Exception:
            pass

    def _show_texturepack_context_menu(self, pos, label: QLabel):
        """Show context menu for texturepack image."""
        from PyQt6.QtWidgets import QApplication

        map_name = label.property('map_name')
        map_id = label.property('map_id')
        map_hash = label.property('map_hash') or ''
        slot_key = label.property('slot_key') or ''

        menu = QMenu(self)

        # Copy image
        copy_image_action = menu.addAction('Copy Image')

        menu.addSeparator()

        # Copy name/slot-key/sub-asset-id/hash
        copy_name_action = menu.addAction(f'Copy Name ({map_name})')
        # "Copy ID" intentionally copies slot key, because this is the exact
        # value users should paste into replace_ids for per-slot replacement.
        copy_id_action = menu.addAction(f'Copy ID ({slot_key}) (Use this for Replacer)')
        copy_subasset_action = menu.addAction(f'Copy Sub-Asset ID ({map_id}) (Cannot be Replaced)')
        copy_hash_action = None
        if map_hash:
            copy_hash_action = menu.addAction(f'Copy Hash ({map_hash[:16]}...)')

        menu.addSeparator()

        # Copy XML
        copy_xml_action = menu.addAction('Copy TexturePack XML')

        menu.addSeparator()

        # Export raw per-slot KTX2 files captured during game session.
        export_slot_ktx2_action = menu.addAction('Export Slot KTX2 Files')

        action = menu.exec(label.mapToGlobal(pos))

        if action == copy_image_action:
            pixmap = self._tp_pixmaps.get(map_name)
            if pixmap and not pixmap.isNull():
                copy_pixmap_to_clipboard(pixmap)
        elif action == copy_name_action:
            QApplication.clipboard().setText(map_name)
        elif action == copy_id_action:
            QApplication.clipboard().setText(slot_key)
        elif action == copy_subasset_action:
            QApplication.clipboard().setText(str(map_id))
        elif action == copy_hash_action and map_hash:
            QApplication.clipboard().setText(map_hash)
        elif action == copy_xml_action:
            QApplication.clipboard().setText(self._texturepack_xml)
        elif action == export_slot_ktx2_action:
            self._export_texpack_slot_ktx2(slot_key.split(':')[0] if ':' in slot_key else '')

    def _export_texpack_slot_ktx2(self, asset_id: str) -> None:
        """Export high-quality per-slot KTX2 files for a TexturePack.

        Exports whichever quality level has been captured so far from
        APP_CACHE_DIR/texpack_slots/<asset_id>_slot{N}.ktx2.
        """
        if not asset_id:
            return
        from PyQt6.QtWidgets import QFileDialog

        from ..utils import APP_CACHE_DIR

        slot_dir = APP_CACHE_DIR / 'texpack_slots'
        _SLOT_NAMES = {0: 'Color', 1: 'Normal', 2: 'ORM'}
        found = []
        for slot, name in _SLOT_NAMES.items():
            src = slot_dir / f'{asset_id}_slot{slot}.ktx2'
            if src.exists():
                found.append((src, f'{asset_id}_slot{slot}_{name}.ktx2'))

        if not found:
            from PyQt6.QtWidgets import QMessageBox

            QMessageBox.information(
                self,
                'No Slot KTX2 Files',
                f'No slot KTX2 files found for pack {asset_id}.\n\n'
                'Load the asset in-game while Fleasion is running to capture them.',
            )
            return

        dest_dir_str = QFileDialog.getExistingDirectory(
            self,
            f'Export Slot KTX2 for {asset_id}',
            str(APP_CACHE_DIR),
        )
        if not dest_dir_str:
            return
        from pathlib import Path as _Path

        dest_dir = _Path(dest_dir_str)
        exported = []
        for src, dest_name in found:
            dst = dest_dir / dest_name
            import shutil

            shutil.copy2(str(src), str(dst))
            exported.append(dest_name)
        self._show_export_complete_message(
            'Export Complete',
            f'Exported {format_count(exported, "slot KTX2 file")} to:\n{dest_dir}\n\n'
            + '\n'.join(exported),
            [dest_dir / name for name in exported],
        )

    def _preview_audio(self, data: bytes, asset_id: str):
        """Preview an audio asset."""
        import tempfile
        from pathlib import Path

        try:
            # Track asset id for this audio preview to avoid stale UI updates
            self._audio_preview_asset_id = asset_id

            # If selection changed since request, abort
            if getattr(self, '_selected_asset_id', None) != asset_id:
                log_buffer.log('Preview', 'Ignored stale audio preview request')
                return
            # Create temporary file for audio
            temp_dir = Path(tempfile.gettempdir()) / 'fleasion_audio'
            temp_dir.mkdir(exist_ok=True)

            # Determine file extension.
            ext = self.cache_manager._detect_extension(data, 3)
            if ext not in ('.ogg', '.mp3', '.wav', '.flac'):
                ext = '.mp3'
            temp_file = temp_dir / f'{asset_id}{ext}'

            # Write audio data to temp file
            with open(temp_file, 'wb') as f:
                f.write(data)

            # Create audio player with config manager for volume persistence
            self.audio_player = AudioPlayerWidget(str(temp_file), self, self.config_manager)

            # Clear previous audio widgets
            while self.audio_container_layout.count():
                child = self.audio_container_layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()

            # Add new audio player
            # Ensure selection is still the same asset before showing
            if getattr(self, '_selected_asset_id', None) != asset_id:
                try:
                    self.audio_player.deleteLater()
                except Exception:
                    pass
                # Ensure we don't keep a dangling reference
                try:
                    self.audio_player = None
                except Exception:
                    pass
                log_buffer.log('Preview', 'Aborted adding audio widget for stale selection')
                return

            self.audio_container_layout.addWidget(self.audio_player)
            self._hide_loading()
            self.audio_wrapper.show()
            self.stop_preview_btn.show()

            # Install global event filter to catch Space for play/pause while audio preview is active
            try:
                from PyQt6.QtWidgets import QApplication

                QApplication.instance().installEventFilter(self)
                self._audio_key_filter_installed = True
            except Exception:
                self._audio_key_filter_installed = False

            # When audio stops or widget is deleted, remove the event filter
            try:
                self.audio_player.stopped.connect(lambda: self._remove_audio_key_filter())
            except Exception:
                pass

        except Exception as e:
            self._show_text_preview(f'Audio preview error: {e}')
            log_buffer.log('Scraper', f'Audio preview error: {e}')

    def _preview_animation(self, data: bytes, asset_id: str):
        """Preview an animation asset (RBXM XML format) using background thread."""
        # Track which asset this animation loader is for
        self._animation_loader_asset_id = asset_id
        self._show_loading()
        self._animation_loader = AnimationLoaderThread(data, asset_id)
        self._animation_loader.animation_ready.connect(self._on_animation_ready)
        self._animation_loader.error.connect(
            lambda e: self._show_text_preview(f'Animation error: {e}')
        )
        self._animation_loader.start()

    def _on_animation_ready(self, data: bytes):
        """Handle animation data ready from background thread."""
        # Ignore if selection changed since loader started
        try:
            if getattr(self, '_animation_loader_asset_id', None) != self._selected_asset_id:
                log_buffer.log('Preview', 'Stale animation result ignored')
                return
        except Exception:
            pass

        self._hide_loading()
        try:
            # Load in the animation viewer (must be on main thread for OpenGL)
            if self.animation_viewer.load_animation(data):
                self.animation_viewer.show()
                self.stop_preview_btn.show()
                return

            if is_rbx_model_data(data):
                asset_id = getattr(self, '_animation_loader_asset_id', '') or ''
                self._preview_rbxm(
                    data,
                    {'id': asset_id, 'type': 24, 'type_name': 'Animation'},
                    title_prefix='Animation structure',
                )
                return

            # Fallback: try to decode as XML for text display
            text = data.decode('utf-8', errors='replace')

            # Check if it's XML
            if text.strip().startswith('<'):
                # Format XML for display
                import xml.etree.ElementTree as ET

                try:
                    ET.fromstring(data)
                    # Pretty print XML
                    import xml.dom.minidom

                    dom = xml.dom.minidom.parseString(data)
                    pretty_xml = dom.toprettyxml(indent='  ')
                    # Remove extra blank lines
                    lines = [line for line in pretty_xml.split('\n') if line.strip()]
                    self._show_text_preview('\n'.join(lines[:500]))  # Limit lines
                except Exception:
                    # Fallback to raw text
                    self._show_text_preview(
                        f'Animation data\nSize: {self._format_size(len(data))}\n\n{text[:5000]}'
                    )
            else:
                # Binary format, show hex
                reason = 'This animation could not be loaded because it appears to be an unrecognized or unsupported animation format.'
                self._preview_hex(data, {'id': '', 'type_name': 'Animation'}, reason=reason)

        except Exception as e:
            self._show_text_preview(f'Animation preview error: {e}')

    def _preview_font(self, data: bytes):
        """Preview a font asset (TTF, OTF, TTC)."""
        try:
            log_buffer.log('Preview', f'Loading font ({len(data)} bytes)')

            # Create font viewer widget
            font_viewer = FontViewerWidget(data, self)

            # Clear previous font widgets
            while self.font_container_layout.count():
                child = self.font_container_layout.takeAt(0)
                if child.widget():
                    child.widget().deleteLater()

            # Add new font viewer
            self.font_container_layout.addWidget(font_viewer)
            self.font_wrapper.show()
            self.stop_preview_btn.show()

        except Exception as e:
            self._show_text_preview(f'Font preview error: {e}')
            log_buffer.log('Preview', f'Font preview error: {e}')

    def _is_json_data(self, data: bytes) -> tuple[bool, dict | list | None]:
        """
        Detect if binary data is valid JSON.

        Returns:
            tuple: (is_json: bool, parsed_data: dict|list|None)
        """
        if not data or len(data) < 2:
            return False, None

        # Check for gzip compression
        if data[:2] == b'\x1f\x8b':
            try:
                data = gzip_module.decompress(data)
            except Exception:
                return False, None

        # Try UTF-8 decoding first (most common)
        for encoding in ['utf-8', 'utf-16', 'utf-16-le', 'utf-16-be']:
            try:
                text = data.decode(encoding)
                parsed = json.loads(text)
                return True, parsed
            except UnicodeDecodeError, json.JSONDecodeError:
                continue

        return False, None

    def _preview_rbxm(self, data: bytes, asset: dict, title_prefix: str = 'RBXM/RBXMX structure'):
        """Display an RBXM/RBXMX instance/property structure preview."""
        try:
            asset_id = str(asset.get('id', ''))
            asset_type = asset.get('type')
            type_name = asset.get('type_name') or (
                self.cache_manager.get_asset_type_name(asset_type)
                if isinstance(asset_type, int)
                else 'RBXM/RBXMX'
            )
            asset_label = f'{type_name} {asset_id}'.strip()
            asset_key = self._rbxm_asset_key(asset)
            cached_at = self._rbxm_asset_cached_at(asset)
            if not cached_at:
                selected_asset = self._get_selected_asset()
                if selected_asset and self._rbxm_asset_key(selected_asset) == asset_key:
                    cached_at = self._rbxm_asset_cached_at(selected_asset)
                    asset = dict(asset)
                    asset['cached_at'] = cached_at

            draft_document = self._get_modified_rbxm_draft(asset)
            if draft_document is not None:
                self.rbxm_viewer.load_document(draft_document, asset_label=asset_label, dirty=True)
            else:
                self.rbxm_viewer.load_bytes(data, asset_label=asset_label)
            self._rbxm_preview_asset_key = asset_key
            self._rbxm_preview_cached_at = cached_at

            # Persist detected type only after a successful parse, matching JSON detection behavior.
            try:
                if isinstance(asset_type, int) and self.cache_manager.get_asset_type_name(
                    asset_type
                ).startswith('Unknown'):
                    self.cache_manager.set_detected_type(asset_id, asset_type, 'RBXM/RBXMX')
                    current_row = self.table.currentRow()
                    if current_row >= 0:
                        type_item = self.table.item(current_row, 4)
                        if type_item:
                            type_item.setText('RBXM/RBXMX')
            except Exception:
                pass

            self._hide_loading()
            self.rbxm_viewer.show()
            self.stop_preview_btn.show()
            try:
                self.preview_title_label.setText(title_prefix)
            except Exception:
                pass
        except Exception as e:
            self._preview_hex(
                data,
                {
                    'id': asset.get('id', ''),
                    'type_name': asset.get('type_name', 'RBXM/RBXMX'),
                },
                reason=f'RBXM/RBXMX structure parse failed: {e}',
            )

    def _preview_json(self, data: bytes, asset: dict):
        """Display JSON data in the JSON viewer."""
        is_json, parsed_data = self._is_json_data(data)

        if not is_json or parsed_data is None:
            # Fallback to hex dump
            self._preview_hex(data, asset)
            return

        # Persist the detected JSON type to the cache index
        asset_id = asset['id']
        asset_type = asset['type']
        try:
            self.cache_manager.set_detected_type(asset_id, asset_type, 'Json')

            # Update the table type display immediately to show "Json"
            current_row = self.table.currentRow()
            if current_row >= 0:
                type_item = self.table.item(current_row, 4)  # Type column is index 4
                if type_item:
                    # Update to 'Json' (now persistent)
                    type_item.setText('Json')
        except Exception:
            pass

        # Load and display in JSON viewer
        self.json_viewer.load_json(parsed_data)
        self._hide_loading()
        self.json_viewer.show()
        self.stop_preview_btn.show()

    def _preview_hex(self, data: bytes, asset: dict, reason: str = None):
        """Show hex dump preview."""
        # Show first 1KB as hex dump
        preview_size = min(1024, len(data))
        hex_lines = []

        hex_lines.append(f'Asset ID: {asset["id"]}')
        hex_lines.append(f'Type: {asset["type_name"]}')
        hex_lines.append(f'Size: {self._format_size(len(data))}')
        if reason:
            hex_lines.append(f'\nWhy is this a Hex Dump?: {reason}')
        hex_lines.append(f'\nFirst {preview_size} bytes (hex dump):\n')

        for i in range(0, preview_size, 16):
            hex_part = ' '.join(f'{b:02x}' for b in data[i : i + 16])
            ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in data[i : i + 16])
            hex_lines.append(f'{i:08x}  {hex_part:<48}  {ascii_part}')

        if len(data) > preview_size:
            hex_lines.append(f'\n... ({len(data) - preview_size} more bytes)')

        self._show_text_preview('\n'.join(hex_lines))
        mono_font = QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont)
        self.text_viewer.setFont(mono_font)
        self.text_viewer.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)

    def _show_text_preview(self, text: str):
        """Show text in the text viewer."""
        self._hide_loading()
        self.text_viewer.setFont(self._text_viewer_default_font)
        self.text_viewer.setLineWrapMode(self._text_viewer_default_wrap)
        self.text_viewer.setPlainText(text)
        self.text_viewer.show()
        self.stop_preview_btn.show()

    # ------------------------------------------------------------------
    # Load Asset dialog
    # ------------------------------------------------------------------

    def _show_blacklist_dialog(self):
        """Show a dialog for managing blacklisted asset IDs."""
        from ..utils import get_icon_path

        dialog = QDialog(self)
        dialog.setWindowTitle('Blacklist IDs')
        dialog.resize(400, 350)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            dialog.setWindowIcon(QIcon(str(icon_path)))

        layout = QVBoxLayout()

        title = QLabel('Blacklisted Asset IDs')
        title.setStyleSheet('font-weight: bold;')
        layout.addWidget(title)

        hint = QLabel('Enter asset IDs separated by commas, spaces, newlines, or semicolons.')
        hint.setStyleSheet('color: gray; font-size: 9pt;')
        hint.setWordWrap(True)
        layout.addWidget(hint)

        text_edit = QTextEdit()
        text_edit.setAcceptRichText(False)
        text_edit.setPlaceholderText('e.g. 1818, 1234567890, 9876543210')

        # Populate with current blacklist
        if self._blacklisted_ids:
            text_edit.setPlainText(', '.join(sorted(self._blacklisted_ids, key=lambda x: int(x))))
        layout.addWidget(text_edit)

        # Search row
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 0)
        search_edit = QLineEdit()
        search_edit.setPlaceholderText('Search IDs')
        search_layout.addWidget(search_edit)
        # Push the following widgets to the right side
        search_layout.addStretch()
        status_label = QLabel('')
        status_label.setStyleSheet('color: #888; font-size: 9pt;')
        search_layout.addWidget(status_label)
        apply_btn = QPushButton('Apply blacklist')
        search_layout.addWidget(apply_btn)
        layout.addLayout(search_layout)

        dialog.setLayout(layout)

        _last_search_query = ['']

        def _search_id():
            query = search_edit.text().strip()
            if not query:
                return
            # If query changed, reset search to start from beginning
            if query != _last_search_query[0]:
                _last_search_query[0] = query
                text_edit.moveCursor(text_edit.textCursor().MoveOperation.Start)
            # Search from current cursor position forward
            cursor = text_edit.document().find(query, text_edit.textCursor())
            if cursor.isNull():
                # Wrap around to start
                cursor = text_edit.document().find(query)
            if not cursor.isNull():
                text_edit.setTextCursor(cursor)
                text_edit.ensureCursorVisible()
                status_label.setText('')
            else:
                status_label.setText(f'ID {query} not found.')
                status_label.setStyleSheet('color: #cc5555; font-size: 9pt;')

        search_edit.returnPressed.connect(_search_id)
        search_edit.textChanged.connect(lambda: status_label.setText(''))

        def _apply():
            content = text_edit.toPlainText().strip()
            content = content.replace('\n', ',').replace(';', ',').replace(' ', ',')
            ids = []
            for part in content.split(','):
                part = part.strip()
                if part:
                    try:
                        ids.append(str(int(part)))
                    except ValueError:
                        pass
            self._blacklisted_ids = set(ids)
            if self.config_manager is not None:
                self.config_manager.scraper_blacklist = ids
            # Fast path: hide/show rows in-place rather than full repopulate
            for row in range(self.table.rowCount()):
                id_item = self.table.item(row, 1)
                if id_item is None:
                    continue
                asset_data = id_item.data(Qt.ItemDataRole.UserRole)
                asset_id = asset_data.get('id') if isinstance(asset_data, dict) else None
                self.table.setRowHidden(row, asset_id in self._blacklisted_ids)
            count = len(self._blacklisted_ids)
            status_label.setText(f'Blacklist applied: {format_count(count, "ID")}.')
            status_label.setStyleSheet('color: #55cc55; font-size: 9pt;')
            if self._blacklisted_ids:
                log_buffer.log(
                    'Scraper',
                    f'Blacklist updated: {format_count(count, "ID")} active — {", ".join(sorted(self._blacklisted_ids, key=lambda x: int(x) if x.isdigit() else 0))}',
                )
            else:
                log_buffer.log('Scraper', 'Blacklist cleared')

        apply_btn.clicked.connect(_apply)

        dialog.exec()

    def _show_load_asset_dialog(self):
        """Show a dialog for manually entering asset IDs to download from Roblox."""
        from ..utils import get_icon_path

        dialog = QDialog(self)
        dialog.setWindowTitle('Load Assets')
        dialog.resize(400, 350)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            dialog.setWindowIcon(QIcon(str(icon_path)))

        layout = QVBoxLayout()

        title = QLabel('Load Assets from Roblox')
        title.setStyleSheet('font-weight: bold;')
        layout.addWidget(title)

        hint = QLabel('Enter asset IDs separated by commas, spaces, newlines, or semicolons.')
        hint.setStyleSheet('color: gray; font-size: 9pt;')
        hint.setWordWrap(True)
        layout.addWidget(hint)

        text_edit = QTextEdit()
        text_edit.setAcceptRichText(False)
        text_edit.setPlaceholderText('e.g. 1818, 1234567890, 9876543210')
        layout.addWidget(text_edit)

        status_label = QLabel('')
        status_label.setStyleSheet('color: #888; font-size: 9pt;')

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(status_label)

        load_btn = QPushButton('Load Asset IDs')
        btn_layout.addWidget(load_btn)
        layout.addLayout(btn_layout)

        dialog.setLayout(layout)

        def on_load_clicked():
            content = text_edit.toPlainText().strip()
            if not content:
                return

            # Parse IDs: support commas, spaces, newlines, semicolons as separators
            content = content.replace('\n', ',').replace(';', ',').replace(' ', ',')
            raw_ids = []
            for part in content.split(','):
                part = part.strip()
                if part:
                    try:
                        raw_ids.append(int(part))
                    except ValueError:
                        pass  # Skip non-numeric entries

            if not raw_ids:
                status_label.setText('No valid asset IDs found.')
                status_label.setStyleSheet('color: #cc5555; font-size: 9pt;')
                return

            # Deduplicate while preserving order
            seen = set()
            asset_ids = []
            for aid in raw_ids:
                if aid not in seen:
                    seen.add(aid)
                    asset_ids.append(aid)

            # Disable button while loading
            load_btn.setEnabled(False)
            text_edit.setReadOnly(True)
            status_label.setText(f'Loading {format_count(asset_ids, "asset")}...')
            status_label.setStyleSheet('color: #888; font-size: 9pt;')

            log_buffer.log(
                'Scraper',
                f'[Load Asset] Starting load of {format_count(asset_ids, "asset ID")}',
            )

            # Stop any existing loader
            if self._asset_loader is not None:
                self._asset_loader.stop()
                self._asset_loader.quit()
                self._asset_loader.wait()
                self._asset_loader = None

            self._asset_loader = AssetLoaderThread(
                asset_ids, self.cache_manager, self.cache_scraper
            )

            def on_status(msg):
                status_label.setText(msg)

            def on_finished(loaded, failed):
                self._on_load_assets_complete(
                    loaded, failed, dialog, load_btn, text_edit, status_label
                )

            self._asset_loader.status_message.connect(on_status)
            self._asset_loader.finished_loading.connect(on_finished)
            self._asset_loader.start()

        load_btn.clicked.connect(on_load_clicked)

        # Handle cleanup when dialog is closed (by user or programmatically)
        def on_dialog_finished():
            if self._asset_loader is not None:
                self._asset_loader.stop()
                self._asset_loader.quit()
                self._asset_loader.wait()
                self._asset_loader = None

        dialog.finished.connect(on_dialog_finished)

        # Non-modal: use show() so the rest of the app remains interactive
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dialog.show()

    def _on_load_assets_complete(
        self,
        loaded: int,
        failed: int,
        dialog: QDialog,
        load_btn: QPushButton,
        text_edit: QTextEdit,
        status_label: QLabel,
    ):
        """Handle completion of the asset loading thread."""
        # Merge resolved metadata into _asset_info so names/creators show immediately
        if self._asset_loader is not None:
            resolved = getattr(self._asset_loader, '_resolved_metadata', {})
            creator_names = getattr(self._asset_loader, '_resolved_creator_names', {})
            for asset_id, meta in resolved.items():
                if asset_id not in self._asset_info:
                    self._asset_info[asset_id] = {
                        'hash': '',
                        'resolved_name': None,
                        'creator_id': None,
                        'creator_name': None,
                        'creator_type': None,
                        'created_at': None,
                        'updated_at': None,
                        'row': None,
                    }
                info = self._asset_info[asset_id]
                info['resolved_name'] = meta.get('name')
                info['creator_id'] = meta.get('creator_id')
                info['creator_type'] = meta.get('creator_type')
                info['created_at'] = meta.get('created_at') or ''
                info['updated_at'] = meta.get('updated_at') or ''
                cid = meta.get('creator_id')
                if cid is not None and cid in creator_names:
                    info['creator_name'] = creator_names[cid]
                elif meta.get('creator_name'):
                    info['creator_name'] = meta['creator_name']

                # Persist to index
                self._save_resolved_name_to_index(asset_id, meta.get('name', ''))
                self._save_resolved_creator_to_index(
                    asset_id,
                    meta.get('creator_id'),
                    info.get('creator_name'),
                    meta.get('creator_type'),
                )
                self._save_resolved_timestamps_to_index(
                    asset_id,
                    meta.get('created_at'),
                    meta.get('updated_at'),
                )

            # Save index once
            try:
                self.cache_manager._save_index()
            except Exception:
                pass

        # Re-enable UI
        load_btn.setEnabled(True)
        text_edit.setReadOnly(False)

        if failed == 0:
            status_label.setText(f'Done! Loaded {format_count(loaded, "asset")}.')
            status_label.setStyleSheet('color: #55cc66; font-size: 9pt;')
        else:
            status_label.setText(f'Done! Loaded {loaded}, failed {failed}.')
            status_label.setStyleSheet('color: #ccaa55; font-size: 9pt;')

        log_buffer.log('Scraper', f'[Load Asset] Finished: {loaded} loaded, {failed} failed')

        # Refresh the table to show newly loaded assets
        self._refresh_assets()
