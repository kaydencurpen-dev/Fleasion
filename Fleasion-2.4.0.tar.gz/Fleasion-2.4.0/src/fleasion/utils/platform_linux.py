"""Linux/Sober desktop utilities."""

from __future__ import annotations

import os
try:
    import pwd
except ModuleNotFoundError:  # pragma: no cover - exercised by Windows collection
    pwd = None
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from .logging import log_buffer
from .metadata import APP_NAME
from .paths import APP_CACHE_DIR, STORAGE_DB, USER_HOME, get_icon_path

SOBER_APP_ID = 'org.vinegarhq.Sober'
SOBER_FLATPAK_ROOT = USER_HOME / '.var' / 'app' / SOBER_APP_ID
SOBER_DATA_DIR = SOBER_FLATPAK_ROOT / 'data' / 'sober'
SOBER_CACHE_DIR = SOBER_FLATPAK_ROOT / 'cache' / 'sober'
SOBER_CONFIG_FILE = SOBER_FLATPAK_ROOT / 'config' / 'sober' / 'config.json'
SOBER_ASSET_OVERLAY_DIR = SOBER_DATA_DIR / 'asset_overlay'
SOBER_LEGACY_EXE_DIR = SOBER_DATA_DIR / 'exe'
SOBER_CACHE_STORAGE_DIR = SOBER_CACHE_DIR / 'rbx-storage'
SOBER_PROCESS_NAMES = ('sober', 'Sober', SOBER_APP_ID)
SOBER_CGROUP_MARKER = 'app-flatpak-org.vinegarhq.Sober'
# Sober fetches its update/feature manifest before the Roblox engine starts.
# That bootstrap client uses certificate pinning and does not trust Fleasion's
# generated CA, so these connections must remain tunneled when the Proxy tab's
# intercept-all switch is enabled. Roblox traffic is still intercepted normally.
SOBER_ENV_PROXY_PASSTHROUGH_HOSTS = frozenset(
    {'sober.vinegarhq.org', 'raw.githubusercontent.com'}
)
PROC_ROOT = Path('/proc')
_ROBLOX_URI_SCHEMES = ('x-scheme-handler/roblox', 'x-scheme-handler/roblox-player')
_SOBER_PROXY_ENVIRONMENT_NAMES = (
    'ALL_PROXY',
    'HTTPS_PROXY',
    'HTTP_PROXY',
    'all_proxy',
    'https_proxy',
    'http_proxy',
    'NO_PROXY',
    'no_proxy',
)
_FLEASION_ROBLOX_URI_HANDLER_IDS = frozenset(
    {
        'fleasion.desktop',
        'fleasion-non-admin.desktop',
        'fleasion-read-only.desktop',
        'fleasion-proxy.desktop',
    }
)
DESKTOP_OPENERS = (
    ('xdg-open', ()),
    ('gio', ('open',)),
    ('kde-open5', ()),
    ('kde-open', ()),
    ('gnome-open', ()),
)

LINUX_APPLICATIONS_DIR = USER_HOME / '.local' / 'share' / 'applications'
LINUX_INSTALL_DIR = USER_HOME / '.local' / 'share' / APP_NAME
LINUX_BIN_DIR = USER_HOME / '.local' / 'bin'
LINUX_DESKTOP_ENTRY_PATH = LINUX_APPLICATIONS_DIR / 'fleasion.desktop'
LINUX_LAUNCHER_PATH = LINUX_BIN_DIR / 'fleasion-launch'
LINUX_INSTALLED_APP_PATH = LINUX_INSTALL_DIR / APP_NAME
LINUX_INSTALLED_ICON_PATH = LINUX_INSTALL_DIR / 'fleasionlogoHR.ico'
LINUX_DEPRECATED_DESKTOP_ENTRY_PATHS = (
    LINUX_APPLICATIONS_DIR / 'fleasion-non-admin.desktop',
    LINUX_APPLICATIONS_DIR / 'fleasion-read-only.desktop',
    LINUX_APPLICATIONS_DIR / 'fleasion-proxy.desktop',
)
OS_RELEASE_PATH = Path('/etc/os-release')
ARCH_LINUX_IDS = frozenset(
    {
        'arch',
        'cachyos',
        'endeavouros',
        'garuda',
        'manjaro',
        'steamos',
    }
)
ARCH_LINUX_GUI_PACKAGES = ('qt6-base',)


def _os_release_ids(path: Path = OS_RELEASE_PATH) -> set[str]:
    """Return normalized distro IDs from os-release."""
    try:
        lines = path.read_text(encoding='utf-8', errors='replace').splitlines()
    except OSError:
        return set()

    values: dict[str, str] = {}
    for line in lines:
        key, separator, value = line.partition('=')
        if not separator or key not in {'ID', 'ID_LIKE'}:
            continue
        values[key] = value.strip().strip('"').strip("'")

    return {
        distro_id.casefold()
        for value in values.values()
        for distro_id in value.split()
        if distro_id
    }


def missing_linux_gui_packages(
    *,
    os_release_path: Path = OS_RELEASE_PATH,
) -> list[str]:
    """Return missing native GUI packages on supported package-managed distros."""
    if not (_os_release_ids(os_release_path) & ARCH_LINUX_IDS):
        return []
    pacman = shutil.which('pacman')
    if pacman is None:
        return []

    missing: list[str] = []
    for package in ARCH_LINUX_GUI_PACKAGES:
        try:
            result = subprocess.run(
                [pacman, '-Q', package],
                capture_output=True,
                text=True,
                timeout=5,
                # PyInstaller adds its Ubuntu-built shared libraries to
                # LD_LIBRARY_PATH.  pacman must instead load the Arch host
                # libraries, or an ABI/load failure looks like a missing
                # package to this check.
                env=_host_subprocess_env(),
            )
        except Exception:
            # A failed package query should not block an otherwise working
            # desktop when its package manager cannot be inspected.
            continue
        if result.returncode != 0:
            diagnostics = (result.stderr or result.stdout).strip()
            detail = f' Details: {diagnostics}' if diagnostics else ''
            log_buffer.log(
                'Linux GUI',
                f'Arch package query reports {package} as unavailable '
                f'(pacman exit {result.returncode}).{detail}',
            )
            missing.append(package)
    return missing


def run_cmd(args: list[str]) -> str:
    """Run a command and return stdout."""
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding='utf-8',
        errors='replace',
    ).stdout


def _process_pids(name: str) -> list[int]:
    try:
        result = subprocess.run(
            ['pgrep', '-x', name],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return []
    pids: list[int] = []
    for raw in result.stdout.splitlines():
        try:
            pids.append(int(raw.strip()))
        except ValueError:
            pass
    return pids


def _first_sober_pid() -> int | None:
    for name in SOBER_PROCESS_NAMES:
        pids = _process_pids(name)
        if pids:
            return pids[0]
    return None


def sober_main_process() -> tuple[int, float] | None:
    """Return the Sober Roblox engine PID and its boot-time start timestamp.

    ``Main`` is the Android/Roblox engine process created by Sober.  Pairing
    the PID with the kernel start timestamp makes a close/reopen detectable
    even when the process monitor does not observe a moment with no process.
    """
    try:
        ticks_per_second = float(os.sysconf('SC_CLK_TCK'))
    except (AttributeError, OSError, ValueError):
        return None
    if ticks_per_second <= 0:
        return None

    for pid in _process_pids('Main'):
        process_dir = PROC_ROOT / str(pid)
        try:
            cgroup = (process_dir / 'cgroup').read_text(
                encoding='utf-8', errors='replace'
            )
            if SOBER_CGROUP_MARKER not in cgroup:
                continue
            stat_text = (process_dir / 'stat').read_text(encoding='utf-8', errors='replace')
            # Field 2 (comm) is parenthesized and can contain spaces.  The
            # remaining fields begin at field 3, so starttime (field 22) is 19.
            fields = stat_text.rsplit(')', 1)[1].split()
            start_ticks = int(fields[19])
        except (IndexError, OSError, ValueError):
            continue
        return pid, start_ticks / ticks_per_second
    return None


def _process_command(pid: int) -> Path | None:
    try:
        result = subprocess.run(
            ['ps', '-p', str(pid), '-o', 'comm='],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return None
    value = result.stdout.strip()
    return Path(value) if value else None


def wait_for_roblox_window(timeout: float = 60.0) -> bool:
    """Wait until Sober's Roblox runtime process is running."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if is_roblox_running():
            return True
        time.sleep(0.25)
    return False


def is_roblox_running() -> bool:
    """Check if Sober is currently running."""
    return _first_sober_pid() is not None


def get_roblox_process_identity() -> tuple[str, int, float] | tuple[str, int] | None:
    """Return Sober's engine generation, falling back to its launcher PID."""
    engine = sober_main_process()
    if engine is not None:
        return 'engine', engine[0], engine[1]
    pid = _first_sober_pid()
    return ('launcher', pid) if pid is not None else None


def is_studio_running() -> bool:
    """Roblox Studio is not supported through Sober."""
    return False


def get_roblox_player_exe_path() -> Optional[Path]:
    """Linux/Sober does not expose a stable RobloxPlayerBeta.exe path.

    The running process is the Flatpak launcher or wrapper, not the resource
    root that callers need for cert/modification discovery. Returning a
    fabricated path would send downstream code to the wrong directory, so we
    intentionally return ``None`` and let callers use the Sober resource-root
    discovery helpers instead.
    """
    return None


def get_roblox_studio_exe_path() -> Optional[Path]:
    """Roblox Studio is not supported through Sober."""
    return None


def terminate_roblox() -> bool:
    """Terminate Sober if it is running. Returns True if it was running."""
    if not is_roblox_running():
        return False
    terminated = False

    flatpak = shutil.which('flatpak')
    if flatpak:
        try:
            result = subprocess.run(
                [flatpak, 'kill', SOBER_APP_ID],
                env=_host_subprocess_env(),
                capture_output=True,
                text=True,
                timeout=10,
            )
            terminated = result.returncode == 0
        except Exception:
            pass

    for name in SOBER_PROCESS_NAMES:
        try:
            result = subprocess.run(
                ['pkill', '-x', name],
                env=_host_subprocess_env(),
                capture_output=True,
                timeout=5,
            )
            terminated = result.returncode == 0 or terminated
        except Exception:
            pass
    return terminated or is_roblox_running()


def wait_for_roblox_exit(timeout: float = 10.0) -> bool:
    """Wait for Sober to exit. Returns True if it exited before timeout."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        if not is_roblox_running():
            return True
        time.sleep(0.5)
    return False


def _delete_path(path: Path, messages: list[str], label: str) -> None:
    if not path.exists():
        messages.append(f'{label} already deleted')
        return
    try:
        if path.is_dir():
            shutil.rmtree(path)
        else:
            path.unlink()
        messages.append(f'{label} deleted successfully')
    except PermissionError:
        messages.append(f'Failed to delete {label.lower()}: permission denied')
    except OSError as exc:
        messages.append(f'Failed to delete {label.lower()}: {exc}')


def delete_cache() -> list[str]:
    """Delete Sober/Roblox cache files and Fleasion's converted-object cache."""
    messages: list[str] = []

    if is_roblox_running():
        messages.append('Sober is running, terminating...')
        terminate_roblox()
        if wait_for_roblox_exit():
            messages.append('Sober terminated successfully')
        else:
            messages.extend(['Sober termination timed out', 'Cache deletion aborted'])
            return messages
    else:
        messages.append('Sober was closed')

    _delete_path(STORAGE_DB, messages, 'Storage database')
    for suffix in ('-wal', '-shm'):
        sidecar = Path(str(STORAGE_DB) + suffix)
        if sidecar.exists():
            _delete_path(sidecar, messages, f'Storage database {suffix}')

    storage_folder = STORAGE_DB.parent / 'rbx-storage'
    _delete_path(storage_folder, messages, 'Storage folder')
    if SOBER_CACHE_STORAGE_DIR != storage_folder:
        _delete_path(SOBER_CACHE_STORAGE_DIR, messages, 'Cache storage folder')

    if APP_CACHE_DIR.exists():
        try:
            preserve = {APP_CACHE_DIR / 'predownloaded'}
            for child in APP_CACHE_DIR.iterdir():
                if child in preserve:
                    continue
                if child.is_dir():
                    shutil.rmtree(child)
                else:
                    child.unlink()
            messages.append('Fleasion obj cache deleted successfully')
        except PermissionError:
            messages.append('Failed to delete obj cache: permission denied')
        except OSError as exc:
            messages.append(f'Failed to delete obj cache: {exc}')

    return messages


def find_roblox_resource_dirs(include_studio: bool = True) -> list[Path]:
    """Return Sober resource roots used by patch/modification code."""
    found: list[Path] = []
    seen: set[str] = set()

    def _add(path: Path) -> None:
        if not path.exists():
            return
        key = str(path.resolve()).lower()
        if key in seen:
            return
        seen.add(key)
        found.append(path)

    if SOBER_DATA_DIR.exists():
        SOBER_ASSET_OVERLAY_DIR.mkdir(parents=True, exist_ok=True)
        _add(SOBER_ASSET_OVERLAY_DIR)

    # Older Sober builds exposed a Roblox-like extracted tree here.
    if SOBER_LEGACY_EXE_DIR.is_dir():
        _add(SOBER_LEGACY_EXE_DIR)

    return found


def is_sober_resource_dir(path: Path) -> bool:
    """Return True when *path* is one of Sober's resource roots."""
    try:
        resolved = path.resolve()
        return resolved in {
            SOBER_ASSET_OVERLAY_DIR.resolve(),
            SOBER_LEGACY_EXE_DIR.resolve(),
        }
    except OSError:
        return False


def resolve_roblox_player_exe_for_launch() -> Optional[Path]:
    """Return a launcher path if Sober can be launched through Flatpak."""
    flatpak = shutil.which('flatpak')
    return Path(flatpak) if flatpak else None


_DETACHED_POPEN_KWARGS = {
    'stdin': subprocess.DEVNULL,
    'stdout': subprocess.DEVNULL,
    'stderr': subprocess.DEVNULL,
    'start_new_session': True,
}


def _host_subprocess_env() -> dict[str, str]:
    """Run host desktop tools without PyInstaller's private library path."""
    env = os.environ.copy()
    original_library_path = env.pop('LD_LIBRARY_PATH_ORIG', None)
    if original_library_path is not None:
        if original_library_path:
            env['LD_LIBRARY_PATH'] = original_library_path
        else:
            env.pop('LD_LIBRARY_PATH', None)
        return env

    bundle_root = getattr(sys, '_MEIPASS', None)
    library_path = env.get('LD_LIBRARY_PATH')
    if bundle_root and library_path:
        bundle_path = Path(bundle_root).resolve()
        entries = [
            entry
            for entry in library_path.split(os.pathsep)
            if entry and Path(entry).resolve() != bundle_path
        ]
        if entries:
            env['LD_LIBRARY_PATH'] = os.pathsep.join(entries)
        else:
            env.pop('LD_LIBRARY_PATH', None)
    return env


def _standard_user_popen(args: list[str]) -> subprocess.Popen:
    env = _host_subprocess_env()
    if os.geteuid() != 0:
        return subprocess.Popen(args, env=env, **_DETACHED_POPEN_KWARGS)

    user_home = Path(os.environ.get('FLEASION_USER_HOME') or USER_HOME)
    try:
        stat = user_home.stat()
        uid = stat.st_uid
        gid = stat.st_gid
        if pwd is None:
            raise KeyError(uid)
        pw_entry = pwd.getpwuid(uid)
    except Exception:
        return subprocess.Popen(args, env=env, **_DETACHED_POPEN_KWARGS)

    env.update(
        {
            'HOME': str(user_home),
            'USER': pw_entry.pw_name,
            'LOGNAME': pw_entry.pw_name,
            'XDG_RUNTIME_DIR': f'/run/user/{uid}',
        }
    )

    def _demote() -> None:
        os.setgid(gid)
        os.setuid(uid)

    return subprocess.Popen(args, env=env, preexec_fn=_demote, **_DETACHED_POPEN_KWARGS)


def _standard_user_run(args: list[str], **kwargs) -> subprocess.CompletedProcess:
    """Run a host command as the desktop user, including under elevation."""
    env = _host_subprocess_env()
    if os.geteuid() != 0:
        return subprocess.run(args, env=env, **kwargs)

    user_home = Path(os.environ.get('FLEASION_USER_HOME') or USER_HOME)
    try:
        stat = user_home.stat()
        uid = stat.st_uid
        gid = stat.st_gid
        if pwd is None:
            raise KeyError(uid)
        pw_entry = pwd.getpwuid(uid)
    except Exception:
        return subprocess.run(args, env=env, **kwargs)

    env.update(
        {
            'HOME': str(user_home),
            'USER': pw_entry.pw_name,
            'LOGNAME': pw_entry.pw_name,
            'XDG_RUNTIME_DIR': f'/run/user/{uid}',
        }
    )

    def _demote() -> None:
        os.setgid(gid)
        os.setuid(uid)

    return subprocess.run(args, env=env, preexec_fn=_demote, **kwargs)


def _desktop_open_command(target: str) -> list[str] | None:
    for executable, extra_args in DESKTOP_OPENERS:
        resolved = shutil.which(executable)
        if resolved:
            return [resolved, *extra_args, target]
    return None


def _open_with_desktop_handler(target: str, label: str) -> bool:
    command = _desktop_open_command(target)
    if command is None:
        log_buffer.log('Launch', f'Cannot open {label}: no desktop opener found')
        return False
    try:
        _standard_user_popen(command)
        return True
    except Exception as exc:
        log_buffer.log('Launch', f'Failed to open {label}: {exc}')
        return False


def launch_as_standard_user(target: str | Path) -> bool:
    """Launch a Roblox URI or Sober itself."""
    target_str = str(target).strip()
    if not target_str:
        return False
    try:
        if target_str.startswith(('roblox:', 'roblox-player:')):
            flatpak = shutil.which('flatpak')
            if not flatpak:
                log_buffer.log('Launch', 'Cannot launch Sober URI: flatpak command not found')
                return False
            _standard_user_popen([flatpak, 'run', SOBER_APP_ID, target_str])
            return True

        if target_str.startswith(('http://', 'https://')):
            return _open_with_desktop_handler(target_str, 'URL')

        path = Path(target_str)
        flatpak = shutil.which('flatpak')
        if flatpak and (path.name == 'flatpak' or target_str == SOBER_APP_ID):
            _standard_user_popen([flatpak, 'run', SOBER_APP_ID])
            return True

        if path.exists():
            return _open_with_desktop_handler(str(path), 'path')
    except Exception as exc:
        log_buffer.log('Launch', f'Failed to launch {target_str}: {exc}')
        return False

    log_buffer.log('Launch', f'Launch target not found: {target_str}')
    return False


def set_sober_env_proxy_override(proxy_url: str) -> bool:
    """Inject Fleasion's proxy environment into Sober's normal Flatpak launches.

    This deliberately leaves Sober as the browser URI handler.  A browser can
    therefore pass its one-time Roblox URI to Sober unchanged, while Flatpak
    supplies the same proxy variables Fleasion uses for explicit relaunches.
    """
    flatpak = shutil.which('flatpak')
    if not flatpak:
        log_buffer.log('Launcher', 'Cannot arm Sober Env Proxy: flatpak command not found')
        return False

    proxy_env = {
        'ALL_PROXY': proxy_url,
        'HTTPS_PROXY': proxy_url,
        'HTTP_PROXY': proxy_url,
        'all_proxy': proxy_url,
        'https_proxy': proxy_url,
        'http_proxy': proxy_url,
        'NO_PROXY': 'localhost,127.0.0.1,::1',
        'no_proxy': 'localhost,127.0.0.1,::1',
    }
    try:
        result = _standard_user_run(
            [
                flatpak,
                'override',
                '--user',
                *(f'--env={key}={value}' for key, value in proxy_env.items()),
                SOBER_APP_ID,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception as exc:
        log_buffer.log('Launcher', f'Could not arm Sober Env Proxy: {exc}')
        return False
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        log_buffer.log(
            'Launcher',
            'Could not arm Sober Env Proxy'
            + (f': {detail}' if detail else ''),
        )
        return False
    log_buffer.log('Launcher', 'Armed Sober Env Proxy for normal browser launches')
    return True


def clear_sober_env_proxy_override() -> bool:
    """Remove Fleasion's proxy environment from future normal Sober launches."""
    flatpak = shutil.which('flatpak')
    if not flatpak:
        log_buffer.log('Launcher', 'Cannot disarm Sober Env Proxy: flatpak command not found')
        return False
    try:
        result = _standard_user_run(
            [
                flatpak,
                'override',
                '--user',
                *(f'--unset-env={name}' for name in _SOBER_PROXY_ENVIRONMENT_NAMES),
                SOBER_APP_ID,
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except Exception as exc:
        log_buffer.log('Launcher', f'Could not disarm Sober Env Proxy: {exc}')
        return False
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip()
        log_buffer.log(
            'Launcher',
            'Could not disarm Sober Env Proxy'
            + (f': {detail}' if detail else ''),
        )
        return False
    log_buffer.log('Launcher', 'Disarmed Sober Env Proxy for normal browser launches')
    return True


def _set_default_roblox_uri_handler(desktop_id: str) -> bool:
    """Set the user-session handler for Roblox URI schemes."""
    xdg_mime = shutil.which('xdg-mime')
    if not xdg_mime:
        log_buffer.log('DesktopIntegration', 'xdg-mime not found; Roblox URI handler unchanged')
        return False

    ok = True
    env = _host_subprocess_env()
    env['HOME'] = str(USER_HOME)
    for scheme in _ROBLOX_URI_SCHEMES:
        try:
            result = subprocess.run(
                [xdg_mime, 'default', desktop_id, scheme],
                env=env,
                capture_output=True,
                text=True,
                timeout=10,
            )
        except Exception as exc:
            log_buffer.log(
                'DesktopIntegration',
                f'Failed to set the {scheme} handler to {desktop_id}: {exc}',
            )
            ok = False
            continue
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip()
            log_buffer.log(
                'DesktopIntegration',
                f'Failed to set the {scheme} handler to {desktop_id}'
                + (f': {detail}' if detail else ''),
            )
            ok = False
    return ok


def _restore_sober_uri_handler() -> bool:
    """Restore Sober only when Fleasion is currently a Roblox URI handler."""
    xdg_mime = shutil.which('xdg-mime')
    if not xdg_mime:
        log_buffer.log('DesktopIntegration', 'xdg-mime not found; Roblox URI handler unchanged')
        return False

    env = _host_subprocess_env()
    env['HOME'] = str(USER_HOME)
    fleasion_handler_detected = False
    for scheme in _ROBLOX_URI_SCHEMES:
        try:
            result = subprocess.run(
                [xdg_mime, 'query', 'default', scheme],
                env=env,
                capture_output=True,
                text=True,
                timeout=10,
            )
        except Exception as exc:
            log_buffer.log(
                'DesktopIntegration', f'Failed to query the {scheme} handler: {exc}'
            )
            continue
        if result.returncode != 0:
            continue
        if result.stdout.strip() in _FLEASION_ROBLOX_URI_HANDLER_IDS:
            fleasion_handler_detected = True

    if not fleasion_handler_detected:
        return False
    return _set_default_roblox_uri_handler(f'{SOBER_APP_ID}.desktop')


def _find_project_root() -> Path | None:
    check = Path(__file__).resolve().parent
    for _ in range(8):
        if (check / 'pyproject.toml').is_file() and (check / 'launcher.py').is_file():
            return check
        if check.parent == check:
            break
        check = check.parent
    return None


def _copy_linux_app_payload() -> tuple[Path | None, Path | None]:
    """Copy frozen Linux app payload into the per-user install directory.

    Source/development launches do not have a self-contained binary to copy, so
    they keep running from the checkout. Frozen builds are copied so the desktop
    entry does not point at a Downloads/tmp path that can disappear.
    """
    if not getattr(sys, 'frozen', False):
        return None, None

    source = Path(sys.executable).resolve()
    if source.is_relative_to(Path('/nix/store')):
        log_buffer.log(
            'App',
            'Linux desktop integration detected a Nix store executable; using it directly instead of copying a stale per-user binary',
        )
        return None, None

    LINUX_INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    installed_app = LINUX_INSTALLED_APP_PATH
    if source != installed_app.resolve():
        shutil.copy2(source, installed_app)
    installed_app.chmod(0o755)

    installed_icon: Path | None = None
    icon_path = get_icon_path()
    if icon_path is not None and icon_path.is_file():
        installed_icon = LINUX_INSTALLED_ICON_PATH
        if icon_path.resolve() != installed_icon.resolve():
            shutil.copy2(icon_path, installed_icon)
        installed_icon.chmod(0o644)

    return installed_app, installed_icon


def _linux_app_launch_command(
    installed_app: Path | None = None,
) -> tuple[list[str], Path | None]:
    """Return the normal-user command that a privileged wrapper should run."""
    if installed_app is not None:
        return [str(installed_app)], installed_app.parent

    if getattr(sys, 'frozen', False):
        return [sys.executable], Path(sys.executable).parent

    project = _find_project_root()
    if project is not None:
        return [sys.executable, str(project / 'launcher.py')], project

    return [sys.executable, '-c', 'from fleasion import main; main()'], None


def _write_executable_script(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')
    path.chmod(0o755)


def install_desktop_entries() -> dict:
    """Install the Linux desktop launcher.

    The installed application entry starts Fleasion as the interactive user.
    Linux/Sober interception starts a small pkexec helper only for /etc/hosts
    and the privileged port-443 relay, keeping the Qt GUI in the user session.
    Legacy non-admin/read-only desktop entries are removed so menus only expose
    the supported proxy-capable launcher.
    """
    installed_app, installed_icon = _copy_linux_app_payload()
    command, working_dir = _linux_app_launch_command(installed_app)
    command_literal = ' '.join(shlex.quote(part) for part in command)
    working_dir_literal = shlex.quote(str(working_dir)) if working_dir is not None else ''
    pythonpath = (
        ''
        if working_dir is None
        else f'export PYTHONPATH={shlex.quote(str(working_dir / "src"))}${{PYTHONPATH:+:$PYTHONPATH}}\n'
    )

    launcher = f'''#!/bin/sh
set -eu
export FLEASION_USER_HOME="{USER_HOME}"
{pythonpath}{f'cd {working_dir_literal}' if working_dir is not None else ':'}
exec {command_literal} "$@"
'''
    _write_executable_script(LINUX_LAUNCHER_PATH, launcher)

    icon_path = installed_icon or get_icon_path()
    icon_line = f'Icon={icon_path}\n' if icon_path is not None else 'Icon=fleasion\n'
    desktop_entry = (
        '[Desktop Entry]\n'
        'Type=Application\n'
        f'Name={APP_NAME}\n'
        'Comment=Roblox asset interceptor and replacer for Sober\n'
        f'Exec={shlex.quote(str(LINUX_LAUNCHER_PATH))}\n'
        f'{icon_line}'
        'Terminal=false\n'
        'Categories=Game;Utility;\n'
        'StartupNotify=true\n'
    )
    LINUX_APPLICATIONS_DIR.mkdir(parents=True, exist_ok=True)
    LINUX_DESKTOP_ENTRY_PATH.write_text(desktop_entry, encoding='utf-8')
    LINUX_DESKTOP_ENTRY_PATH.chmod(0o644)

    removed: list[str] = []
    for path in LINUX_DEPRECATED_DESKTOP_ENTRY_PATHS:
        if path.exists():
            path.unlink()
            removed.append(str(path))

    update_desktop = shutil.which('update-desktop-database')
    if update_desktop:
        subprocess.run(
            [update_desktop, str(LINUX_APPLICATIONS_DIR)],
            capture_output=True,
            timeout=10,
        )

    sober_uri_handler_restored = _restore_sober_uri_handler()

    return {
        'desktop_entry': str(LINUX_DESKTOP_ENTRY_PATH),
        'launcher': str(LINUX_LAUNCHER_PATH),
        'installed_app': str(installed_app) if installed_app is not None else None,
        'installed_icon': str(installed_icon) if installed_icon is not None else None,
        'removed_deprecated_entries': removed,
        'sober_uri_handler_restored': sober_uri_handler_restored,
    }


def open_folder(path: Path):
    """Open a folder in the user's file manager."""
    path.mkdir(parents=True, exist_ok=True)
    return _open_with_desktop_handler(str(path), 'folder')


def show_message_box(title: str, message: str, icon: int = 0x40):
    """Show a simple Linux desktop notification/dialog when available."""
    try:
        subprocess.run(['zenity', '--info', '--title', title, '--text', message], timeout=10)
    except Exception:
        log_buffer.log('UI', f'{title}: {message}')
