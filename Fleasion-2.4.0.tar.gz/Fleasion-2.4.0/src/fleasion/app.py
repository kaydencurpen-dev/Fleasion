"""Application entrypoint."""

import atexit
import html
import json
import os
import platform
import shlex
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from PyQt6.QtCore import QEvent, QObject, QSharedMemory, Qt, QTimer, pyqtSignal, pyqtSlot
from PyQt6.QtNetwork import QLocalServer, QLocalSocket
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from . import __version__
from .config import ConfigFolderWatcher, ConfigManager
from .modifications import ModificationManager
from .prejsons import download_prejsons
from .proxy import ProxyMaster, check_and_patch_running_roblox_ca
from .tray import SystemTray
from .utils import (
    APP_DISCORD,
    APP_NAME,
    CONFIG_DIR,
    LOG_FILE,
    delete_cache,
    get_icon_path,
    get_roblox_player_exe_path,
    get_roblox_process_identity,
    get_roblox_studio_exe_path,
    is_roblox_running,
    is_studio_running,
    launch_as_standard_user,
    log_buffer,
    open_folder,
    run_in_thread,
    start_update_check,
    terminate_roblox,
    time_tracker,
    wait_for_roblox_exit,
)
from .utils.microprofiler import start_microprofiler

_SINGLE_INSTANCE_KEY = 'FleasionSingleInstance'
_SINGLE_INSTANCE_CONTROL_SERVER = 'FleasionSingleInstanceControl'
_WINDOWS_REPAIR_RESULT_TIMEOUT_SECONDS = 120.0
_WINDOWS_FIREWALL_REPAIR_RESULT_TIMEOUT_SECONDS = 120.0
_WINDOWS_HOSTS_CLEANUP_TIMEOUT_SECONDS = 15 * 60
_WINDOWS_WAIT_TIMEOUT = 0x102
_HOSTS_CLEANUP_NOT_ADMIN_EXIT = 10
_HOSTS_CLEANUP_WRITE_FAILED_EXIT = 11
_HOSTS_CLEANUP_UNEXPECTED_EXIT = 12
_MACOS_PLAIN_LAUNCH_CLASSIFICATION_SECONDS = 2.0


class _FirstTimeSetupMessageBox(QMessageBox):
    """Message box that must be acknowledged with OK."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._can_accept = False

    def allow_accept(self):
        self._can_accept = True

    def accept(self):
        if self._can_accept:
            super().accept()

    def reject(self):
        return

    def closeEvent(self, event):
        event.ignore()


class _ForcedAcknowledgeMessageBox(QMessageBox):
    """Message box that cannot be dismissed until explicitly allowed."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._can_close = False

    def allow_close(self):
        self._can_close = True

    def done(self, result: int):
        if self._can_close:
            super().done(result)

    def closeEvent(self, event):
        if self._can_close:
            event.accept()
        else:
            event.ignore()


def _prepare_env_proxy_migration(config_manager: ConfigManager) -> bool:
    """Select Env Proxy before privilege gates and report a legacy migration."""
    if config_manager.env_proxy_migration_v1_complete:
        return False

    # Assign even when the merged in-memory default is already Env so the new
    # mode is durable on disk before any acknowledgement dialog can appear.
    config_manager.proxy_mode = 'env'

    # First-time users learn about Env Proxy in the setup guide. Existing
    # users receive the dedicated migration acknowledgement later in startup.
    return bool(config_manager.first_time_setup_complete)


def _show_env_proxy_migration(config_manager: ConfigManager, roblox_monitor) -> None:
    """Acknowledge the forced legacy migration and apply it to Player."""
    player_running = bool(roblox_monitor.is_player_running())
    if player_running:
        # Do not let the process monitor interpret a Player that predates this
        # startup as a fresh launch and relaunch it without the user's choice.
        roblox_monitor.was_running = True
        roblox_monitor._player_was_running = True

    msg = QMessageBox(_visible_parent_widget())
    msg.setWindowTitle('New Default: Roblox Env Proxy')
    msg.setIcon(QMessageBox.Icon.Information)
    msg.setText('Fleasion has switched your saved proxy mode to Roblox Env Proxy.')
    details = (
        'Env Proxy is the new recommended mode and does not require administrator '
        'permission for normal use. Fleasion applies it only to Roblox Player '
        '(including Sober); Roblox Studio is left untouched.\n\n'
        'You can switch back at any time under Settings > Proxy > Proxy Mode. '
        'Hosts File mode may require administrator permission.'
    )
    restart_button = None
    if player_running and config_manager.proxy_features_enabled:
        if sys.platform.startswith('linux'):
            details += '\n\nFleasion will apply the proxy to future Sober launches.'
            restart_button = msg.addButton('Apply for Future Launches', QMessageBox.ButtonRole.AcceptRole)
            later_button = msg.addButton('Apply Later', QMessageBox.ButtonRole.RejectRole)
        else:
            details += (
                '\n\nRoblox Player is already running. It must be relaunched before '
                'the new proxy mode applies to that session.'
            )
            restart_button = msg.addButton('Restart Roblox Now', QMessageBox.ButtonRole.AcceptRole)
            later_button = msg.addButton('Restart Roblox Later', QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(restart_button)
        msg.setEscapeButton(later_button)
    else:
        if player_running:
            details += (
                '\n\nProxy features are currently disabled, so Fleasion will not '
                'relaunch Roblox Player.'
            )
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    msg.setInformativeText(details)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    msg.exec()
    config_manager.env_proxy_migration_v1_complete = True

    if restart_button is None or msg.clickedButton() is not restart_button:
        return
    lifecycle = getattr(roblox_monitor, 'env_lifecycle', None)
    if lifecycle is None:
        return
    if sys.platform.startswith('linux'):
        run_in_thread(lifecycle.handle_adopted_player_launch)(Path('org.vinegarhq.Sober'))
    else:
        run_in_thread(lifecycle.handle_player_launch)(get_roblox_player_exe_path())


class _MacOSAuthSourceDialog(QDialog):
    """Browser-token startup prompt that only closes through explicit choices."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.allow_reject = False

    def reject(self):
        if self.allow_reject:
            super().reject()

    def closeEvent(self, event):
        if self.allow_reject:
            event.accept()
        else:
            event.ignore()


def _quit_after_modal_closes(modal, tray=None, selected: dict[str, str] | None = None) -> None:
    """Close the active modal first, then run the normal quit path."""
    if QApplication.overrideCursor() is not None:
        QApplication.restoreOverrideCursor()
    if selected is not None:
        selected['exit'] = '1'
    if hasattr(modal, 'allow_reject'):
        modal.allow_reject = True
    if hasattr(modal, 'allow_close'):
        modal.allow_close()
    try:
        modal.reject()
    except Exception:
        pass

    def _quit() -> None:
        if tray is not None and hasattr(tray, '_exit_app'):
            tray._exit_app()
        else:
            QApplication.quit()

    QTimer.singleShot(0, _quit)


# ---------------------------------------------------------------------------
# UAC / elevation helpers
# ---------------------------------------------------------------------------


def _is_admin() -> bool:
    """Return True if the current process has administrator/root privileges."""
    if sys.platform == 'darwin' or sys.platform.startswith('linux'):
        return hasattr(os, 'geteuid') and os.geteuid() == 0
    import ctypes

    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _cleanup_hosts_once() -> int:
    """Remove Fleasion hosts entries from a one-shot elevated child."""
    if not _is_admin():
        log_buffer.log(
            'Hosts', 'Elevated hosts cleanup child rejected: administrator access is required'
        )
        return _HOSTS_CLEANUP_NOT_ADMIN_EXIT

    from .proxy.master import (
        INTERCEPT_HOSTS,
        _cancel_hosts_cleanup_on_reboot,
        _flush_dns,
        _remove_hosts_entries,
        hosts_file_is_oversized,
        repair_hosts_file,
    )

    error_details: dict = {}
    try:
        if hosts_file_is_oversized(error_details):
            cleaned = repair_hosts_file(set(INTERCEPT_HOSTS), error_details=error_details)
        else:
            cleaned = _remove_hosts_entries(set(INTERCEPT_HOSTS), error_details=error_details)
        if not cleaned:
            detail = error_details.get('error') or 'unknown hosts write failure'
            log_buffer.log(
                'Hosts', f'Elevated hosts cleanup child could not update the hosts file: {detail}'
            )
            return _HOSTS_CLEANUP_WRITE_FAILED_EXIT
        _flush_dns()
        _cancel_hosts_cleanup_on_reboot()
    except Exception as exc:
        log_buffer.log('Hosts', f'Elevated hosts cleanup child crashed: {exc!r}')
        return _HOSTS_CLEANUP_UNEXPECTED_EXIT
    log_buffer.log('Hosts', 'Elevated one-shot hosts cleanup completed')
    return 0


def _run_privileged_hosts_cleanup(parent=None) -> bool:
    """Run the short-lived administrator/root child used for Env Proxy repair."""
    if _is_admin():
        return _cleanup_hosts_once() == 0

    if sys.platform.startswith('linux'):
        from .utils.linux_proxy_helper import cleanup_hosts_with_pkexec

        return cleanup_hosts_with_pkexec()

    completion: dict[str, int | bool] = {}
    completed = _relaunch_as_admin(
        extra_args='--cleanup-hosts',
        parent_hwnd=_window_handle(parent),
        wait_for_completion=True,
        wait_timeout_ms=int(_WINDOWS_HOSTS_CLEANUP_TIMEOUT_SECONDS * 1000),
        completion=completion,
    )
    if completed:
        return True

    exit_code = completion.get('exit_code')
    if completion.get('wait_result') == _WINDOWS_WAIT_TIMEOUT:
        log_buffer.log(
            'Hosts',
            'Privileged cleanup child is still running after the extended wait; '
            'the hosts file may still be under repair',
        )
        return False
    reasons = {
        _HOSTS_CLEANUP_NOT_ADMIN_EXIT: 'the child did not receive an administrator token',
        _HOSTS_CLEANUP_WRITE_FAILED_EXIT: 'Windows or security software blocked the hosts write',
        _HOSTS_CLEANUP_UNEXPECTED_EXIT: 'the cleanup child raised an unexpected exception',
    }
    if exit_code in reasons:
        log_buffer.log('Hosts', f'Privileged cleanup failed because {reasons[exit_code]}')
    elif exit_code is not None:
        log_buffer.log(
            'Hosts',
            f'Privileged cleanup child exited before reporting a known outcome (exit={exit_code})',
        )
    return False


def _show_oversized_hosts_file_dialog(details: dict, on_repaired=None) -> bool:
    """Offer a streaming repair for an abnormally large system hosts file."""
    import os

    hosts_path = str(details.get('hosts_path') or r'C:\Windows\System32\drivers\etc\hosts')
    hosts_directory = str(
        details.get('hosts_directory') or os.path.dirname(hosts_path) or r'C:\Windows\System32\drivers\etc'
    )
    size = int(details.get('hosts_size_bytes') or 0)
    limit = int(details.get('hosts_size_limit_bytes') or 512 * 1024)
    size_mib = size / (1024 * 1024)
    limit_kib = limit / 1024
    parent = _visible_parent_widget()

    while True:
        msg = QMessageBox(parent)
        msg.setWindowTitle('Fleasion - Hosts File Is Abnormally Large')
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setText(
            f'Your system hosts file is abnormally large ({size_mib:.1f} MiB).'
        )
        msg.setInformativeText(
            f'Fleasion will not load hosts files larger than {limit_kib:.0f} KiB because a '
            'damaged file can consume all available memory and CPU. This can happen when '
            'another program repeatedly appends blank lines.\n\n'
            'Attempt Safe Repair creates a timestamped backup, removes blank lines and '
            'Fleasion-owned entries, and preserves every other non-empty line byte-for-byte. '
            'This is required even in Env Proxy mode so stale Fleasion redirects cannot remain '
            'active for other programs.'
        )
        repair_button = msg.addButton(
            'Attempt Safe Repair (Recommended)', QMessageBox.ButtonRole.AcceptRole
        )
        open_dir_button = msg.addButton('Open Hosts Directory', QMessageBox.ButtonRole.ActionRole)
        cancel_button = msg.addButton('Cancel', QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(repair_button)
        msg.exec()

        if msg.clickedButton() == open_dir_button:
            try:
                open_folder(Path(hosts_directory))
            except OSError as exc:
                log_buffer.log('Hosts', f'Could not open hosts directory: {exc}')
            continue
        if msg.clickedButton() != repair_button:
            log_buffer.log('Hosts', 'User declined oversized hosts file repair')
            return False

        repair_button.setEnabled(False)
        open_dir_button.setEnabled(False)
        cancel_button.setEnabled(False)
        msg.setText('Waiting for administrator permission...')
        msg.setInformativeText(
            'Approve the operating-system permission prompt. Fleasion will make a backup before '
            'installing the repaired hosts file. A multi-gigabyte hosts file may take several '
            'minutes to process; keep this window open while cleanup runs.'
        )
        msg.show()
        msg.raise_()
        msg.activateWindow()
        QApplication.processEvents()
        try:
            repaired = _run_privileged_hosts_cleanup(msg)
        finally:
            msg.hide()

        if repaired:
            from .proxy.master import has_stale_hosts_entries, hosts_file_size

            repaired_size = hosts_file_size()
            if repaired_size is not None and repaired_size <= limit and not has_stale_hosts_entries():
                log_buffer.log('Hosts', 'Verified oversized hosts file was repaired successfully')
                if on_repaired is not None:
                    on_repaired()
                return True

        failure_details = dict(details)
        failure_details.update(
            {
                'error_code': 'hosts_file_repair_failed',
                'error': (
                    'Fleasion could not reduce the hosts file to a safe size. Rename or delete '
                    'the hosts file manually, then restart Fleasion.'
                ),
            }
        )
        log_buffer.log('Hosts', 'Safe repair did not produce a usable hosts file')
        _show_hosts_write_exhausted_dialog(failure_details)
        return False


def _show_hosts_capacity_dialog(details: dict) -> None:
    """Explain that a normal-sized hosts file cannot fit new mappings safely."""
    import os

    hosts_path = str(details.get('hosts_path') or r'C:\Windows\System32\drivers\etc\hosts')
    hosts_directory = str(
        details.get('hosts_directory')
        or os.path.dirname(hosts_path)
        or r'C:\Windows\System32\drivers\etc'
    )
    limit = int(details.get('hosts_size_limit_bytes') or 512 * 1024)
    candidate_size = int(details.get('hosts_size_bytes') or 0)
    msg = QMessageBox(_visible_parent_widget())
    msg.setWindowTitle('Fleasion - Hosts File Near Safety Limit')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText('Fleasion did not modify your hosts file.')
    msg.setInformativeText(
        f'Adding Fleasion entries would make it {candidate_size / (1024 * 1024):.1f} MiB, '
        f'which exceeds Fleasion’s {limit / 1024:.0f} KiB safety limit. No mappings were '
        'added. Remove obsolete hosts-file lines or rename the file, then restart Fleasion.'
        f'\n\nHosts file path:\n{hosts_path}'
    )
    open_dir_button = msg.addButton('Open Hosts Directory', QMessageBox.ButtonRole.ActionRole)
    msg.addButton(QMessageBox.StandardButton.Ok)
    msg.exec()
    if msg.clickedButton() == open_dir_button:
        try:
            open_folder(Path(hosts_directory))
        except OSError as exc:
            log_buffer.log('Hosts', f'Could not open hosts directory: {exc}')


def _show_env_proxy_stale_hosts_dialog() -> bool:
    """Offer a one-shot privileged repair for oversized or stale Env Proxy hosts entries."""
    from .proxy.master import (
        INTERCEPT_HOSTS,
        _other_proxy_owner_alive,
        has_stale_hosts_entries,
        hosts_file_is_oversized,
    )

    if _other_proxy_owner_alive():
        log_buffer.log(
            'Hosts',
            'Skipped Env Proxy stale hosts prompt because another proxy owns the hosts file',
        )
        return True
    oversized_details: dict = {}
    if hosts_file_is_oversized(oversized_details):
        return _show_oversized_hosts_file_dialog(oversized_details)
    if not has_stale_hosts_entries(set(INTERCEPT_HOSTS)):
        return True

    parent = _visible_parent_widget()
    msg = QMessageBox(parent)
    msg.setWindowTitle('Fleasion - Stale Hosts File Entries')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText('Fleasion found stale Env Proxy entries in your system hosts file.')
    msg.setInformativeText(
        'The hosts file is protected by the operating system, so Fleasion cannot safely '
        'repair it as your normal user.\n\n'
        'Fix Hosts File runs a temporary administrator/root child that removes only '
        'Fleasion-owned entries, flushes DNS, and exits. It does not keep Fleasion running '
        'as administrator.\n\n'
        'If you continue without fixing it, those stale entries may keep redirecting Roblox '
        'hosts for other applications.'
    )
    fix_button = msg.addButton('Fix Hosts File (Recommended)', QMessageBox.ButtonRole.AcceptRole)
    continue_button = msg.addButton('Continue Without Fixing', QMessageBox.ButtonRole.RejectRole)
    msg.setDefaultButton(fix_button)
    msg.exec()

    if msg.clickedButton() != fix_button:
        log_buffer.log('Hosts', 'User deferred privileged Env Proxy stale hosts cleanup')
        return True

    fix_button.setEnabled(False)
    continue_button.setEnabled(False)
    if sys.platform == 'win32':
        msg.setText('Waiting for Windows administrator permission...')
        msg.setInformativeText(
            'Approve the UAC prompt to remove the stale Fleasion hosts entries.\n\n'
            'If the prompt is flashing on the taskbar, click it and choose Yes or No.'
        )
    else:
        msg.setText('Waiting for administrator/root permission...')
        msg.setInformativeText(
            'Approve the operating-system permission prompt to remove the stale Fleasion '
            'hosts entries.'
        )
    msg.show()
    msg.raise_()
    msg.activateWindow()
    QApplication.processEvents()
    try:
        repaired = _run_privileged_hosts_cleanup(msg)
    finally:
        msg.hide()

    if repaired:
        if not has_stale_hosts_entries(set(INTERCEPT_HOSTS)):
            log_buffer.log('Hosts', 'Verified stale Env Proxy hosts entries were removed')
            return True
        detail = 'The administrator child completed, but stale Fleasion entries are still present.'
    else:
        detail = 'Fleasion could not obtain administrator permission or the cleanup child failed.'

    log_buffer.log('Hosts', f'Privileged Env Proxy stale hosts cleanup failed: {detail}')
    QMessageBox.warning(
        parent,
        'Fleasion - Hosts File Still Needs Repair',
        f'{detail}\n\nEnv Proxy may start, but the stale entries can still affect other applications.',
    )
    return True


def _should_sync_autostart_on_launch(run_on_boot: bool) -> bool:
    if not run_on_boot:
        return False
    if sys.platform == 'darwin':
        return not _is_admin()
    if sys.platform.startswith('linux'):
        return True
    if sys.platform == 'win32':
        return True
    return False


def _refresh_run_on_boot_ui(tray, enabled: bool) -> None:
    if tray is not None and hasattr(tray, 'run_on_boot_action'):
        tray.run_on_boot_action.setChecked(enabled)
    if tray is not None and hasattr(tray, '_refresh_settings_tab'):
        tray._refresh_settings_tab()


def _refresh_desktop_integration_ui(tray, enabled: bool) -> None:
    if tray is not None and hasattr(tray, 'desktop_integration_action'):
        tray.desktop_integration_action.setChecked(enabled)
    if tray is not None and hasattr(tray, '_refresh_settings_tab'):
        tray._refresh_settings_tab()


def _show_run_on_boot_failure(
    parent, proxy_mode: str | None = None, *, enabled: bool = True
) -> bool:
    msg = QMessageBox(parent)
    msg.setWindowTitle('Run on Boot Needs Repair' if enabled else 'Run on Boot Could Not Be Disabled')
    msg.setIcon(QMessageBox.Icon.Warning)
    if sys.platform == 'win32':
        from .utils.autostart import windows_autostart_privilege_hint

        if enabled:
            msg.setText(
                'Fleasion could not update its Run on Boot task.\n\n'
                'Repair it now with one administrator approval? The repair updates the task '
                'for your current Windows account and confirms whether it worked.\n\n'
                f'{windows_autostart_privilege_hint(proxy_mode)}'
            )
        else:
            msg.setText(
                'Fleasion could not remove its legacy Run on Boot task.\n\n'
                'Remove it now with one administrator approval? This removes startup for '
                'your current Windows account and confirms whether it worked.'
            )
    else:
        msg.setText(
            'Failed to register autostart.\n'
            'Check the application log for details.\n\n'
            'Turn off Run on Boot to stop this error from appearing.'
        )
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    repair_button = None
    if sys.platform == 'win32':
        repair_label = 'Repair Now (Recommended)' if enabled else 'Remove Task Now (Recommended)'
        repair_button = msg.addButton(repair_label, QMessageBox.ButtonRole.AcceptRole)
        ignore_button = msg.addButton('Keep Run on Boot Enabled', QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(ignore_button)
    else:
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    msg.exec()

    if repair_button is not None and msg.clickedButton() == repair_button:
        repair_args = '--repair-autostart' if enabled else '--repair-autostart --disable-autostart'
        if _relaunch_as_admin(
            extra_args=repair_args,
            parent_hwnd=_window_handle(parent),
            wait_for_completion=True,
        ):
            log_buffer.log(
                'Autostart',
                'Elevated autostart repair completed'
                if enabled
                else 'Elevated legacy autostart-task removal completed',
            )
            msg.setWindowTitle('Run on Boot Fixed' if enabled else 'Run on Boot Disabled')
            msg.setIcon(QMessageBox.Icon.Information)
            if enabled:
                msg.setText(
                    'It worked — Fleasion repaired the Run on Boot task for your current '
                    'Windows account.\n\n'
                    'You do not need to run the repair again. Fleasion will start automatically '
                    'the next time you sign in.'
                )
            else:
                msg.setText(
                    'It worked — Fleasion removed the legacy Run on Boot task for your '
                    'current Windows account.\n\n'
                    'Fleasion will no longer start automatically when you sign in.'
                )
            msg.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg.exec()
            return True
        else:
            log_buffer.log(
                'Autostart',
                'Elevated autostart repair did not complete successfully'
                if enabled
                else 'Elevated legacy autostart-task removal did not complete successfully',
            )
            msg.setWindowTitle(
                'Run on Boot Repair Incomplete' if enabled else 'Run on Boot Disable Incomplete'
            )
            msg.setIcon(QMessageBox.Icon.Warning)
            msg.setText(
                'Fleasion could not confirm that the Run on Boot task was repaired.\n\n'
                'The administrator prompt may have been canceled, or Windows rejected the '
                'task update. No further repair was started automatically.'
            )
            msg.setStandardButtons(QMessageBox.StandardButton.Ok)
            msg.exec()
    return False


def _show_roblox_permission_failure(
    parent,
    denied_dirs,
    mod_manager=None,
    *,
    on_repaired=None,
    failure_text: str | None = None,
) -> None:
    """Ask before permanently granting this Windows user access to failed installs."""
    if sys.platform != 'win32':
        return
    paths = sorted(
        {Path(path).resolve() for path in denied_dirs}, key=lambda value: str(value).lower()
    )
    if not paths:
        return

    msg = QMessageBox(parent)
    msg.setWindowTitle('Roblox Installation Permission Required')
    msg.setIcon(QMessageBox.Icon.Warning)
    listed_paths = '\n'.join(f'- {path}' for path in paths)
    failure_text = failure_text or (
        'Fleasion could not write configured modifications or FastFlags to these Roblox '
        'Player installations'
    )
    msg.setText(
        f'{failure_text}:\n\n{listed_paths}\n\n'
        'Would you like to permanently grant your current Windows account Modify access '
        'to only these installation folders? Existing permissions are preserved. '
        'This requires a one-time administrator prompt.'
    )
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    grant_button = msg.addButton(
        'Grant access for this Windows user', QMessageBox.ButtonRole.AcceptRole
    )
    ignore_button = msg.addButton('Ignore', QMessageBox.ButtonRole.RejectRole)
    msg.setDefaultButton(ignore_button)
    msg.exec()

    if msg.clickedButton() != grant_button:
        return

    from .utils.windows_permissions import (
        clear_repair_result,
        clear_pending_repair,
        write_pending_repair,
    )

    try:
        clear_repair_result(CONFIG_DIR)
        if not write_pending_repair(paths, CONFIG_DIR):
            raise OSError('No valid Roblox installation folders were selected')
        relaunched = _relaunch_as_admin(
            extra_args='--repair-roblox-permissions',
            parent_hwnd=_window_handle(parent),
        )
    except Exception as exc:
        clear_pending_repair(CONFIG_DIR)
        log_buffer.log('RobloxPermissions', f'Could not start elevated ACL repair: {exc}')
        return

    if relaunched:
        log_buffer.log(
            'RobloxPermissions',
            'Elevated ACL repair started for the selected Roblox installations',
        )
        if mod_manager is not None:
            deadline = time.monotonic() + _WINDOWS_REPAIR_RESULT_TIMEOUT_SECONDS
            QTimer.singleShot(
                500,
                lambda: _poll_roblox_permission_repair(
                    mod_manager,
                    deadline,
                    on_repaired=on_repaired,
                ),
            )
        elif on_repaired is not None:
            deadline = time.monotonic() + _WINDOWS_REPAIR_RESULT_TIMEOUT_SECONDS
            QTimer.singleShot(
                500,
                lambda: _poll_roblox_permission_repair(
                    None,
                    deadline,
                    on_repaired=on_repaired,
                ),
            )
    else:
        clear_pending_repair(CONFIG_DIR)


def _poll_roblox_permission_repair(mod_manager, deadline: float, *, on_repaired=None) -> None:
    """Consume a one-shot elevated ACL result and retry the normal write path."""
    from .utils.windows_permissions import (
        clear_pending_repair,
        clear_repair_result,
        read_repair_result,
    )

    result = read_repair_result(CONFIG_DIR)
    if result is None:
        if time.monotonic() < deadline:
            QTimer.singleShot(
                500,
                lambda: _poll_roblox_permission_repair(
                    mod_manager,
                    deadline,
                    on_repaired=on_repaired,
                ),
            )
            return
        clear_pending_repair(CONFIG_DIR)
        clear_repair_result(CONFIG_DIR)
        log_buffer.log(
            'RobloxPermissions',
            'Timed out waiting for the elevated Roblox permission repair',
        )
        QMessageBox.warning(
            _visible_parent_widget(),
            'Roblox Permission Repair Timed Out',
            'Fleasion did not receive a result from the administrator process. '
            'No additional permission repair will be attempted automatically.',
        )
        return

    clear_repair_result(CONFIG_DIR)
    clear_pending_repair(CONFIG_DIR)
    if result.get('ok'):
        log_buffer.log(
            'RobloxPermissions',
            f'Granted Modify access to {len(result.get("granted", []))} Roblox installation(s)',
        )
        if mod_manager is not None:
            run_in_thread(mod_manager.reapply_all)()
        if on_repaired is not None:
            on_repaired()
        return

    detail = result.get('error') or result.get('failed') or 'icacls could not update the ACL'
    log_buffer.log('RobloxPermissions', f'ACL repair failed: {detail}')
    msg = QMessageBox(_visible_parent_widget())
    msg.setWindowTitle('Roblox Permission Repair Failed')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(
        'Fleasion could not update the permissions for one or more Roblox installations.\n\n'
        f'{detail}'
    )
    msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    msg.exec()


def _poll_windows_firewall_repair(deadline: float) -> None:
    """Consume a one-shot elevated firewall result and explain the outcome."""
    from .utils.windows_firewall import (
        clear_pending_repair,
        clear_repair_result,
        read_repair_result,
    )

    result = read_repair_result(CONFIG_DIR)
    if result is None:
        if time.monotonic() < deadline:
            QTimer.singleShot(500, lambda: _poll_windows_firewall_repair(deadline))
            return
        clear_pending_repair(CONFIG_DIR)
        clear_repair_result(CONFIG_DIR)
        log_buffer.log('WindowsFirewall', 'Timed out waiting for the elevated firewall repair')
        QMessageBox.warning(
            _visible_parent_widget(),
            'Fleasion Firewall Repair Timed Out',
            'Fleasion did not receive a result from the administrator process.\n\n'
            'You can retry the repair or open Windows Firewall settings manually.',
        )
        return

    clear_repair_result(CONFIG_DIR)
    clear_pending_repair(CONFIG_DIR)
    if result.get('ok'):
        log_buffer.log(
            'WindowsFirewall',
            f'Added {len(result.get("rules", []))} Fleasion firewall rule(s)',
        )
        QMessageBox.information(
            _visible_parent_widget(),
            'Fleasion Firewall Updated',
            'Windows Firewall now allows Fleasion on Private and Public networks.\n\n'
            'Try the Roblox action again.',
        )
        return

    detail = result.get('error') or result.get('failed') or 'netsh could not update the rules'
    log_buffer.log('WindowsFirewall', f'Firewall repair failed: {detail}')
    QMessageBox.warning(
        _visible_parent_widget(),
        'Fleasion Firewall Repair Failed',
        'Fleasion could not update Windows Firewall.\n\n'
        f'{detail}\n\nYou can open Windows Firewall settings manually to review the block.',
    )


def _show_desktop_integration_failure(parent) -> None:
    msg = QMessageBox(parent)
    msg.setWindowTitle('Desktop Integration Failed')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(
        'Failed to create desktop/start menu integration.\n'
        'Check the application log for details.\n\n'
        'Turn off desktop integration creation to stop this error from appearing.'
    )
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))
    msg.exec()


def _prompt_first_time_startup_options(config_manager: ConfigManager, tray=None) -> None:
    """Ask first-time users which startup integrations Fleasion should create."""
    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    dialog = QDialog(_parent)
    dialog.setModal(True)
    dialog.setWindowTitle('Startup Integration')
    if _on_top:
        dialog.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        dialog.setWindowIcon(QIcon(str(icon_path)))

    layout = QVBoxLayout(dialog)
    label = QLabel(dialog)
    label.setWordWrap(True)
    message = (
        'Choose how Fleasion should integrate with your system.\n\n'
        'Run on Boot launches Fleasion when you sign in. Desktop/start menu integration adds '
        'Fleasion to your operating system launcher and is refreshed on each launch.'
    )
    if sys.platform == 'win32':
        message += (
            '\n\nRun on Boot uses a normal per-user task. Hosts File mode may still '
            'request administrator permission after Fleasion starts.'
        )
    label.setText(message)
    layout.addWidget(label)

    checkbox_row = QHBoxLayout()
    run_on_boot_chk = QCheckBox('Run on Boot', dialog)
    desktop_integration_chk = QCheckBox('Desktop/Start Menu Integration', dialog)
    run_on_boot_chk.setChecked(config_manager.run_on_boot)
    desktop_integration_chk.setChecked(config_manager.desktop_integration)
    checkbox_row.addWidget(run_on_boot_chk)
    checkbox_row.addWidget(desktop_integration_chk)
    checkbox_row.addStretch(1)
    layout.addLayout(checkbox_row)

    button_row = QHBoxLayout()
    ok_button = QPushButton('OK', dialog)
    ok_button.setDefault(True)
    ok_button.setAutoDefault(True)
    button_row.addStretch(1)
    button_row.addWidget(ok_button)
    layout.addLayout(button_row)
    ok_button.clicked.connect(dialog.accept)

    ok_button.setFocus(Qt.FocusReason.OtherFocusReason)
    dialog.show()
    dialog.raise_()
    dialog.activateWindow()
    dialog.exec()

    enable_run_on_boot = run_on_boot_chk.isChecked()
    enable_desktop_integration = desktop_integration_chk.isChecked()
    try:
        from .utils.desktop_integration import sync_desktop_integration

        desktop_ok = sync_desktop_integration(enable_desktop_integration)
    except Exception as exc:
        desktop_ok = False
        log_buffer.log('DesktopIntegration', f'First-time desktop integration prompt failed: {exc}')

    try:
        from .utils.autostart import sync_autostart

        boot_ok = sync_autostart(
            enable_run_on_boot,
            CONFIG_DIR,
            proxy_mode=config_manager.proxy_mode,
        )
    except Exception as exc:
        boot_ok = False
        log_buffer.log('Autostart', f'First-time run-on-boot prompt failed: {exc}')

    config_manager.run_on_boot = enable_run_on_boot if boot_ok else False
    config_manager.desktop_integration = enable_desktop_integration if desktop_ok else False
    _refresh_run_on_boot_ui(tray, config_manager.run_on_boot)
    _refresh_desktop_integration_ui(tray, config_manager.desktop_integration)

    if enable_run_on_boot and not boot_ok:
        _show_run_on_boot_failure(dialog.parentWidget(), config_manager.proxy_mode)
    if enable_desktop_integration and not desktop_ok:
        _show_desktop_integration_failure(dialog.parentWidget())


def _append_windows_requesting_user_args(existing_args: list[str]) -> bool:
    """Carry the pre-UAC desktop identity into a one-shot elevated child."""
    if sys.platform != 'win32':
        return True
    if any(arg.startswith('--fleasion-requesting-user-sid=') for arg in existing_args):
        return True
    try:
        from .utils.windows_permissions import current_windows_user_identity

        sid, _account_name = current_windows_user_identity()
    except Exception as exc:
        log_buffer.log('UAC', f'Could not capture requesting Windows identity: {exc}')
        return False
    existing_args.extend(
        [
            f'--fleasion-requesting-user-sid={sid}',
        ]
    )
    return True


def _relaunch_as_admin(
    extra_args: str = '',
    parent_hwnd: int | None = None,
    *,
    wait_for_completion: bool = False,
    wait_timeout_ms: int = 120_000,
    completion: dict[str, int | bool] | None = None,
) -> bool:
    """Silently attempt to relaunch elevated via the platform prompt.

    Shows only the standard Windows UAC or macOS administrator prompt.
    Returns True if the elevated process was spawned (caller should exit), or,
    when ``wait_for_completion`` is set, if the elevated child completed with
    exit code zero. ``completion`` receives the native wait and exit-code
    details for synchronous callers that need a more specific failure reason.
    Returns False if the user declined or the relaunch failed.
    """
    if sys.platform == 'darwin':
        existing_args = sys.argv[1:]
        if not any(arg.startswith('--fleasion-user-localappdata=') for arg in existing_args):
            existing_args.append(f'--fleasion-user-localappdata={CONFIG_DIR.parent}')
        if extra_args.strip():
            existing_args.extend(extra_args.strip().split())

        if getattr(sys, 'frozen', False):
            launch = [sys.executable, *existing_args]
            redirect = ' >/tmp/fleasion-admin.log 2>&1'
            if not wait_for_completion:
                redirect += ' &'
            shell_cmd = (
                f'FLEASION_USER_HOME={shlex.quote(str(Path.home()))} {shlex.join(launch)}{redirect}'
            )
        else:
            project_root = Path(__file__).resolve().parents[2]
            launcher = project_root / 'launcher.py'
            python_exe = Path(sys.executable)
            launch = [str(python_exe), str(launcher), *existing_args]
            redirect = ' >/tmp/fleasion-admin.log 2>&1'
            if not wait_for_completion:
                redirect += ' &'
            shell_cmd = (
                f'cd {shlex.quote(str(project_root))} && '
                f'FLEASION_USER_HOME={shlex.quote(str(Path.home()))} '
                f'PYTHONPATH={shlex.quote(str(project_root / "src"))} '
                f'{shlex.join(launch)}{redirect}'
            )

        script = 'do shell script ' + json.dumps(shell_cmd) + ' with administrator privileges'
        try:
            result = subprocess.run(
                ['osascript', '-e', script],
                capture_output=True,
                text=True,
                timeout=120,
            )
        except Exception as exc:
            log_buffer.log('UAC', f'macOS administrator relaunch failed: {exc}')
            return False

        if result.returncode != 0:
            err = (result.stderr or result.stdout or '').strip()
            log_buffer.log(
                'UAC',
                f'macOS administrator relaunch was cancelled or failed: {err or result.returncode}',
            )
            return False
        return True

    if sys.platform.startswith('linux'):
        log_buffer.log(
            'UAC',
            'Linux administrator relaunch skipped: proxy uses the privileged helper instead',
        )
        return False

    import ctypes

    existing_args = sys.argv[1:]
    if not any(arg.startswith('--fleasion-user-localappdata=') for arg in existing_args):
        local_appdata = os.environ.get('LOCALAPPDATA') or str(CONFIG_DIR.parent)
        existing_args.append(f'--fleasion-user-localappdata={local_appdata}')
    if extra_args.strip():
        existing_args.extend(extra_args.strip().split())
    requesting_identity_captured = _append_windows_requesting_user_args(existing_args)
    if extra_args.strip().startswith(
        ('--repair-autostart', '--repair-roblox-permissions')
    ) and not (requesting_identity_captured):
        return False
    # ShellExecuteEx returns as soon as the elevated child is created, while
    # this normal-user Qt process can still own the single-instance slot.  Let
    # the elevated copy request a clean exit from that parent before it tries
    # to claim the slot; otherwise it falls into the duplicate-instance dialog
    # and no dashboard is shown.
    if '--kill-others' not in existing_args:
        existing_args.append('--kill-others')

    frozen = bool(getattr(sys, 'frozen', False))
    if frozen:
        # Compiled .exe — sys.executable is the .exe itself
        exe = sys.executable
        params = subprocess.list2cmdline(existing_args) if existing_args else None
    else:
        # Dev / uv run — locate the uv executable and replay the original
        # invocation through it.  Running the Python interpreter directly in
        # the elevated process would miss the uv-managed virtualenv entirely,
        # causing import failures and a silent crash.
        import shutil

        uv_exe = shutil.which('uv') or shutil.which('uv.exe')
        if uv_exe:
            # Reconstruct:  uv run fleasion  (the original entry-point)
            exe = uv_exe
            # Pass the project directory so uv finds pyproject.toml correctly
            cwd = str(Path(__file__).resolve().parents[2])
            # ShellExecuteW doesn't let us set cwd directly for the child, but
            # we can pass --project to tell uv where to look.
            params = subprocess.list2cmdline(['--project', cwd, 'run', 'fleasion', *existing_args])
        else:
            # Fallback: plain interpreter (may fail if venv is not activated,
            # but it's the best we can do without uv)
            exe = sys.executable
            params = subprocess.list2cmdline([sys.argv[0], *existing_args])

    # Use ShellExecuteExW with SEE_MASK_NO_CONSOLE so the elevated process
    # (which may be uv.exe, a console app) never spawns a visible cmd window.
    import ctypes.wintypes

    SEE_MASK_NO_CONSOLE = 0x00008000
    SEE_MASK_NOCLOSEPROCESS = 0x00000040

    class _SHELLEXECUTEINFOW(ctypes.Structure):
        _fields_ = [
            ('cbSize', ctypes.wintypes.DWORD),
            ('fMask', ctypes.wintypes.ULONG),
            ('hwnd', ctypes.wintypes.HWND),
            ('lpVerb', ctypes.wintypes.LPCWSTR),
            ('lpFile', ctypes.wintypes.LPCWSTR),
            ('lpParameters', ctypes.wintypes.LPCWSTR),
            ('lpDirectory', ctypes.wintypes.LPCWSTR),
            ('nShow', ctypes.c_int),
            ('hInstApp', ctypes.wintypes.HINSTANCE),
            ('lpIDList', ctypes.c_void_p),
            ('lpClass', ctypes.wintypes.LPCWSTR),
            ('hkeyClass', ctypes.wintypes.HKEY),
            ('dwHotKey', ctypes.wintypes.DWORD),
            ('hIconOrMonitor', ctypes.wintypes.HANDLE),
            ('hProcess', ctypes.wintypes.HANDLE),
        ]

    sei = _SHELLEXECUTEINFOW()
    sei.cbSize = ctypes.sizeof(_SHELLEXECUTEINFOW)
    sei.fMask = SEE_MASK_NO_CONSOLE | SEE_MASK_NOCLOSEPROCESS
    sei.hwnd = parent_hwnd
    sei.lpVerb = 'runas'
    sei.lpFile = exe
    sei.lpParameters = params
    sei.lpDirectory = os.path.dirname(os.path.abspath(exe)) or None
    # SW_HIDE (0) for dev/uv mode: hides the uv.exe console wrapper.
    # SW_SHOWNORMAL (1) for compiled .exe: the exe IS the app, we need windows to show.
    sei.nShow = 1 if frozen else 0
    sei.hInstApp = None

    shell32 = ctypes.WinDLL('shell32', use_last_error=True)
    shell32.ShellExecuteExW.argtypes = [ctypes.POINTER(_SHELLEXECUTEINFOW)]
    shell32.ShellExecuteExW.restype = ctypes.wintypes.BOOL

    reset_env_key = 'PYINSTALLER_RESET_ENVIRONMENT'
    old_reset_env = os.environ.get(reset_env_key)
    if frozen:
        os.environ[reset_env_key] = '1'
    try:
        ok = shell32.ShellExecuteExW(ctypes.byref(sei))
    finally:
        if frozen:
            if old_reset_env is None:
                os.environ.pop(reset_env_key, None)
            else:
                os.environ[reset_env_key] = old_reset_env
    if not ok:
        err = ctypes.get_last_error()
        if err == 1223:  # ERROR_CANCELLED: user declined UAC
            log_buffer.log('UAC', 'Administrator relaunch was cancelled by the user')
        else:
            log_buffer.log(
                'UAC',
                f'Administrator relaunch failed: WinError {err}: {ctypes.FormatError(err)}',
            )
        return False

    if not wait_for_completion:
        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel32.CloseHandle.argtypes = [ctypes.wintypes.HANDLE]
        kernel32.CloseHandle.restype = ctypes.wintypes.BOOL
        kernel32.CloseHandle(sei.hProcess)
        return True

    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel32.WaitForSingleObject.argtypes = [ctypes.wintypes.HANDLE, ctypes.wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = ctypes.wintypes.DWORD
    kernel32.GetExitCodeProcess.argtypes = [
        ctypes.wintypes.HANDLE,
        ctypes.POINTER(ctypes.wintypes.DWORD),
    ]
    kernel32.GetExitCodeProcess.restype = ctypes.wintypes.BOOL
    kernel32.CloseHandle.argtypes = [ctypes.wintypes.HANDLE]
    kernel32.CloseHandle.restype = ctypes.wintypes.BOOL
    wait_result = kernel32.WaitForSingleObject(sei.hProcess, wait_timeout_ms)
    exit_code = ctypes.wintypes.DWORD()
    exit_code_read = False
    if wait_result != _WINDOWS_WAIT_TIMEOUT:
        exit_code_read = bool(kernel32.GetExitCodeProcess(sei.hProcess, ctypes.byref(exit_code)))
    completed = wait_result == 0 and exit_code_read and exit_code.value == 0
    kernel32.CloseHandle(sei.hProcess)
    if completion is not None:
        completion.update(
            {
                'wait_result': wait_result,
                'exit_code_read': exit_code_read,
                'exit_code': exit_code.value if exit_code_read else None,
            }
        )
    if not completed:
        if wait_result == _WINDOWS_WAIT_TIMEOUT:
            log_buffer.log(
                'UAC',
                f'Elevated child is still running after {wait_timeout_ms / 1000:.0f}s; '
                'the synchronous wait timed out',
            )
        else:
            log_buffer.log(
                'UAC',
                f'Elevated child did not complete successfully (wait={wait_result}, '
                f'exit={exit_code.value if exit_code_read else "unknown"})',
            )
    return completed


def _repair_autostart_once(
    requesting_user_sid: str | None = None, *, enabled: bool = True
) -> int:
    """Repair or remove Windows autostart from a one-shot elevated process."""
    if sys.platform != 'win32' or not _is_admin():
        log_buffer.log(
            'Autostart', 'Elevated autostart repair rejected: administrator access is required'
        )
        return 1

    from .utils.autostart import sync_autostart
    windows_user_id = None
    if enabled:
        from .utils.windows_permissions import windows_user_id_from_sid

        if not requesting_user_sid:
            log_buffer.log('Autostart', 'Elevated autostart repair has no requesting user identity')
            return 1

        try:
            windows_user_id = windows_user_id_from_sid(requesting_user_sid)
        except Exception as exc:
            log_buffer.log('Autostart', f'Invalid requesting Windows identity: {exc}')
            return 1

    try:
        proxy_mode = ConfigManager().proxy_mode
    except Exception:
        proxy_mode = None
    if sync_autostart(
        enabled,
        CONFIG_DIR,
        windows_user_id=windows_user_id,
        proxy_mode=proxy_mode,
    ):
        log_buffer.log(
            'Autostart',
            'Elevated autostart repair completed'
            if enabled
            else 'Elevated legacy autostart-task removal completed',
        )
        return 0

    log_buffer.log(
        'Autostart',
        'Elevated autostart repair failed'
        if enabled
        else 'Elevated legacy autostart-task removal failed',
    )
    return 1


def _repair_roblox_permissions_once(requesting_user_sid: str | None = None) -> int:
    """Apply a pending targeted Roblox ACL repair from a one-shot UAC child."""
    from .utils.windows_permissions import (
        clear_pending_repair,
        grant_current_user_modify_access,
        read_pending_repair,
        write_repair_result,
    )

    if sys.platform != 'win32' or not _is_admin():
        log_buffer.log(
            'RobloxPermissions',
            'Elevated Roblox ACL repair rejected: administrator access is required',
        )
        return 1

    if not requesting_user_sid:
        log_buffer.log(
            'RobloxPermissions',
            'Elevated Roblox ACL repair has no requesting user identity',
        )
        return 1

    paths = read_pending_repair(CONFIG_DIR)
    if not paths:
        result = {
            'ok': False,
            'granted': [],
            'failed': [],
            'error': 'No pending Roblox installation permission repair was found',
        }
    else:
        try:
            result = grant_current_user_modify_access(
                paths,
                user_sid=requesting_user_sid,
            )
        except Exception as exc:
            result = {
                'ok': False,
                'granted': [],
                'failed': [],
                'error': f'Unexpected ACL repair error: {exc}',
            }

    try:
        write_repair_result(result, CONFIG_DIR)
    finally:
        clear_pending_repair(CONFIG_DIR)

    if result.get('ok'):
        log_buffer.log('RobloxPermissions', 'Elevated Roblox ACL repair completed')
        return 0
    log_buffer.log('RobloxPermissions', f'Elevated Roblox ACL repair failed: {result}')
    return 1


def _repair_windows_firewall_once() -> int:
    """Apply a pending Fleasion firewall repair from a one-shot UAC child."""
    from .utils.windows_firewall import (
        clear_pending_repair,
        install_fleasion_firewall_rules,
        read_pending_repair,
        write_repair_result,
    )

    if sys.platform != 'win32' or not _is_admin():
        result = {
            'ok': False,
            'rules': [],
            'failed': [],
            'error': 'Administrator permission is required to update Windows Firewall',
        }
    elif not read_pending_repair(CONFIG_DIR):
        result = {
            'ok': False,
            'rules': [],
            'failed': [],
            'error': 'No pending Fleasion firewall repair was found',
        }
    else:
        try:
            result = install_fleasion_firewall_rules()
        except Exception as exc:
            result = {
                'ok': False,
                'rules': [],
                'failed': [],
                'error': f'Unexpected Windows Firewall repair error: {exc}',
            }

    try:
        write_repair_result(result, CONFIG_DIR)
    finally:
        clear_pending_repair(CONFIG_DIR)
    log_buffer.log(
        'WindowsFirewall',
        'Elevated Fleasion firewall repair completed'
        if result.get('ok')
        else f'Elevated Fleasion firewall repair failed: {result}',
    )
    return 0


def restart_fleasion_normally(*, preserve_env_proxy_player: bool = False) -> bool:
    """Relaunch Fleasion as a normal (non-elevated) process and return
    whether the new process was spawned - used when a setting change (e.g.
    switching the proxy mode back to Hosts File) needs a full restart to
    apply cleanly. Unlike ``_relaunch_as_admin``, this never triggers an
    OS elevation prompt, and is implemented for all three platforms (the
    admin version is a no-op stub on Linux). The caller is responsible for
    then exiting this process - it isn't done here, same as
    ``_relaunch_as_admin``.

    Reuses the frozen-vs-dev relaunch-command logic from
    ``_relaunch_as_admin`` (locating ``uv``/``launcher.py`` as needed) minus
    the ``runas``/``osascript administrator`` elevation wrapping, and passes
    ``--kill-others`` so the new process' own single-instance startup check
    asks this one to exit if there's ever a timing race between the two.
    """
    existing_args = [arg for arg in sys.argv[1:] if arg != '--preserve-env-proxy-player']
    if '--kill-others' not in existing_args:
        existing_args.append('--kill-others')
    if preserve_env_proxy_player:
        existing_args.append('--preserve-env-proxy-player')

    creationflags = 0
    popen_kwargs = {}

    if getattr(sys, 'frozen', False):
        launch = [sys.executable, *existing_args]
        if sys.platform != 'win32':
            popen_kwargs['start_new_session'] = True
    elif sys.platform == 'win32':
        import shutil

        uv_exe = shutil.which('uv') or shutil.which('uv.exe')
        if uv_exe:
            cwd = str(Path(__file__).resolve().parents[2])
            launch = [uv_exe, '--project', cwd, 'run', 'fleasion', *existing_args]
        else:
            launch = [sys.executable, sys.argv[0], *existing_args]
        # A dev/uv relaunch is a console app under the hood - avoid flashing
        # a visible console window for what should look like a GUI restart.
        creationflags = subprocess.CREATE_NO_WINDOW
    else:
        project_root = Path(__file__).resolve().parents[2]
        launcher = project_root / 'launcher.py'
        if launcher.exists():
            launch = [sys.executable, str(launcher), *existing_args]
        else:
            launch = [sys.executable, sys.argv[0], *existing_args]
        popen_kwargs['start_new_session'] = True

    if sys.platform == 'win32':
        popen_kwargs['creationflags'] = creationflags

    try:
        subprocess.Popen(launch, **popen_kwargs)
    except Exception as exc:
        log_buffer.log('Restart', f'Failed to relaunch Fleasion: {exc}')
        return False
    log_buffer.log('Restart', 'Relaunching Fleasion normally to apply a setting change')
    return True


def _attempt_silent_elevation(extra_args: str = '', parent_hwnd: int | None = None) -> bool:
    """Try to elevate silently on startup.

    If already admin, returns True immediately.
    Otherwise fires the UAC prompt. If the user accepts, the elevated
    copy launches and this function calls sys.exit(0) to close the
    non-elevated instance.  If the user declines, returns False so the
    caller continues in read-only mode — no extra dialog shown.
    """
    if _is_admin():
        return True

    success = _relaunch_as_admin(extra_args=extra_args, parent_hwnd=parent_hwnd)
    if success:
        # Elevated copy is now starting up — close this instance silently
        sys.exit(0)

    # User clicked "No" on UAC — stay open in read-only mode
    return False


def _visible_parent_widget():
    """Return the best visible Qt parent for startup dialogs."""
    _top = QApplication.topLevelWidgets()
    return next((w for w in _top if w.isVisible()), QApplication.activeWindow())


def _window_handle(widget) -> int | None:
    """Return a native window handle for ShellExecuteExW, if Qt has one."""
    if widget is None:
        return None
    try:
        return int(widget.winId())
    except Exception:
        return None


def _show_admin_required_dialog(parent=None):
    """Warn that the non-elevated instance cannot provide Fleasion's core behavior."""
    _top = QApplication.topLevelWidgets()
    _parent = parent or _visible_parent_widget()
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    msg = QMessageBox(_parent)
    if _on_top:
        msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    msg.setWindowTitle('Administrator Mode Required')
    msg.setIcon(QMessageBox.Icon.Warning)
    if sys.platform == 'darwin':
        msg.setText('Fleasion needs its macOS proxy helper before interception can start.')
        msg.setInformativeText(
            'Run Fleasion as your normal macOS user, then approve the proxy-helper install prompt. '
            'The helper owns port 443, updates /etc/hosts, and patches Roblox SSL trust while the app stays unprivileged.'
        )
    elif sys.platform.startswith('linux'):
        msg.setText('Fleasion needs administrator permission for Linux/Sober interception.')
        msg.setInformativeText(
            'Linux support targets the Sober Flatpak client.\n\n'
            'Asset interception, scraping, replacement, hosts-file changes, and the local HTTPS proxy need root access '
            'because Fleasion writes /etc/hosts and listens on local port 443.'
        )
    else:
        msg.setText("Fleasion won't work unless you're in admin mode.")
        msg.setInformativeText(
            'Windows did not start Fleasion with administrator rights.\n\n'
            'Asset interception, scraping, replacement, hosts-file changes, and the local HTTPS proxy may not work.\n\n'
            'Close Fleasion and run it as Administrator.'
        )
    msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))
    msg.exec()


def _show_proxy_bind_error_dialog(details: dict):
    """Show a user-facing popup when Fleasion cannot bind its proxy port."""
    port = int(details.get('port') or 443)
    owners = details.get('owners') or []
    bind_reason = str(details.get('bind_reason') or '')

    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    msg = QMessageBox(_parent)
    if _on_top:
        msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    msg.setWindowTitle('Proxy Port Conflict')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(f'Fleasion could not start its local proxy on port {port}.')

    if bind_reason == 'access_denied_or_reserved':
        owners_html = (
            f'Windows denied access to port {port}; it may be reserved or excluded even though '
            'no listening process appears in netstat.<br><br>'
        )
    elif owners:
        owner_lines = '<br>'.join(
            f'- {html.escape(str(owner.get("process_name") or "Unknown"))} '
            f'(PID {int(owner.get("pid") or 0)}) on '
            f'{html.escape(str(owner.get("local_address") or "0.0.0.0"))}:{port}'
            for owner in owners
        )
        owners_html = f'Port {port} is already in use by:<br>{owner_lines}<br><br>'
    else:
        owners_html = f'Port {port} is already in use by another process.<br><br>'

    discord_url = APP_DISCORD
    if not discord_url.startswith(('http://', 'https://')):
        discord_url = f'https://{discord_url}'

    msg.setTextFormat(Qt.TextFormat.RichText)
    msg.setInformativeText(
        owners_html
        + 'Close the conflicting process, then relaunch Fleasion.<br><br>'
        + f'Need help? <a href="{html.escape(discord_url)}">{html.escape(APP_DISCORD)}</a>'
    )
    msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    for label in msg.findChildren(QLabel):
        label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
            | Qt.TextInteractionFlag.TextSelectableByMouse
        )
        label.setOpenExternalLinks(True)

    msg.exec()


def _show_hosts_write_exhausted_dialog(details: dict):
    """Show a user-facing popup when hosts writes fail after all retries."""
    import os

    default_hosts_path = (
        '/etc/hosts'
        if sys.platform == 'darwin' or sys.platform.startswith('linux')
        else r'C:\Windows\System32\drivers\etc\hosts'
    )
    default_hosts_dir = (
        '/etc'
        if sys.platform == 'darwin' or sys.platform.startswith('linux')
        else r'C:\Windows\System32\drivers\etc'
    )
    hosts_path = str(details.get('hosts_path') or default_hosts_path)
    hosts_directory = str(
        details.get('hosts_directory') or os.path.dirname(hosts_path) or default_hosts_dir
    )
    raw_error = str(details.get('error') or '').strip()

    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    discord_url = APP_DISCORD
    if not discord_url.startswith(('http://', 'https://')):
        discord_url = f'https://{discord_url}'

    while True:
        msg = QMessageBox(_parent)
        if _on_top:
            msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        msg.setWindowTitle('Hosts File Write Failed')
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setText(
            'Fleasion could not modify the system hosts file after every write attempt was exhausted.'
        )

        diagnostics_html = ''
        if raw_error:
            diagnostics_html = 'Technical details:<br>' + html.escape(raw_error) + '<br><br>'

        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setInformativeText(
            'Most likely causes:<br>'
            'A) Antivirus/security software is protecting the hosts file '
            '(for example Webroot or Kaspersky).<br>'
            'B) A restrictive system permission setting is blocking writes.<br><br>'
            + f'Hosts file path:<br>{html.escape(hosts_path)}<br><br>'
            + 'Quick fix:<br>'
            + '1) Click "Click Here to Open Directory".<br>'
            + '2) Rename the file named "hosts" (no extension) to anything, or delete it.<br>'
            + '3) Restart Fleasion.<br><br>'
            + diagnostics_html
            + f'Need help? <a href="{html.escape(discord_url)}">{html.escape(APP_DISCORD)}</a>'
        )

        open_dir_button = msg.addButton(
            'Click Here to Open Directory', QMessageBox.ButtonRole.ActionRole
        )
        msg.addButton(QMessageBox.StandardButton.Ok)

        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            msg.setWindowIcon(QIcon(str(icon_path)))

        for label in msg.findChildren(QLabel):
            label.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextBrowserInteraction
                | Qt.TextInteractionFlag.TextSelectableByMouse
            )
            label.setOpenExternalLinks(True)

        msg.exec()

        if msg.clickedButton() == open_dir_button:
            try:
                open_folder(Path(hosts_directory))
            except OSError as exc:
                log_buffer.log('Hosts', f'Could not open hosts directory: {exc}')
            continue
        break


def _linux_hosts_nix_snippet(details: dict) -> str:
    raw_hosts = details.get('hosts') or (
        'apis.roblox.com',
        'assetdelivery.roblox.com',
        'contentdelivery.roblox.com',
        'fts.rbxcdn.com',
        'gamejoin.roblox.com',
    )
    hosts = sorted({str(host).strip().lower() for host in raw_hosts if str(host).strip()})
    if not hosts:
        hosts = [
            'apis.roblox.com',
            'assetdelivery.roblox.com',
            'contentdelivery.roblox.com',
            'fts.rbxcdn.com',
            'gamejoin.roblox.com',
        ]

    extra_hosts = '\n'.join(f'  127.0.0.1 {host}' for host in hosts)
    return "networking.extraHosts =\n''\n" + extra_hosts + "\n'';"


def _show_linux_hosts_read_only_dialog(details: dict):
    """Show Nix/NixOS guidance when /etc/hosts cannot be edited at runtime."""
    nix_snippet = _linux_hosts_nix_snippet(details)
    raw_error = str(details.get('error') or '').strip()
    hosts_path = str(details.get('hosts_path') or '/etc/hosts')

    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    msg = QMessageBox(_parent)
    if _on_top:
        msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    msg.setWindowTitle('Read-Only Hosts File')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText('Fleasion cannot edit the Linux hosts file on this read-only system.')
    msg.setTextFormat(Qt.TextFormat.RichText)
    msg.setInformativeText(
        f'The proxy helper got a read-only filesystem error while writing <code>{html.escape(hosts_path)}</code>. '
        'On Nix/NixOS, add these hosts declaratively and rebuild your system:<br><br>'
        '<b>In configuration.nix add:</b><br>'
        f'<pre>{html.escape(nix_snippet)}</pre>'
        'Then restart Fleasion after the rebuilt hosts file is active.'
        + (f'<br><br>Technical details:<br>{html.escape(raw_error)}' if raw_error else '')
    )
    copy_button = msg.addButton('Copy Nix Snippet', QMessageBox.ButtonRole.ActionRole)
    msg.addButton(QMessageBox.StandardButton.Ok)

    def _copy_nix_snippet():
        QApplication.clipboard().setText(nix_snippet)
        copy_button.setText('Copied')
        log_buffer.log('Hosts', 'Copied Nix extraHosts snippet to clipboard')

    copy_button.clicked.connect(_copy_nix_snippet)

    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    for label in msg.findChildren(QLabel):
        label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
            | Qt.TextInteractionFlag.TextSelectableByMouse
        )

    msg.exec()


def _show_macos_ca_patch_failed_dialog(details: dict):
    """Show a user-facing popup when Roblox cacert.pem cannot be verified."""
    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    failed = details.get('failed') or []
    verified = details.get('verified') or []
    failed_lines = []
    if isinstance(failed, list):
        for item in failed[:6]:
            if isinstance(item, dict):
                path = item.get('ca_file') or item.get('resource_dir') or '(unknown path)'
                error = item.get('error') or item.get('status') or 'unknown error'
                failed_lines.append(f'- {html.escape(str(path))}: {html.escape(str(error))}')

    unhealthy_lines = []
    if isinstance(verified, list):
        for item in verified[:6]:
            if isinstance(item, dict) and not item.get('healthy'):
                path = item.get('path') or '(unknown path)'
                error = item.get('error') or 'verification failed'
                unhealthy_lines.append(f'- {html.escape(str(path))}: {html.escape(str(error))}')

    diagnostics_html = ''
    if failed_lines or unhealthy_lines:
        diagnostics_html = '<br><br>Diagnostics:<br>' + '<br>'.join(failed_lines + unhealthy_lines)

    msg = QMessageBox(_parent)
    if _on_top:
        msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    msg.setWindowTitle('macOS Roblox CA Patch Failed')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(
        'Fleasion could not verify Roblox SSL trust patching, so the proxy was not started.'
    )
    msg.setTextFormat(Qt.TextFormat.RichText)
    msg.setInformativeText(
        'Roblox would reject Fleasion proxy certificates until its bundled '
        '<code>ssl/cacert.pem</code> contains the Fleasion CA exactly once.<br><br>'
        "A protected Roblox installation may need Fleasion's small privileged helper. "
        'If this keeps happening, repair or reinstall Roblox, then start Fleasion again.'
        + diagnostics_html
    )
    install_button = None
    if details.get('helper_required'):
        install_button = msg.addButton(
            'Install Helper and Retry', QMessageBox.ButtonRole.AcceptRole
        )
        msg.addButton('Not Now', QMessageBox.ButtonRole.RejectRole)
        msg.setDefaultButton(install_button)
    else:
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    for label in msg.findChildren(QLabel):
        label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
            | Qt.TextInteractionFlag.TextSelectableByMouse
        )

    msg.exec()
    return (
        'install_helper'
        if install_button is not None and msg.clickedButton() == install_button
        else None
    )


def _show_macos_ca_trust_failed_dialog(details: dict):
    """Explain why launcher traffic cannot be intercepted safely."""
    raw_error = html.escape(str(details.get('error') or 'unknown helper error'))
    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)

    msg = QMessageBox(_parent)
    msg.setWindowTitle('macOS Launcher CA Trust Failed')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(
        'Fleasion could not establish macOS trust for launcher network traffic, '
        'so the proxy was not started.'
    )
    msg.setTextFormat(Qt.TextFormat.RichText)
    msg.setInformativeText(
        'Froststrap and AppleBlox can contact intercepted Roblox endpoints before '
        'Roblox starts. Their HTTP clients require the same Fleasion CA to be trusted '
        'by macOS.<br><br>Unlock the login keychain if prompted, then restart Fleasion.'
        f'<br><br>Technical details:<br>{raw_error}'
    )
    msg.setStandardButtons(QMessageBox.StandardButton.Ok)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))
    msg.exec()


def _show_roblox_ca_patch_failed_dialog(details: dict) -> None:
    failed = details.get('failed') or []
    lines = []
    for item in failed[:8] if isinstance(failed, list) else []:
        if not isinstance(item, dict):
            continue
        path = item.get('ca_file') or item.get('resource_dir') or '(unknown path)'
        error = item.get('error') or item.get('status') or 'verification failed'
        lines.append(f'{path}: {error}')
    diagnostics = '\n'.join(lines) or str(
        details.get('error') or 'No writable Roblox installation was found.'
    )
    QMessageBox.critical(
        _visible_parent_widget(),
        'Fleasion - Roblox Files Are Protected',
        'Fleasion could not prepare Roblox Player for Env Proxy, so Roblox was not relaunched.\n\n'
        'Move or reinstall Roblox in a directory your user account can modify, then restart Fleasion.\n\n'
        f'Details:\n{diagnostics}',
    )


def _windows_ca_permission_denied_dirs(details: dict) -> list[Path]:
    """Return install directories whose CA patch failed due to Windows ACLs."""
    if sys.platform != 'win32':
        return []

    denied: set[Path] = set()
    failed = details.get('failed') or []
    for item in failed if isinstance(failed, list) else []:
        if not isinstance(item, dict):
            continue
        error = str(item.get('error') or '').lower()
        if not any(
            marker in error
            for marker in ('permission denied', 'access is denied', 'winerror 5', 'errno 13')
        ):
            continue
        resource_dir = item.get('resource_dir')
        if resource_dir:
            denied.add(Path(resource_dir))
            continue
        ca_file = item.get('ca_file')
        if ca_file:
            path = Path(ca_file)
            denied.add(path.parent.parent if path.parent.name.lower() == 'ssl' else path.parent)

    return sorted(denied, key=lambda path: str(path).lower())


def _show_macos_relay_failed_dialog(details: dict) -> str:
    """Explain a failed privileged relay and return the requested recovery action."""
    from .utils.macos_proxy_helper import HELPER_LOG_DIR

    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    backend_probe = details.get('backend_probe') or {}
    reachable = bool(backend_probe.get('reachable'))
    if reachable:
        probe_html = (
            'The helper can currently reach Fleasion’s backend, but TLS forwarding through '
            '<code>127.0.0.1:443</code> still failed.'
        )
    else:
        error_type = html.escape(str(backend_probe.get('error_type') or 'connection error'))
        error_text = html.escape(str(backend_probe.get('error') or 'No details were reported.'))
        probe_html = (
            'The helper could not reach Fleasion’s backend on '
            f'<code>127.0.0.1:{int(details.get("backend_port") or 58443)}</code>.<br>'
            f'Technical details: {error_type}: {error_text}'
        )

    attempts = int(details.get('attempts') or 1)
    while True:
        msg = QMessageBox(_parent)
        if _on_top:
            msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        msg.setWindowTitle('macOS Proxy Relay Failed')
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setText('Fleasion could not start its privileged local HTTPS relay.')
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setInformativeText(
            f'The relay was tested {attempts} times and the proxy was stopped before any '
            'Roblox hosts were redirected, so Roblox networking was left unchanged.<br><br>'
            f'{probe_html}<br><br>'
            'A stale helper or macOS firewall/network filter can cause this. Retry once, '
            'or reinstall the helper to restart and replace its LaunchDaemon.'
        )
        retry_button = msg.addButton('Retry', QMessageBox.ButtonRole.AcceptRole)
        reinstall_button = msg.addButton('Reinstall Helper', QMessageBox.ButtonRole.ActionRole)
        logs_button = msg.addButton('Open Helper Logs', QMessageBox.ButtonRole.ActionRole)
        close_button = msg.addButton(QMessageBox.StandardButton.Close)
        msg.setDefaultButton(reinstall_button)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            msg.setWindowIcon(QIcon(str(icon_path)))

        for label in msg.findChildren(QLabel):
            label.setTextInteractionFlags(
                Qt.TextInteractionFlag.TextBrowserInteraction
                | Qt.TextInteractionFlag.TextSelectableByMouse
            )

        msg.exec()
        clicked = msg.clickedButton()
        if clicked == retry_button:
            return 'retry'
        if clicked == reinstall_button:
            return 'reinstall'
        if clicked == logs_button:
            open_folder(HELPER_LOG_DIR)
            continue
        if clicked == close_button:
            return 'close'
        return 'close'


def _choose_macos_auth_source_on_launch(config_manager, tray=None, *, force: bool = False) -> str:
    """Ask macOS users which browser should be queried for Roblox auth."""
    if sys.platform != 'darwin':
        return 'unavailable'
    if config_manager.macos_auth_source and not force:
        try:
            from .utils.roblox_auth import get_roblosecurity, notify_auth_source_changed

            if get_roblosecurity(include_keychain_browsers=True):
                return 'already-configured'
            log_buffer.log(
                'Auth',
                f'Configured Roblox login source {config_manager.macos_auth_source} did not produce a valid token; reopening browser picker',
            )
            config_manager.macos_auth_source = ''
            notify_auth_source_changed()
        except Exception as exc:
            log_buffer.log(
                'Auth',
                f'Unexpected error while validating configured macOS auth source: {type(exc).__name__}: {exc}',
            )
            config_manager.macos_auth_source = ''

    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    dialog = _MacOSAuthSourceDialog(_parent)
    if _on_top:
        dialog.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    dialog.setWindowTitle('Roblox Login Source')
    dialog.setMinimumWidth(620)

    selected: dict[str, str] = {}
    buttons: list[QPushButton] = []
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(18, 18, 18, 18)
    layout.setSpacing(14)

    title = QLabel('Which browser is signed in to roblox.com?')
    title.setStyleSheet('font-size: 18px; font-weight: 700;')
    layout.addWidget(title)

    warning = QLabel(
        'Most Fleasion account-aware features will not work until a valid Roblox token is available: '
        'private asset downloads, account launches, authenticated asset details, subplace metadata, '
        'and private-server flows may fail or wait.'
    )
    warning.setWordWrap(True)
    warning.setStyleSheet('font-weight: 600; color: #e0a53a;')
    layout.addWidget(warning)

    body = QLabel(
        'Choose the browser where roblox.com is already signed in. macOS may ask for browser-data access; '
        'choose Always Allow to avoid approving it every launch. Fleasion will test the browser before saving it.'
    )
    body.setWordWrap(True)
    layout.addWidget(body)

    status = QLabel('')
    status.setWordWrap(True)
    layout.addWidget(status)

    def _set_busy(browser: str):
        status.setText(f'Checking {browser} for a valid Roblox login...')
        for btn in buttons:
            btn.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        QApplication.processEvents()

    def _set_ready(message: str):
        if QApplication.overrideCursor() is not None:
            QApplication.restoreOverrideCursor()
        status.setText(message)
        for btn in buttons:
            btn.setEnabled(True)

    def _save_and_accept(source: str) -> None:
        if QApplication.overrideCursor() is not None:
            QApplication.restoreOverrideCursor()
        selected['browser'] = source
        dialog.accept()

    def _exit_from_auth_prompt() -> None:
        _quit_after_modal_closes(dialog, tray, selected)

    def _show_safari_unsupported() -> None:
        message = (
            'Safari is not supported for Roblox login discovery on macOS because Safari stores cookies behind a '
            'different privacy model than the other supported browsers.\n\n'
            'Use one of the other browsers in the list instead: Chrome, Firefox, Brave, Edge, Chromium, Opera, or '
            'Vivaldi. Log in to roblox.com in that browser, come back to Fleasion, and select that browser.\n\n'
            'You do not have to use that browser for anything else. It only needs to stay logged in to roblox.com so '
            'Fleasion can read a valid Roblox token.'
        )
        msg = QMessageBox(dialog)
        msg.setWindowTitle('Safari Is Not Supported')
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setText('Safari cannot be used for Fleasion login discovery.')
        msg.setInformativeText(message)
        exit_button = msg.addButton('Exit Fleasion', QMessageBox.ButtonRole.DestructiveRole)
        msg.addButton(QMessageBox.StandardButton.Ok)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            msg.setWindowIcon(QIcon(str(icon_path)))
        msg.exec()
        if msg.clickedButton() == exit_button:
            _quit_after_modal_closes(dialog, tray, selected)

    grid = QGridLayout()
    grid.setHorizontalSpacing(8)
    grid.setVerticalSpacing(8)
    browsers = (
        'Chrome',
        'Safari',
        'Firefox',
        'Brave',
        'Edge',
        'Chromium',
        'Opera',
        'Vivaldi',
    )

    def _choose(browser: str) -> None:
        _set_busy(browser)
        try:
            from .utils.roblox_auth import discover_browser_roblosecurity

            cookie, source = discover_browser_roblosecurity(
                include_keychain=True,
                explicit_import=True,
                browser=browser,
            )
        except Exception as exc:
            log_buffer.log(
                'Auth',
                f'Unexpected error while checking {browser}: {type(exc).__name__}: {exc}',
            )
            _set_ready(f'{browser} could not be checked: {type(exc).__name__}: {exc}')
            return
        if cookie:
            _save_and_accept(source or browser)
            return
        if browser == 'Safari':
            _set_ready(
                'Safari is not supported for Fleasion login discovery on macOS. Log in to roblox.com in another browser '
                'from the list, then select that browser instead.'
            )
            _show_safari_unsupported()
            return
        _set_ready(
            f'No valid Roblox login token was found in {browser}. Choose another browser, import a token manually, '
            'or continue without a token.'
        )

    for index, browser in enumerate(browsers):
        button = QPushButton(browser)
        button.setMinimumHeight(34)
        button.clicked.connect(lambda _checked=False, value=browser: _choose(value))
        grid.addWidget(button, index // 4, index % 4)
        buttons.append(button)
    layout.addLayout(grid)

    footer = QHBoxLayout()
    footer.addStretch()
    exit_btn = QPushButton('Exit Fleasion')
    footer.addWidget(exit_btn)
    manual_btn = QPushButton('Import Token Manually')
    footer.addWidget(manual_btn)
    skip_btn = QPushButton('Continue Without Token')
    footer.addWidget(skip_btn)
    layout.addLayout(footer)
    buttons.extend((manual_btn, skip_btn))

    def _manual_import() -> None:
        from .gui.rando_stuff_tab import AddAccountDialog
        from .utils.roblox_auth import (
            store_manual_roblosecurity,
            validate_roblosecurity_for_import,
        )

        dlg = AddAccountDialog(dialog, title='Import Roblox Token')
        dlg.set_ok_label('Import')
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            dlg.setWindowIcon(QIcon(str(icon_path)))
        if dlg.exec() != QDialog.DialogCode.Accepted or not dlg.result_cookie:
            return
        valid, detail = validate_roblosecurity_for_import(dlg.result_cookie)
        if not valid:
            QMessageBox.warning(
                dialog,
                'Invalid Roblox Token',
                f'Fleasion could not confirm this Roblox token is valid.\n\n{detail}',
            )
            return
        if not store_manual_roblosecurity(dlg.result_cookie):
            QMessageBox.warning(
                dialog,
                'Token Import Failed',
                'Fleasion could not store the Roblox token encrypted.',
            )
            return
        _save_and_accept('manual')

    def _continue_without_token() -> None:
        selected['continue_without_token'] = '1'
        dialog.allow_reject = True
        dialog.reject()

    manual_btn.clicked.connect(_manual_import)
    skip_btn.clicked.connect(_continue_without_token)
    exit_btn.clicked.connect(_exit_from_auth_prompt)

    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        dialog.setWindowIcon(QIcon(str(icon_path)))

    dialog.exec()
    if selected_browser := selected.get('browser'):
        config_manager.macos_auth_source = selected_browser
        try:
            from .utils.roblox_auth import notify_auth_source_changed

            notify_auth_source_changed()
        except Exception:
            pass
        if tray is not None and hasattr(tray, '_refresh_settings_tab'):
            tray._refresh_settings_tab()
        return 'selected'
    if selected.get('continue_without_token'):
        return 'skipped'
    if selected.get('exit'):
        return 'exiting'
    return 'dismissed'


def _show_auth_cookie_unavailable_dialog(details: dict, tray=None):
    """Show a user-facing popup when no readable Roblox auth cookie can be found."""
    _top = QApplication.topLevelWidgets()
    _parent = next((w for w in _top if w.isVisible()), None)
    _on_top = any(
        w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint) for w in _top
    )

    discord_url = APP_DISCORD
    if not discord_url.startswith(('http://', 'https://')):
        discord_url = f'https://{discord_url}'

    attempted = details.get('attempted_paths') or []
    existing = details.get('existing_paths') or []
    if not isinstance(attempted, list):
        attempted = []
    if not isinstance(existing, list):
        existing = []

    existing_html = ''
    if existing:
        existing_html = (
            'RobloxCookies.dat files were found here, but none could be used:<br>'
            + '<br>'.join(html.escape(str(path)) for path in existing[:8])
            + '<br><br>'
        )

    skipped_token = bool(details.get('user_skipped_token'))
    if sys.platform == 'darwin':
        diagnostics_html = (
            'Diagnostics:<br>'
            f'macOS home: {html.escape(str(details.get("home") or "Unknown"))}<br>'
            f'Fleasion config root: {html.escape(str(details.get("local_appdata") or "Unknown"))}<br>'
            f'Default cookie path: {html.escape(str(details.get("default_cookie_path") or "Unknown"))}<br>'
            f'Candidate paths checked: {len(attempted)}<br><br>'
        )
        most_likely_html = (
            (
                'You chose to continue without a Roblox login token.<br><br>'
                if skipped_token
                else 'Fleasion checked RobloxCookies.dat plus the selected login source, but found zero usable Roblox login tokens.<br><br>'
            )
            + 'This token is required for authenticated asset downloads, account launches, '
            'private-server joins, and other account-aware features.<br><br>'
            'Sign in to roblox.com in Chrome, Firefox, Brave, Edge, Chromium, Opera, '
            'or Vivaldi, then choose that browser in Settings > Roblox Login. Safari is not supported for '
            'Fleasion login discovery on macOS.<br><br>'
            'You do not have to use that browser for anything else; it only needs to stay logged in to roblox.com.<br><br>'
            'You can also store a token manually from Settings > Roblox Login > Import Token, '
            'or retry from Dashboard > Miscellaneous > Account Manager > Import Browser Login.<br><br>'
        )
    elif sys.platform.startswith('linux'):
        diagnostics_html = (
            'Diagnostics:<br>'
            f'Linux home: {html.escape(str(details.get("home") or "Unknown"))}<br>'
            f'Fleasion config root: {html.escape(str(details.get("local_appdata") or "Unknown"))}<br>'
            f'Default Sober cookie path: {html.escape(str(details.get("default_cookie_path") or "Unknown"))}<br>'
            f'Candidate paths checked: {len(attempted)}<br><br>'
        )
        most_likely_html = (
            (
                'You chose to continue without a Roblox login token.<br><br>'
                if skipped_token
                else 'Fleasion checked Sober cookies plus supported browser login stores, but found zero usable Roblox login tokens.<br><br>'
            )
            + 'This token is required for authenticated asset downloads, account launches, '
            'private-server joins, and other account-aware features.<br><br>'
            'Sign in through Sober or log in to roblox.com in Firefox or a Chrome-family browser, '
            'then try again. You can retry from Dashboard > Miscellaneous > Account Manager > '
            'Import Browser Login.<br><br>'
        )
    else:
        diagnostics_html = (
            'Diagnostics:<br>'
            f'Windows username: {html.escape(str(details.get("username") or "Unknown"))}<br>'
            f'USERPROFILE: {html.escape(str(details.get("userprofile") or "Unknown"))}<br>'
            f'Fleasion LocalAppData: {html.escape(str(details.get("local_appdata") or "Unknown"))}<br>'
            f'Default cookie path: {html.escape(str(details.get("default_cookie_path") or "Unknown"))}<br>'
            f'Candidate paths checked: {len(attempted)}<br><br>'
        )
        most_likely_html = (
            'Most likely cause:<br>'
            'Fleasion is running under a different Windows user account than Roblox, '
            'or it inherited the wrong LocalAppData path during elevation/startup.<br><br>'
            'Quick fix:<br>'
            '1) Fully exit Fleasion from the system tray.<br>'
            '2) Start Fleasion from the same Windows account that runs Roblox.<br>'
            '3) If Windows shows a UAC prompt, do not approve it with a different admin account.<br>'
            '4) Launch Roblox once, then restart Fleasion.<br><br>'
        )

    msg = _ForcedAcknowledgeMessageBox(_parent)
    if _on_top:
        msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
    msg.setWindowTitle('Roblox Token Not Readable')
    msg.setIcon(QMessageBox.Icon.Warning)
    msg.setText(
        'Fleasion is continuing without a Roblox login token.'
        if skipped_token
        else 'Fleasion could not read a usable Roblox login token.'
    )
    msg.setTextFormat(Qt.TextFormat.RichText)
    msg.setInformativeText(
        (
            '<b>MOST FUNCTIONS OF FLEASION WILL NOT FUNCTION until a valid Roblox login token is available.</b><br><br>'
            'Authenticated Roblox asset downloads may fail until a token is imported.<br><br>'
            if skipped_token
            else '<b>MOST FUNCTIONS OF FLEASION WILL NOT FUNCTION until a valid Roblox login token is available.</b><br><br>'
            'Authenticated Roblox asset downloads may fail until this is fixed.<br><br>'
        )
        + most_likely_html
        + existing_html
        + diagnostics_html
        + f'Need help? <a href="{html.escape(discord_url)}">{html.escape(APP_DISCORD)}</a>'
    )
    if sys.platform == 'darwin' or sys.platform.startswith('linux'):
        import webbrowser

        open_login_button = msg.addButton('Open Roblox Login', QMessageBox.ButtonRole.ActionRole)
        exit_button = msg.addButton('Exit Fleasion', QMessageBox.ButtonRole.DestructiveRole)
        msg.addButton(QMessageBox.StandardButton.Ok)
    else:
        open_login_button = None
        exit_button = msg.addButton('Exit Fleasion', QMessageBox.ButtonRole.DestructiveRole)
        msg.addButton(QMessageBox.StandardButton.Ok)

    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        msg.setWindowIcon(QIcon(str(icon_path)))

    for label in msg.findChildren(QLabel):
        label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextBrowserInteraction
            | Qt.TextInteractionFlag.TextSelectableByMouse
        )
        label.setOpenExternalLinks(True)

    ack_buttons = list(msg.buttons())
    countdown_buttons = [button for button in ack_buttons if button is not exit_button]
    for button in countdown_buttons:
        button.setEnabled(False)
    ok_button = msg.button(QMessageBox.StandardButton.Ok)
    remaining_seconds = 5
    if ok_button is not None:
        ok_button.setText(f'OK ({remaining_seconds}s)')

    countdown_timer = QTimer(msg)
    countdown_timer.setInterval(1000)

    def _update_auth_warning_countdown():
        nonlocal remaining_seconds
        remaining_seconds -= 1
        if remaining_seconds <= 0:
            countdown_timer.stop()
            msg.allow_close()
            for button in countdown_buttons:
                button.setEnabled(True)
            if ok_button is not None:
                ok_button.setText('OK')
        elif ok_button is not None:
            ok_button.setText(f'OK ({remaining_seconds}s)')

    countdown_timer.timeout.connect(_update_auth_warning_countdown)
    countdown_timer.start()

    def _exit_from_warning() -> None:
        _quit_after_modal_closes(msg, tray)

    exit_button.clicked.connect(_exit_from_warning)

    msg.exec()
    if msg.clickedButton() == exit_button:
        return
    if open_login_button is not None and msg.clickedButton() == open_login_button:
        if sys.platform.startswith('linux'):
            launch_as_standard_user('https://www.roblox.com/login')
        else:
            webbrowser.open('https://www.roblox.com/login')


def _show_windows_upstream_firewall_dialog(details: dict) -> None:
    """Explain a blocked upstream connection and offer a targeted UAC repair."""
    if sys.platform != 'win32':
        return

    from .utils.windows_firewall import get_fleasion_firewall_rule_status

    host = str(details.get('host') or 'a Roblox content server')
    parent = _visible_parent_widget()
    try:
        firewall_status = get_fleasion_firewall_rule_status()
    except Exception as exc:
        log_buffer.log('WindowsFirewall', f'Could not inspect Fleasion firewall rules: {exc}')
        firewall_status = {'ok': False}

    rules_already_present = bool(firewall_status.get('ok'))
    msg = QMessageBox(parent)
    msg.setWindowTitle(
        'Fleasion - Connection Still Blocked'
        if rules_already_present
        else 'Fleasion - Connection Blocked'
    )
    msg.setIcon(QMessageBox.Icon.Warning)
    if rules_already_present:
        msg.setText(f'Fleasion still cannot connect securely to {host}.')
        msg.setInformativeText(
            "Fleasion's Windows Firewall rules are already installed for both Private and "
            'Public networks, so adding them again will not fix this connection.\n\n'
            'Another network control may be blocking Fleasion, such as antivirus, a VPN, '
            'DNS filtering, or an organization policy. Please contact the Fleasion Discord '
            'for help and include the Fleasion log if possible.'
        )
        repair_button = None
        help_button = msg.addButton('Get Help on Discord', QMessageBox.ButtonRole.ActionRole)
    else:
        msg.setText(f'Fleasion could not connect securely to {host}. Windows may be blocking it.')
        msg.setInformativeText(
            'Fleasion needs to reach Roblox over HTTPS, but the connection was refused or '
            'interrupted before the request completed. This can happen when Windows Firewall, '
            'antivirus, a VPN, or an organization policy blocks Fleasion.\n\n'
            'Allow Fleasion through Windows Firewall adds only Fleasion program rules for '
            'inbound and outbound traffic on Private and Public networks. It requires one '
            "standard administrator approval and does not change other applications' rules."
        )
        repair_button = msg.addButton(
            'Allow Fleasion Through Firewall', QMessageBox.ButtonRole.AcceptRole
        )
        help_button = None
    settings_button = msg.addButton('Open Firewall Settings', QMessageBox.ButtonRole.ActionRole)
    msg.addButton('Not Now', QMessageBox.ButtonRole.RejectRole)
    msg.setDefaultButton(help_button or settings_button)
    msg.exec()

    if help_button is not None and msg.clickedButton() == help_button:
        import webbrowser

        discord_url = APP_DISCORD
        if not discord_url.startswith(('http://', 'https://')):
            discord_url = f'https://{discord_url}'
        webbrowser.open(discord_url)
        return

    if msg.clickedButton() == repair_button:
        from .utils.windows_firewall import (
            clear_pending_repair,
            clear_repair_result,
            write_pending_repair,
        )

        try:
            clear_repair_result(CONFIG_DIR)
            write_pending_repair(CONFIG_DIR)
            relaunched = _relaunch_as_admin(
                extra_args='--repair-firewall',
                parent_hwnd=_window_handle(parent),
            )
        except Exception as exc:
            clear_pending_repair(CONFIG_DIR)
            log_buffer.log('WindowsFirewall', f'Could not start elevated firewall repair: {exc}')
            relaunched = False

        if relaunched:
            log_buffer.log('WindowsFirewall', 'Elevated Fleasion firewall repair started')
            deadline = time.monotonic() + _WINDOWS_FIREWALL_REPAIR_RESULT_TIMEOUT_SECONDS
            QTimer.singleShot(500, lambda: _poll_windows_firewall_repair(deadline))
        else:
            clear_pending_repair(CONFIG_DIR)
            QMessageBox.warning(
                parent,
                'Fleasion Firewall Repair Not Started',
                'Fleasion could not obtain administrator permission, so Windows Firewall '
                'was not changed. You can retry this action or open Firewall Settings manually.',
            )
        return

    if msg.clickedButton() == settings_button:
        try:
            subprocess.Popen(
                [
                    'control.exe',
                    '/name',
                    'Microsoft.WindowsFirewall',
                    '/page',
                    'pageConfigureApps',
                ]
            )
        except OSError as exc:
            QMessageBox.warning(
                msg.parentWidget(), 'Fleasion', f'Could not open Firewall settings: {exc}'
            )
        return


def _show_tls_self_test_failed_dialog(details: dict) -> None:
    """Show a user-facing error when the proxy cannot pass startup TLS checks."""
    hosts = details.get('hosts') or []
    host_text = ', '.join(str(host) for host in hosts) or 'the configured Roblox routes'
    QMessageBox.critical(
        _visible_parent_widget(),
        'Fleasion - Proxy Startup Failed',
        'Fleasion could not start its local proxy because its TLS self-test failed.\n\n'
        f'Routes tested: {host_text}\n\n'
        'Check the Fleasion log for the certificate or network error, then restart Fleasion.',
    )


class _ProxyErrorInvoker(QObject):
    """Main-thread bridge for proxy startup errors emitted from worker threads."""

    show_proxy_error = pyqtSignal(str, dict)
    disable_proxy_features = pyqtSignal(str)
    retry_proxy = pyqtSignal()

    @pyqtSlot(str, dict)
    def handle_proxy_error(self, code: str, details: dict):
        if code == 'port_bind_failed':
            _show_proxy_bind_error_dialog(details)
        elif code == 'hosts_write_exhausted':
            _show_hosts_write_exhausted_dialog(details)
        elif code == 'hosts_entries_would_exceed_limit':
            _show_hosts_capacity_dialog(details)
        elif code in ('hosts_file_too_large', 'hosts_file_repair_failed'):
            _show_oversized_hosts_file_dialog(details, on_repaired=self.retry_proxy.emit)
        elif code == 'linux_hosts_read_only':
            _show_linux_hosts_read_only_dialog(details)
        elif code == 'macos_ca_patch_failed':
            if _show_macos_ca_patch_failed_dialog(details) == 'install_helper':
                from .utils.macos_proxy_helper import install_helper

                ok, detail = install_helper()
                if ok:
                    log_buffer.log(
                        'ProxyHelper',
                        'macOS proxy helper installed for protected cacert.pem; retrying proxy startup',
                    )
                    self.retry_proxy.emit()
                else:
                    log_buffer.log('ProxyHelper', f'macOS proxy helper install failed: {detail}')
                    QMessageBox.warning(
                        _visible_parent_widget(),
                        'Fleasion - Proxy Helper Installation Failed',
                        f'Fleasion could not install or start the macOS proxy helper.\n\n{detail}',
                    )
        elif code == 'macos_ca_trust_failed':
            _show_macos_ca_trust_failed_dialog(details)
        elif code == 'roblox_ca_patch_failed':
            denied_dirs = _windows_ca_permission_denied_dirs(details)
            if denied_dirs:
                _show_roblox_permission_failure(
                    _visible_parent_widget(),
                    denied_dirs,
                    on_repaired=self.retry_proxy.emit,
                    failure_text=(
                        'Fleasion could not update cacert.pem for Env Proxy in these Roblox '
                        'Player installations'
                    ),
                )
            else:
                _show_roblox_ca_patch_failed_dialog(details)
        elif code == 'macos_relay_failed':
            action = _show_macos_relay_failed_dialog(details)
            if action == 'retry':
                self.retry_proxy.emit()
            elif action == 'reinstall':
                from .utils.macos_proxy_helper import install_helper

                ok, detail = install_helper()
                if ok:
                    log_buffer.log(
                        'ProxyHelper',
                        'macOS proxy helper reinstalled after relay failure; retrying proxy startup',
                    )
                    self.retry_proxy.emit()
                else:
                    log_buffer.log(
                        'ProxyHelper',
                        f'macOS proxy helper reinstall failed: {detail}',
                    )
                    QMessageBox.warning(
                        _visible_parent_widget(),
                        'Fleasion - Proxy Helper Reinstall Failed',
                        f'Fleasion could not reinstall or restart the macOS proxy helper.\n\n{detail}',
                    )
        elif code == 'upstream_connect_failed':
            _show_windows_upstream_firewall_dialog(details)
        elif code == 'tls_self_test_failed':
            _show_tls_self_test_failed_dialog(details)


def _manual_upstream_credentials_missing(config_manager) -> bool:
    mode = config_manager.upstream_transport_mode
    if mode == 'http_connect':
        return not bool(
            config_manager.upstream_http_connect_username.strip()
            or config_manager.upstream_http_connect_password
        )
    if mode == 'socks5':
        return not bool(
            config_manager.upstream_socks5_username.strip()
            or config_manager.upstream_socks5_password
        )
    return False


def _disable_proxy_features_after_start_failure(
    config_manager, tray: SystemTray | None, reason: str
):
    """Handle proxy startup failure without silently mutating the saved setting."""
    if not config_manager.proxy_features_enabled:
        return
    if sys.platform.startswith('linux'):
        log_buffer.log(
            'Proxy',
            f'Linux proxy helper start failed; leaving proxy features enabled: {reason}',
        )
        QMessageBox.warning(
            _visible_parent_widget(),
            'Fleasion - Linux Proxy Helper Unavailable',
            'Fleasion could not start the Linux proxy helper.\n\n'
            f'{reason}\n\n'
            'Proxy features remain enabled in Settings, so Fleasion will try again the next time you launch it.',
        )
        if tray is not None and hasattr(tray, 'update_status'):
            tray.update_status()
        return

    log_buffer.log('Proxy', f'Proxy features disabled after startup failure: {reason}')
    if tray is not None:
        tray.set_proxy_features_enabled(False)
    else:
        config_manager.proxy_features_enabled = False


class _AuthCheckInvoker(QObject):
    """Main-thread bridge for the potentially prompting browser auth check."""

    completed = pyqtSignal(bool, dict)


class _RobloxUrlEventFilter(QObject):
    """Receive Roblox URL open events delivered to the macOS app bundle."""

    roblox_uri_received = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._ready = False
        self._pending: list[str] = []

    @staticmethod
    def _event_target(event: QEvent) -> str | None:
        if event.type() != QEvent.Type.FileOpen:
            return None
        try:
            url = event.url()
            target = url.toString() if url.isValid() else ''
        except AttributeError:
            target = ''
        target = str(target).strip()
        if target.startswith(('roblox:', 'roblox-player:')):
            return target
        return None

    def eventFilter(self, _watched, event):
        target = self._event_target(event)
        if target is not None:
            if self._ready:
                self.roblox_uri_received.emit(target)
            else:
                self._pending.append(target)
        return False

    def start(self) -> None:
        self._ready = True
        pending = self._pending
        self._pending = []
        for target in pending:
            self.roblox_uri_received.emit(target)


class RobloxExitMonitor(QObject):
    """Monitors Roblox process and triggers cache deletion on exit."""

    _studio_detected = pyqtSignal()
    player_status_changed = pyqtSignal(
        bool
    )  # Emitted when RobloxPlayerBeta opens/closes (True = running)

    def __init__(
        self,
        config_manager,
        proxy_master=None,
        mod_manager=None,
        env_lifecycle=None,
    ):
        super().__init__()
        self.config_manager = config_manager
        self._proxy_master = proxy_master
        self._mod_manager = mod_manager
        self.env_lifecycle = env_lifecycle
        self._status_lock = threading.Lock()
        adopted_running = bool(env_lifecycle and env_lifecycle.owns_player)
        self.was_running = adopted_running
        self._player_was_running = adopted_running
        self._suppress_next_player_exit_cache_delete = False
        self._studio_was_running = False
        self._studio_notified = False
        self._studio_suppress_session = False
        self._macos_uri_interceptor = None
        self._macos_plain_launch_lock = threading.Lock()
        self._macos_plain_launches: dict[int, Path] = {}
        if (
            sys.platform == 'darwin'
            and env_lifecycle is not None
            and proxy_master is not None
            and config_manager.proxy_mode == 'env'
            and config_manager.proxy_features_enabled
            and callable(getattr(proxy_master, 'wait_for_env_proxy_ready', None))
        ):
            try:
                from .utils.platform_macos import MacOSRobloxUriInterceptor

                self._macos_uri_interceptor = MacOSRobloxUriInterceptor(
                    is_armed=self._macos_uri_interception_armed,
                    on_intercepted=self._handle_macos_uri_interception,
                )
                self._macos_uri_interceptor.start()
            except Exception as exc:
                log_buffer.log(
                    'Launcher',
                    f'Could not start macOS Roblox URI watcher: {type(exc).__name__}: {exc}',
                )
        self._studio_detected.connect(self._on_studio_detected)

    def is_player_running(self) -> bool:
        """Return whether Roblox Player is currently running."""
        return is_roblox_running()

    def stop(self) -> None:
        """Release the macOS URI watcher during normal application shutdown."""
        with self._macos_plain_launch_lock:
            self._macos_plain_launches.clear()
        interceptor = self._macos_uri_interceptor
        if interceptor is not None:
            interceptor.stop()

    def _macos_uri_interception_armed(self) -> bool:
        """Return whether it is safe to stop and replay a browser URI launch."""
        if (
            sys.platform != 'darwin'
            or self._proxy_master is None
            or self.env_lifecycle is None
            or self.config_manager.proxy_mode != 'env'
            or not self.config_manager.proxy_features_enabled
            or self.env_lifecycle.owns_player
            or self.env_lifecycle.operation_in_progress
        ):
            return False
        ready = getattr(self._proxy_master, 'wait_for_env_proxy_ready', None)
        try:
            return bool(callable(ready) and ready(timeout=0.0))
        except Exception:
            return False

    def _handle_macos_uri_interception(self, launch, target: str) -> None:
        """Run after the watcher has already SIGKILLed the original Player."""
        if self.env_lifecycle is None:
            return
        self._suppress_next_player_exit_cache_delete = True
        with self._macos_plain_launch_lock:
            self._macos_plain_launches.pop(int(launch.pid), None)
        self.env_lifecycle.handle_intercepted_player_launch(Path(launch.executable_path), target)

    def _schedule_macos_plain_launch_fallback(self, exe_path: Path) -> None:
        """Keep ordinary Dock/Finder launches on the existing Env Proxy path."""
        if self._macos_uri_interceptor is None:
            return
        identity = get_roblox_process_identity()
        if not isinstance(identity, tuple) or not identity:
            return
        try:
            pid = int(identity[0])
        except TypeError, ValueError:
            return
        with self._macos_plain_launch_lock:
            if pid in self._macos_plain_launches:
                return
            self._macos_plain_launches[pid] = Path(exe_path)

        def _fallback() -> None:
            time.sleep(_MACOS_PLAIN_LAUNCH_CLASSIFICATION_SECONDS)
            with self._macos_plain_launch_lock:
                pending_exe = self._macos_plain_launches.pop(pid, None)
            if pending_exe is None or self.env_lifecycle is None:
                return
            if (
                self._macos_uri_interceptor is not None
                and self._macos_uri_interceptor.has_claimed_pid(pid)
            ):
                return
            current_identity = get_roblox_process_identity()
            if not isinstance(current_identity, tuple) or not current_identity:
                return
            try:
                if int(current_identity[0]) != pid:
                    return
            except TypeError, ValueError:
                return
            if not self._macos_uri_interception_armed():
                return
            self._suppress_next_player_exit_cache_delete = True
            self.env_lifecycle.handle_player_launch(pending_exe)

        threading.Thread(
            target=_fallback,
            name='FleasionMacOSPlainLaunchFallback',
            daemon=True,
        ).start()

    @run_in_thread
    def check_roblox_status(self):
        """Coalesce timer ticks so process edges are handled exactly once."""
        if not self._status_lock.acquire(blocking=False):
            return
        try:
            self._check_roblox_status_locked()
        finally:
            self._status_lock.release()

    def _check_roblox_status_locked(self):
        """Check if Roblox has exited and trigger cache deletion if needed."""
        is_running = is_roblox_running()
        player_status_observed_at = time.monotonic()
        intentional_player_exit = False

        # --- Roblox Player: player status changed signal ---
        if self._player_was_running != is_running:
            self.player_status_changed.emit(is_running)
            if self._proxy_master is not None:
                self._proxy_master.set_roblox_player_running(is_running)
            if self._player_was_running and not is_running and self.env_lifecycle is not None:
                intentional_player_exit = self.env_lifecycle.consume_intentional_player_exit(
                    player_status_observed_at
                )
                if not intentional_player_exit:
                    self.env_lifecycle.note_unexpected_player_exit()

        # --- Roblox Player: launch detection - check CA cert on new launch ---
        if not self._player_was_running and is_running:
            if sys.platform.startswith('linux'):
                exe_path = Path('org.vinegarhq.Sober')
                if self._mod_manager is not None:
                    self._mod_manager.refresh_roblox_dirs(reapply_if_changed=True)
                proxy_features_enabled = self.config_manager.proxy_features_enabled
                if (
                    self.config_manager.proxy_mode == 'env'
                    and self._proxy_master is not None
                    and proxy_features_enabled
                ):
                    if self.env_lifecycle is not None:
                        run_in_thread(self.env_lifecycle.handle_adopted_player_launch)(exe_path)
                elif self._proxy_master is not None and proxy_features_enabled:
                    run_in_thread(self._proxy_master.refresh_and_restart_roblox)(exe_path)
                elif self._proxy_master is None and proxy_features_enabled:
                    run_in_thread(check_and_patch_running_roblox_ca)(exe_path)
                elif not proxy_features_enabled:
                    log_buffer.log(
                        'Certificate',
                        'Sober launch detected: proxy features disabled, skipping proxy CA refresh',
                    )
            else:
                exe_path = get_roblox_player_exe_path()
                if exe_path is None:
                    # Process may still be initializing — retry for up to 10 s
                    for _ in range(10):
                        time.sleep(1.0)
                        exe_path = get_roblox_player_exe_path()
                        if exe_path is not None:
                            break
                if exe_path is not None:
                    proxy_features_enabled = self.config_manager.proxy_features_enabled
                    if self._mod_manager is not None:
                        self._mod_manager.refresh_roblox_dirs(reapply_if_changed=True)
                    if (
                        sys.platform == 'win32'
                        and self.config_manager.proxy_mode == 'env'
                        and self._proxy_master is not None
                        and proxy_features_enabled
                    ):
                        from .utils.platform_windows import (
                            is_roblox_gdk_env_proxy_armed,
                            is_gdk_env_proxy_activation_in_progress,
                            is_env_proxy_relaunched_player_running,
                            is_roblox_gdk_exe_path,
                        )

                        if is_roblox_gdk_exe_path(exe_path):
                            gdk_env_proxy_armed = (
                                is_roblox_gdk_env_proxy_armed()
                                or is_gdk_env_proxy_activation_in_progress()
                            )
                            if gdk_env_proxy_armed and self.env_lifecycle is not None:
                                log_buffer.log(
                                    'Launcher',
                                    'Xbox/GDK Env Proxy package activation supplied the '
                                    'initial Player; handing it to Env Proxy lifecycle monitoring',
                                )
                                self._suppress_next_player_exit_cache_delete = True
                                run_in_thread(self.env_lifecycle.handle_adopted_player_launch)(
                                    exe_path
                                )
                            else:
                                log_buffer.log(
                                    'Launcher',
                                    'Xbox/GDK Env Proxy package activation is unavailable; '
                                    'leaving the initial package Player untouched',
                                )
                                self._suppress_next_player_exit_cache_delete = False
                        elif is_env_proxy_relaunched_player_running():
                            log_buffer.log(
                                'Launcher',
                                'Roblox Env Proxy Player already running; skipping duplicate launch handling',
                            )
                            self._suppress_next_player_exit_cache_delete = False
                        else:
                            self._suppress_next_player_exit_cache_delete = True

                            def _handle_env_proxy_player_launch() -> None:
                                lifecycle = self.env_lifecycle
                                started = bool(
                                    lifecycle is not None
                                    and lifecycle.handle_player_launch(exe_path)
                                )
                                if not started:
                                    self._suppress_next_player_exit_cache_delete = False

                            run_in_thread(_handle_env_proxy_player_launch)()
                    elif (
                        self.config_manager.proxy_mode == 'env'
                        and self._proxy_master is not None
                        and proxy_features_enabled
                    ):
                        if self.env_lifecycle is not None:
                            if sys.platform == 'darwin':
                                self._schedule_macos_plain_launch_fallback(exe_path)
                            else:
                                run_in_thread(self.env_lifecycle.handle_player_launch)(exe_path)
                    elif self._proxy_master is not None and proxy_features_enabled:
                        run_in_thread(self._proxy_master.refresh_and_restart_roblox)(exe_path)
                    elif self._proxy_master is None and proxy_features_enabled:
                        run_in_thread(check_and_patch_running_roblox_ca)(exe_path)
                    elif not proxy_features_enabled:
                        log_buffer.log(
                            'Certificate',
                            'Roblox launch detected: proxy features disabled, skipping proxy CA refresh',
                        )
                else:
                    log_buffer.log(
                        'Certificate',
                        'Roblox launch detected but could not resolve exe path for CA check',
                    )
        self._player_was_running = is_running

        # --- Roblox Player: auto cache deletion on exit ---
        if self.config_manager.auto_delete_cache_on_exit:
            if self.was_running and not is_running:
                if intentional_player_exit or self._suppress_next_player_exit_cache_delete:
                    self._suppress_next_player_exit_cache_delete = False
                    log_buffer.log(
                        'Cache',
                        'Roblox exited during env-proxy relaunch; skipping auto cache deletion',
                    )
                else:
                    log_buffer.log('Cache', 'Roblox exited, deleting cache...')
                    run_in_thread(self._delete_cache_background)()
            self.was_running = is_running
        else:
            self.was_running = False

        # --- Roblox Studio: Env Proxy deliberately leaves Studio untouched ---
        studio_running = is_studio_running()

        if not self._studio_was_running and studio_running:
            env_proxy_mode = self.config_manager.proxy_mode == 'env'
            if env_proxy_mode:
                log_buffer.log(
                    'Launcher',
                    'Studio launch detected in Env Proxy mode; leaving Studio untouched',
                )
                studio_exe_path = None
            else:
                studio_exe_path = get_roblox_studio_exe_path()
                if studio_exe_path is None:
                    for _ in range(10):
                        time.sleep(1.0)
                        studio_exe_path = get_roblox_studio_exe_path()
                        if studio_exe_path is not None:
                            break

            if (
                not env_proxy_mode
                and studio_exe_path is not None
                and self.config_manager.proxy_features_enabled
            ):
                if sys.platform == 'darwin':
                    log_buffer.log(
                        'Certificate',
                        'Studio launch detected on macOS: skipping proxy CA refresh',
                    )
                else:
                    run_in_thread(check_and_patch_running_roblox_ca)(studio_exe_path)
            elif not env_proxy_mode and studio_exe_path is not None:
                log_buffer.log(
                    'Certificate',
                    'Studio launch detected: proxy features disabled, skipping proxy CA refresh',
                )
            elif not env_proxy_mode:
                log_buffer.log(
                    'Certificate',
                    'Studio launch detected but could not resolve exe path for CA check',
                )

            if (
                not env_proxy_mode
                and not self._studio_suppress_session
                and not self._studio_notified
            ):
                self._studio_notified = True
                self._studio_detected.emit()

        if self._studio_was_running and not studio_running:
            self._studio_notified = False

        self._studio_was_running = studio_running

    def _on_studio_detected(self):
        """Show the Roblox Studio warning dialog (called on the main thread via signal)."""
        _top = QApplication.topLevelWidgets()
        _parent = next((w for w in _top if w.isVisible()), None)
        _on_top = any(
            w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
            for w in _top
        )
        dialog = QDialog(_parent)
        if _on_top:
            dialog.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        dialog.setWindowTitle('Roblox Studio Detected')

        layout = QVBoxLayout(dialog)
        layout.setSpacing(12)

        label = QLabel(
            'Roblox Studio is currently open.\n\n'
            'Asset modification and scraping may not work correctly while '
            'Roblox Studio is running.'
        )
        label.setWordWrap(True)
        layout.addWidget(label)

        btn_layout = QHBoxLayout()
        suppress_btn = QPushButton("Don't Show for Session")
        ok_btn = QPushButton('OK')
        ok_btn.setDefault(True)
        ok_btn.setFixedWidth(80)

        btn_layout.addWidget(suppress_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(ok_btn)
        layout.addLayout(btn_layout)

        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            dialog.setWindowIcon(QIcon(str(icon_path)))

        ok_btn.clicked.connect(dialog.accept)

        def _suppress():
            self._studio_suppress_session = True
            dialog.accept()

        suppress_btn.clicked.connect(_suppress)
        dialog.exec()

    def _delete_cache_background(self):
        """Delete cache in background thread."""
        messages = delete_cache()
        for msg in messages:
            log_buffer.log('Cache', msg)


def _looks_like_fleasion_gui_command(command: str) -> bool:
    """Return whether a process command is a Fleasion GUI app/dev launch."""
    try:
        tokens = shlex.split(command)
    except ValueError:
        tokens = command.split()
    if not tokens:
        return False

    if '--linux-proxy-helper' in tokens:
        return False
    if any(Path(token).name == 'linux_proxy_helper_daemon.py' for token in tokens):
        return False

    executable = Path(tokens[0]).name.lower()
    if executable == 'fleasion' or executable.startswith('fleasion-v'):
        return True

    # ``uv run fleasion`` and virtual-environment entry points are executed as
    # ``python …/bin/fleasion``.  The old check only considered argv[0], so
    # Linux's Kill Others action missed the already-running GUI and a second
    # instance later failed on the proxy backend port.
    if any(Path(token).name.lower() == 'fleasion' for token in tokens[1:]):
        return True

    for index, token in enumerate(tokens):
        if Path(token).name == 'launcher.py':
            return True
        if token == '-m' and index + 1 < len(tokens) and tokens[index + 1].lower() == 'fleasion':
            return True
    return False


def _looks_like_macos_fleasion_command(command: str) -> bool:
    """Compatibility wrapper for tests and older imports."""
    return _looks_like_fleasion_gui_command(command)


def _other_fleasion_pids() -> list:
    """Return PIDs of other Fleasion GUI processes (excludes current process and its parent)."""
    import os
    import subprocess

    current_pid = os.getpid()
    parent_pid = os.getppid()
    safe_pids = {current_pid, parent_pid}
    exe_name = os.path.basename(sys.executable)
    pids = []

    if sys.platform != 'win32':
        try:
            result = subprocess.run(
                ['ps', '-axo', 'pid=,ppid=,command='],
                capture_output=True,
                text=True,
                timeout=10,
            )
            for raw in result.stdout.splitlines():
                try:
                    pid_text, _ppid_text, command = raw.strip().split(None, 2)
                    pid = int(pid_text)
                except ValueError, TypeError:
                    continue
                if pid not in safe_pids and _looks_like_fleasion_gui_command(command):
                    pids.append(pid)
        except Exception:
            pass
        return pids

    try:
        if exe_name.lower() not in ('python.exe', 'python3.exe'):
            result = subprocess.run(
                ['tasklist', '/FI', f'IMAGENAME eq {exe_name}', '/FO', 'CSV', '/NH'],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                creationflags=subprocess.CREATE_NO_WINDOW,
                timeout=10,
            )
            for line in result.stdout.strip().splitlines():
                line = line.strip().strip('"')
                parts = line.split('","')
                if len(parts) >= 2:
                    try:
                        pid = int(parts[1])
                        if pid not in safe_pids:
                            pids.append(pid)
                    except ValueError, IndexError:
                        pass
        else:
            ps_cmd = (
                'Get-CimInstance Win32_Process -Filter "Name=\'python.exe\'" | '
                'Select-Object ProcessId, CommandLine | ConvertTo-Json -Depth 1'
            )
            result = subprocess.run(
                ['powershell', '-NoProfile', '-Command', ps_cmd],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                creationflags=subprocess.CREATE_NO_WINDOW,
                timeout=30,
            )
            try:
                data = json.loads(result.stdout)
                if isinstance(data, dict):
                    data = [data]
                for proc in data:
                    pid = int(proc.get('ProcessId', 0))
                    cmdline = (proc.get('CommandLine') or '').lower()
                    if pid in safe_pids or pid == 0:
                        continue
                    if 'launcher.py' in cmdline or 'fleasion' in cmdline:
                        pids.append(pid)
            except json.JSONDecodeError, TypeError, ValueError:
                pass
    except Exception:
        pass

    return pids


def _should_reclaim_stale_single_instance(error) -> bool:
    """Return True when a stale Qt singleton marker can be safely reclaimed."""
    if error != QSharedMemory.SharedMemoryError.AlreadyExists:
        return False
    if not (sys.platform == 'darwin' or sys.platform.startswith('linux')):
        return False
    return not _other_fleasion_pids()


def _request_running_instance_exit(
    timeout_ms: int = 2000,
    *,
    preserve_env_proxy_player: bool = False,
) -> bool:
    """Ask the already-running Fleasion instance to exit through its Qt event loop."""
    try:
        socket = QLocalSocket()
        socket.connectToServer(_SINGLE_INSTANCE_CONTROL_SERVER)
        if not socket.waitForConnected(timeout_ms):
            return False

        command = 'quit-preserve-env-player' if preserve_env_proxy_player else 'quit'
        socket.write(f'{command}\n'.encode('utf-8'))
        socket.waitForBytesWritten(1000)
        socket.disconnectFromServer()
        socket.waitForDisconnected(1000)
        return True
    except Exception:
        return False


def _roblox_uri_from_argv() -> str | None:
    """Return a Roblox deeplink passed by a desktop URI handler, if any."""
    for argument in sys.argv[1:]:
        target = str(argument).strip()
        if target.startswith(('roblox:', 'roblox-player:')):
            return target
    return None


def _request_running_instance_launch(target: str, timeout_ms: int = 5000) -> bool:
    """Forward a Roblox deeplink to the already-running Fleasion instance."""
    try:
        socket = QLocalSocket()
        socket.connectToServer(_SINGLE_INSTANCE_CONTROL_SERVER)
        if not socket.waitForConnected(timeout_ms):
            return False

        socket.write(f'launch-roblox\n{target}\n'.encode('utf-8'))
        socket.waitForBytesWritten(1000)
        socket.disconnectFromServer()
        socket.waitForDisconnected(1000)
        return True
    except Exception:
        return False


def _launch_roblox_uri_for_instance(tray: SystemTray, target: str) -> bool:
    """Launch a URI through the active proxy mode."""
    if sys.platform.startswith('linux'):
        # Flatpak supplies Fleasion's Env Proxy variables to Sober while the
        # proxy is active; do not replace a one-time URI with a synthetic launch.
        return launch_as_standard_user(target)

    config = tray.config_manager
    proxy_master = tray.proxy_master
    if (
        (sys.platform.startswith('linux') or sys.platform == 'darwin')
        and getattr(config, 'proxy_mode', 'hosts') == 'env'
        and getattr(config, 'proxy_features_enabled', False)
        and proxy_master is not None
    ):
        lifecycle = getattr(getattr(tray, 'roblox_monitor', None), 'env_lifecycle', None)
        if lifecycle is not None:
            exe_path = (
                Path('org.vinegarhq.Sober')
                if sys.platform.startswith('linux')
                else get_roblox_player_exe_path()
            )
            return lifecycle.handle_player_launch(exe_path, target)

    return launch_as_standard_user(target)


def _arm_windows_gdk_env_proxy_when_ready(proxy_master, timeout: float = 15.0) -> bool:
    """Arm Store/GDK activation with the proxy's finalized loopback port."""
    if not proxy_master.wait_for_env_proxy_ready(timeout=timeout):
        log_buffer.log(
            'Launcher',
            'Xbox/GDK Env Proxy activation was not armed because the proxy did not become ready',
        )
        return False

    from .utils.platform_windows import (
        arm_roblox_gdk_env_proxy,
        disarm_roblox_gdk_env_proxy,
    )

    if not arm_roblox_gdk_env_proxy(proxy_master.roblox_env_proxy_url()):
        return False
    atexit.register(disarm_roblox_gdk_env_proxy)
    return True


def _wait_for_other_fleasion_instances_to_exit(timeout_seconds: float = 8.0) -> bool:
    """Wait until no other Fleasion processes remain."""
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if not _other_fleasion_pids():
            return True
        time.sleep(0.1)
    return not _other_fleasion_pids()


def _request_other_fleasion_instances_exit(
    timeout_seconds: float = 8.0,
    *,
    preserve_env_proxy_player: bool = False,
) -> bool:
    """Return True if other instances were asked to exit and disappeared."""
    if not _other_fleasion_pids():
        return True
    if not _request_running_instance_exit(preserve_env_proxy_player=preserve_env_proxy_player):
        return False
    return _wait_for_other_fleasion_instances_to_exit(timeout_seconds)


def _handle_single_instance_command(socket: QLocalSocket, tray: SystemTray):
    try:
        command = bytes(socket.readAll()).decode('utf-8', errors='replace').strip()
        if command.lower() == 'quit':
            tray._exit_app()
        elif command.lower() == 'quit-preserve-env-player':
            tray._exit_app(preserve_roblox=True)
        elif command.lower().startswith('launch-roblox\n'):
            target = command.split('\n', 1)[1].strip()
            if target.startswith(('roblox:', 'roblox-player:')):
                run_in_thread(_launch_roblox_uri_for_instance)(tray, target)
    except Exception:
        pass


def _start_single_instance_control_server(
    app: QApplication, tray: SystemTray
) -> QLocalServer | None:
    """Start a local control endpoint for clean single-instance handoff."""
    server = QLocalServer(app)

    if not server.listen(_SINGLE_INSTANCE_CONTROL_SERVER):
        QLocalServer.removeServer(_SINGLE_INSTANCE_CONTROL_SERVER)
        if not server.listen(_SINGLE_INSTANCE_CONTROL_SERVER):
            log_buffer.log('App', 'Single-instance control server could not start')
            return None

    def _handle_connection():
        while server.hasPendingConnections():
            socket = server.nextPendingConnection()
            if socket is not None:
                socket.readyRead.connect(lambda s=socket: _handle_single_instance_command(s, tray))
                if socket.bytesAvailable() > 0:
                    _handle_single_instance_command(socket, tray)

    server.newConnection.connect(_handle_connection)
    return server


def kill_other_fleasion_instances():
    """Kill all other Fleasion instances except the current process."""
    import os
    import subprocess

    if _request_other_fleasion_instances_exit():
        return

    for pid in _other_fleasion_pids():
        try:
            if sys.platform != 'win32':
                os.kill(pid, signal.SIGTERM)
            else:
                subprocess.run(
                    ['taskkill', '/PID', str(pid)],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    timeout=5,
                )
                if _wait_for_other_fleasion_instances_to_exit(2.0):
                    continue
                subprocess.run(
                    ['taskkill', '/F', '/PID', str(pid)],
                    capture_output=True,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    timeout=5,
                )
        except Exception:
            pass


def _configure_opengl_for_legacy_viewers() -> None:
    """Configure Qt before any OpenGL preview widgets create contexts."""
    if sys.platform.startswith('linux'):
        os.environ.setdefault('QT_OPENGL', 'desktop')
    try:
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    except Exception as exc:
        log_buffer.log('OpenGL', f'Could not enable shared OpenGL contexts: {exc}')
    try:
        from .cache.gl_format import configure_default_legacy_gl_format

        configure_default_legacy_gl_format()
    except Exception as exc:
        log_buffer.log('OpenGL', f'Could not configure default OpenGL format: {exc}')


def _check_linux_gui_dependencies() -> bool:
    """Report native Linux GUI dependencies that Python packaging cannot supply."""
    if not sys.platform.startswith('linux'):
        return True

    from .utils.platform_linux import missing_linux_gui_packages

    missing = missing_linux_gui_packages()
    if not missing:
        return True

    package_list = ' '.join(missing)
    install_command = f'sudo pacman -S --needed {package_list}'
    log_buffer.log(
        'Linux GUI',
        'A required Arch Linux GUI package is missing.\n'
        f'  Package: {package_list}\n'
        f'  Impact: Fleasion cannot reliably publish its system tray icon.\n'
        f'  Install: {install_command}',
    )
    QMessageBox.critical(
        None,
        f'{APP_NAME} - System Package Required',
        'Fleasion needs a system package before its tray icon can work reliably.\n\n'
        f'Required package:\n  • {package_list}\n\n'
        f'Install it with:\n  {install_command}\n\n'
        'Restart Fleasion after installation. Without this package, PyQt6 may create a '
        'tray object but your desktop may never show its icon.',
        QMessageBox.StandardButton.Ok,
    )
    return False


def main():
    """Main application entry point."""
    import argparse as _ap

    _parser = _ap.ArgumentParser(add_help=False)
    _parser.add_argument(
        '--no-dashboard',
        action='store_true',
        help='Suppress dashboard on launch (used by autostart task)',
    )
    _parser.add_argument(
        '--kill-others',
        action='store_true',
        help='Kill other Fleasion instances on startup (used when relaunching elevated)',
    )
    _parser.add_argument(
        '--preserve-env-proxy-player',
        action='store_true',
        help=_ap.SUPPRESS,
    )
    _parser.add_argument('--proxy-debug', '-proxy-debug', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument(
        '--proxy-debug-mode',
        choices=['a', 'b', 'c', 'd', 'e', 'full'],
        help=_ap.SUPPRESS,
    )
    _parser.add_argument('--fleasion-user-localappdata', help=_ap.SUPPRESS)
    _parser.add_argument('--fleasion-requesting-user-sid', help=_ap.SUPPRESS)
    _parser.add_argument('--repair-autostart', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--disable-autostart', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--repair-roblox-permissions', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--repair-firewall', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--cleanup-hosts', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--fleasion-gdk-debugger', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument('--microprofile', action='store_true', help=_ap.SUPPRESS)
    _parser.add_argument(
        '--install-linux-privileged-helper',
        action='store_true',
        help='Install the root-owned Linux proxy helper and Polkit policy, then exit',
    )
    _parser.add_argument(
        '--linux-helper-promptless',
        action='store_true',
        help='Allow active sudo/wheel users to run the Linux proxy helper without future prompts',
    )
    _args, _ = _parser.parse_known_args()
    if _args.fleasion_gdk_debugger:
        from .utils.platform_windows import run_gdk_debugger_command_line

        sys.exit(run_gdk_debugger_command_line())
    if _args.cleanup_hosts:
        sys.exit(_cleanup_hosts_once())
    if _args.repair_autostart:
        sys.exit(
            _repair_autostart_once(
                _args.fleasion_requesting_user_sid,
                enabled=not _args.disable_autostart,
            )
        )
    if _args.repair_roblox_permissions:
        sys.exit(_repair_roblox_permissions_once(_args.fleasion_requesting_user_sid))
    if _args.repair_firewall:
        sys.exit(_repair_windows_firewall_once())
    pending_roblox_uri = _roblox_uri_from_argv()
    if _args.install_linux_privileged_helper:
        if not sys.platform.startswith('linux'):
            print(
                'Linux privileged helper installation is only supported on Linux.',
                file=sys.stderr,
            )
            sys.exit(1)
        from .utils.linux_proxy_helper import install_privileged_helper

        result = install_privileged_helper(enable_promptless=_args.linux_helper_promptless)
        if not result.get('ok'):
            print(
                f'Failed to install Linux privileged helper: {result.get("error") or result}',
                file=sys.stderr,
            )
            sys.exit(1)
        print(f'Installed Linux privileged helper: {result["helper"]}')
        print(f'Installed Polkit policy: {result["policy"]}')
        if result.get('promptless_rule'):
            print(f'Installed promptless Polkit rule: {result["promptless_rule"]}')
        sys.exit(0)

    _suppress_dashboard = _args.no_dashboard
    log_buffer.log('App', f'Version {__version__}')

    current_platform = platform.system()
    if current_platform not in {'Windows', 'Darwin', 'Linux'}:
        app = QApplication(sys.argv)
        QMessageBox.critical(
            None,
            'Unsupported Operating System',
            'Fleasion supports Windows, macOS, and Linux/Sober.\n\nThis application will now exit.',
            QMessageBox.StandardButton.Ok,
        )
        sys.exit(1)

    # The profiler is opt-in so normal releases do not collect diagnostics.
    _microprofiler = start_microprofiler(enabled=_args.microprofile)
    if _microprofiler is not None:
        log_buffer.log('MicroProfiler', f'Writing diagnostics to {_microprofiler.output_path}')

    _configure_opengl_for_legacy_viewers()

    # Create Qt application
    app = QApplication(sys.argv)
    roblox_url_event_filter = _RobloxUrlEventFilter(app)
    app.installEventFilter(roblox_url_event_filter)
    # Qt normally follows each desktop's dialog conventions (GNOME/KDE/Windows),
    # which changes the visual order of standard buttons. Fleasion uses the
    # Windows order everywhere so confirmations have a stable layout.
    app.setStyleSheet('QDialogButtonBox, QMessageBox { button-layout: 0; }')
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    if icon_path := get_icon_path():
        from PyQt6.QtGui import QIcon

        app.setWindowIcon(QIcon(str(icon_path)))
        if sys.platform == 'darwin':
            from .utils.platform_macos import set_application_icon

            set_application_icon(icon_path)

    if not _check_linux_gui_dependencies():
        sys.exit(1)

    if sys.platform == 'darwin' and _is_admin():
        QMessageBox.critical(
            None,
            'Do Not Run with sudo',
            'Run Fleasion as your normal macOS user.\n\n'
            'Fleasion installs a small privileged proxy helper when needed; the dashboard and menu-bar app must not run as root.',
        )
        sys.exit(1)

    # Gracefully release the existing instance before claiming shared memory.
    # The preserve command reaches the old lifecycle controller before its
    # proxy stops, so an Env Player can be adopted by this replacement.
    if _args.kill_others and _other_fleasion_pids():
        _request_other_fleasion_instances_exit(
            preserve_env_proxy_player=_args.preserve_env_proxy_player
        )

    # Single instance check.
    # When we've just been relaunched via UAC elevation, the non-elevated
    # instance may not have fully exited yet, leaving stale shared memory.
    # If we're admin, forcibly attach-and-detach to clear it so the
    # elevated instance can take over cleanly.
    if _is_admin():
        # If launched with --kill-others, kill before clearing stale memory so
        # the shared memory slot is freed by the time we try to claim it.
        if _args.kill_others:
            kill_other_fleasion_instances()
            import time as _time

            _time.sleep(0.3)
        _stale = QSharedMemory(_SINGLE_INSTANCE_KEY)
        if _stale.attach():
            _stale.detach()

    shared_memory = QSharedMemory(_SINGLE_INSTANCE_KEY)
    _shared_memory_created = shared_memory.create(1)
    if not _shared_memory_created and _should_reclaim_stale_single_instance(shared_memory.error()):
        # A hard termination can leave Qt's native shared-memory segment behind
        # on Unix-like platforms. Attach/detach removes it when no real
        # Fleasion GUI process still owns it; Linux proxy helpers are ignored by
        # _other_fleasion_pids() because they are not app instances.
        _stale = QSharedMemory(_SINGLE_INSTANCE_KEY)
        if _stale.attach():
            _stale.detach()
        shared_memory = QSharedMemory(_SINGLE_INSTANCE_KEY)
        _shared_memory_created = shared_memory.create(1)

    if not _shared_memory_created:
        if shared_memory.error() == QSharedMemory.SharedMemoryError.AlreadyExists:
            # Another instance is already running.
            if pending_roblox_uri and _request_running_instance_launch(pending_roblox_uri):
                sys.exit(0)
            if _suppress_dashboard:
                sys.exit(0)
            # Non-admin processes cannot use taskkill on elevated processes — it
            # silently does nothing.  Branch on whether WE are admin rather than
            # trying to inspect the other process's token cross-privilege.
            msg_box = QMessageBox()
            msg_box.setWindowTitle('Already Running')
            msg_box.setText(
                'Another instance of Fleasion is already running (Check your system tray).'
            )
            msg_box.setIcon(QMessageBox.Icon.Warning)

            # Set icon if available
            if icon_path := get_icon_path():
                from PyQt6.QtGui import QIcon

                msg_box.setWindowIcon(QIcon(str(icon_path)))

            msg_box.setInformativeText('Do you want to run another instance anyway?')

            if _is_admin() or sys.platform == 'darwin' or sys.platform.startswith('linux'):
                # Already elevated — can kill any process directly.
                kill_others_button = msg_box.addButton(
                    'Kill Others', QMessageBox.ButtonRole.AcceptRole
                )
                _kill_requires_elevation = False
            else:
                # Not admin — taskkill on an elevated process silently fails.
                # A single "Elevate & Kill Others" relaunches as admin with
                # --kill-others so the elevated copy handles it automatically.
                kill_others_button = msg_box.addButton(
                    'Elevate && Kill Others (Recommended)',
                    QMessageBox.ButtonRole.AcceptRole,
                )
                _kill_requires_elevation = True

            run_anyway_button = msg_box.addButton(
                'Run Anyway (Bad)', QMessageBox.ButtonRole.AcceptRole
            )
            cancel_button = msg_box.addButton('Cancel', QMessageBox.ButtonRole.RejectRole)
            msg_box.setDefaultButton(cancel_button)

            msg_box.exec()

            if msg_box.clickedButton() == cancel_button:
                sys.exit(0)

            if msg_box.clickedButton() == kill_others_button:
                if _kill_requires_elevation:
                    # Relaunch elevated with --kill-others.  The elevated copy will
                    # kill the running instance before claiming the shared memory
                    # slot — no second dialog shown.
                    launched = _relaunch_as_admin(extra_args='--kill-others')
                    if launched:
                        sys.exit(0)
                    # UAC denied — the existing admin instance is still running.
                    # There is no point continuing as a read-only copy alongside it,
                    # so exit cleanly.
                    sys.exit(0)
                else:
                    kill_other_fleasion_instances()

            # If "Run Anyway" or "Kill Others" (admin path) is clicked, we proceed.
            # Note: shared_memory object will be garbage collected or go out of scope,
            # but since we didn't successfully create it, we don't hold the lock.

    # Initialize config manager before the elevation gate so the non-elevated
    # process can still build the prompt UI and show a fallback dialog.
    config_manager = ConfigManager()
    _env_proxy_migration_pending = _prepare_env_proxy_migration(config_manager)
    config_manager.settings['_runtime_proxy_debug'] = bool(_args.proxy_debug)
    config_manager.settings['_runtime_proxy_debug_mode'] = _args.proxy_debug_mode or 'full'

    # Gate non-admin launches before opening the usable GUI. Some Windows setups
    # show UAC as a taskbar item instead of foregrounding it, so startup must
    # block here until UAC is accepted, denied, or fails.
    _admin_prompt_needed = (
        sys.platform == 'win32'
        and config_manager.proxy_features_enabled
        and config_manager.proxy_mode != 'env'
        and not _is_admin()
    )
    if sys.platform == 'darwin' and config_manager.proxy_mode != 'env':
        from .utils.macos_proxy_helper import helper_is_ready

        start_proxy = config_manager.proxy_features_enabled and helper_is_ready()
    else:
        start_proxy = config_manager.proxy_features_enabled and not _admin_prompt_needed

    # Start tracking time wasted from the stored total
    time_tracker.init(config_manager.time_wasted_seconds)
    atexit.register(time_tracker.save, config_manager)

    proxy_error_invoker = _ProxyErrorInvoker()
    proxy_error_invoker.show_proxy_error.connect(proxy_error_invoker.handle_proxy_error)
    tray_ref: dict[str, SystemTray | None] = {'tray': None}

    def _refresh_config_surfaces() -> None:
        config_manager.refresh_config_names()
        tray = tray_ref.get('tray')
        dashboard = getattr(tray, 'dashboard_window', None)
        if dashboard is not None:
            try:
                dashboard.refresh_configs_from_disk()
            except Exception as exc:
                log_buffer.log('Config', f'Failed to refresh Dashboard after config import: {exc}')

    config_folder_watcher = ConfigFolderWatcher(
        config_manager,
        parent=app,
        parent_provider=_visible_parent_widget,
    )
    config_folder_watcher.configs_changed.connect(_refresh_config_surfaces)
    app.aboutToQuit.connect(config_folder_watcher.stop)

    def _revert_uncredentialed_manual_upstream() -> None:
        if not _manual_upstream_credentials_missing(config_manager):
            return
        previous_mode = config_manager.upstream_transport_mode
        config_manager.upstream_transport_mode = 'auto'
        log_buffer.log(
            'Proxy',
            f'Reset upstream transport from {previous_mode} to auto after '
            '10 seconds without credentials',
        )
        tray = tray_ref.get('tray')
        dashboard = getattr(tray, 'dashboard_window', None)
        settings_tab = getattr(dashboard, '_settings_tab', None)
        if settings_tab is not None:
            settings_tab.refresh_from_config()
        if proxy_master.is_running:

            def _restart_proxy() -> None:
                proxy_master.stop()
                proxy_master.start()

            run_in_thread(_restart_proxy)()

    QTimer.singleShot(10_000, _revert_uncredentialed_manual_upstream)

    def _handle_proxy_features_start_failure(reason: str):
        _disable_proxy_features_after_start_failure(config_manager, tray_ref.get('tray'), reason)

    proxy_error_invoker.disable_proxy_features.connect(_handle_proxy_features_start_failure)

    def _on_proxy_start_error(code: str, details: dict):
        if code == 'upstream_connect_failed':
            if sys.platform == 'win32':
                proxy_error_invoker.show_proxy_error.emit(code, dict(details))
            return
        if code == 'linux_hosts_read_only':
            proxy_error_invoker.show_proxy_error.emit(code, dict(details))
            return
        if code == 'linux_helper_unavailable':
            proxy_error_invoker.disable_proxy_features.emit(
                'Linux Polkit approval was denied or the proxy helper could not start'
            )
            return
        if code == 'tls_self_test_failed':
            proxy_error_invoker.show_proxy_error.emit(code, dict(details))
            return
        if code not in (
            'port_bind_failed',
            'hosts_write_exhausted',
            'hosts_entries_would_exceed_limit',
            'hosts_file_too_large',
            'hosts_file_repair_failed',
            'macos_ca_patch_failed',
            'roblox_ca_patch_failed',
            'macos_ca_trust_failed',
            'macos_relay_failed',
        ):
            return
        proxy_error_invoker.show_proxy_error.emit(code, dict(details))

    # Initialize proxy master
    proxy_master = ProxyMaster(config_manager, on_proxy_start_error=_on_proxy_start_error)
    proxy_error_invoker.retry_proxy.connect(proxy_master.start)

    # Initialize modification manager (pass cache_scraper for asset-id resolution)
    mod_manager = ModificationManager(
        cache_scraper=getattr(proxy_master, 'cache_scraper', None),
        read_only_lock_enabled=config_manager.lock_roblox_files_read_only,
    )
    if not config_manager.lock_roblox_files_read_only:
        if not config_manager.read_only_lock_migration_v1_complete:
            # One-time cleanup for persistent guards left by older builds,
            # including the old cacert.pem lock.
            mod_manager.clear_managed_file_read_only(
                (roblox_dir / 'ssl' / 'cacert.pem' for roblox_dir in mod_manager.roblox_dirs),
                clear_untracked=True,
            )
            config_manager.read_only_lock_migration_v1_complete = True
        else:
            # Exact original modes persisted by the new opt-in guard survive a
            # crash and can be restored without changing unrelated files.
            mod_manager.clear_managed_file_read_only(clear_untracked=False)
    macos_bootstrapper_bridge = None
    if sys.platform == 'darwin':
        from .modifications.macos_bootstrapper_bridge import MacBootstrapperBridge

        macos_bootstrapper_bridge = MacBootstrapperBridge(
            mod_manager,
            app,
            custom_fflag_seed=lambda: proxy_master.prime_custom_fflag_cache(allow_running=True),
            custom_fflag_prepare=proxy_master.prepare_custom_fflags_for_player_launch,
        )
        app.aboutToQuit.connect(macos_bootstrapper_bridge.stop)

    def _refresh_managed_read_only_guard() -> None:
        try:
            if config_manager.lock_roblox_files_read_only:
                mod_manager.protect_managed_files()
        except Exception as exc:
            log_buffer.log('Modifications', f'Read-only guard refresh failed: {exc}')

    # Re-apply saved modifications on launch so the GUI state and Roblox files stay in sync.
    run_in_thread(mod_manager.reapply_all)()

    # ── Shutdown guards ───────────────────────────────────────────────────
    # 1. Graceful Windows shutdown / log-off: Qt fires commitDataRequest before
    #    the session ends, giving us a chance to clean up the hosts file.
    def _on_commit_data(_session):
        try:
            env_lifecycle.cancel()
        except NameError, AttributeError:
            pass
        mod_manager.clear_managed_file_read_only()
        proxy_master.stop()
        mod_manager.restore_all()

    app.commitDataRequest.connect(_on_commit_data)

    # 2. Normal Python exit (sys.exit, end of main): last-resort fallback so
    #    the hosts file is cleaned up even if the tray Exit path was bypassed.
    atexit.register(proxy_master.stop)
    atexit.register(mod_manager.clear_managed_file_read_only)
    atexit.register(mod_manager.restore_all)

    # Start PreJsons download in background
    run_in_thread(download_prejsons)()

    # Check for updates in the background
    start_update_check()

    # Sync launch integrations on every launch (updates if launch method changed).
    # All platforms use per-user launch entries and reconcile from the normal
    # non-elevated GUI process.
    _autostart_launch_sync_failed = False
    _desktop_integration_launch_sync_failed = False
    if config_manager.first_time_setup_complete and config_manager.desktop_integration:
        try:
            from .utils.desktop_integration import sync_desktop_integration

            _desktop_integration_launch_sync_failed = not sync_desktop_integration(True)
        except Exception as exc:
            _desktop_integration_launch_sync_failed = True
            log_buffer.log('DesktopIntegration', f'Launch desktop integration sync failed: {exc}')

    if config_manager.first_time_setup_complete and _should_sync_autostart_on_launch(
        config_manager.run_on_boot
    ):
        try:
            from .utils.autostart import sync_autostart

            _autostart_launch_sync_failed = not sync_autostart(
                True,
                CONFIG_DIR,
                proxy_mode=config_manager.proxy_mode,
            )
        except Exception as exc:
            _autostart_launch_sync_failed = True
            log_buffer.log('Autostart', f'Launch autostart sync failed: {exc}')

    # Start proxy only if enabled and we have admin rights
    if start_proxy and config_manager.proxy_features_enabled and config_manager.proxy_mode == 'env':
        if not _show_env_proxy_stale_hosts_dialog():
            start_proxy = False
            log_buffer.log(
                'Proxy',
                'Proxy startup cancelled because the oversized hosts file was not repaired',
            )

    if start_proxy:
        proxy_master.start()
        _refresh_managed_read_only_guard()
    elif not config_manager.proxy_features_enabled:
        log_buffer.log('Proxy', 'Proxy features disabled in settings: proxy not started')
    elif sys.platform == 'darwin':
        log_buffer.log('Proxy', 'Waiting for the macOS proxy helper before starting interception')
    else:
        log_buffer.log('Proxy', 'Read-only mode: proxy not started (no admin rights)')

    if (
        sys.platform == 'win32'
        and start_proxy
        and config_manager.proxy_mode == 'env'
        and config_manager.proxy_features_enabled
    ):
        _arm_windows_gdk_env_proxy_when_ready(proxy_master)

    # Env Proxy owns Player/Sober lifecycle independently of Studio.
    from .proxy.env_lifecycle import EnvProxyLifecycleController

    if sys.platform == 'win32':
        from .utils.platform_windows import (
            close_roblox_for_env_lifecycle,
            relaunch_roblox_with_proxy_env,
        )

        def _prepare_env_proxy_launch(path: Path) -> bool:
            result = proxy_master.ensure_env_proxy_roblox_ca(path, settle=False)
            return bool(result.get('success'))

        def _relaunch_env_player(
            proxy_url: str,
            _target: str | None,
            force: bool,
            cancel_event: threading.Event,
            _source_exe_path: Path | None,
            _player_already_stopped: bool,
        ) -> bool:
            return relaunch_roblox_with_proxy_env(
                proxy_url,
                force=force,
                cancel_event=cancel_event,
                prepare_launch=_prepare_env_proxy_launch,
            )

        _terminate_env_player = close_roblox_for_env_lifecycle

    elif sys.platform == 'darwin':
        from .utils.platform_macos import relaunch_roblox_with_proxy_env

        def _relaunch_env_player(
            proxy_url: str,
            target: str | None,
            force: bool,
            cancel_event: threading.Event,
            source_exe_path: Path | None,
            player_already_stopped: bool,
        ) -> bool:
            return relaunch_roblox_with_proxy_env(
                proxy_url,
                target,
                force=force,
                cancel_event=cancel_event,
                source_exe_path=source_exe_path,
                player_already_stopped=player_already_stopped,
            )

        _terminate_env_player = terminate_roblox

    else:
        def _relaunch_env_player(
            _proxy_url: str,
            _target: str | None,
            _force: bool,
            _cancel_event: threading.Event,
            _source_exe_path: Path | None,
            _player_already_stopped: bool,
        ) -> bool:
            log_buffer.log(
                'Launcher',
                'Linux Sober Env Proxy is supplied by Flatpak; synthetic relaunch skipped',
            )
            return False

        _terminate_env_player = terminate_roblox

    env_lifecycle = EnvProxyLifecycleController(
        config_manager=config_manager,
        proxy_master=proxy_master,
        resolve_player_exe=get_roblox_player_exe_path,
        relaunch_player=_relaunch_env_player,
        is_player_running=is_roblox_running,
        get_player_identity=get_roblox_process_identity,
        terminate_player=_terminate_env_player,
        wait_for_player_exit=wait_for_roblox_exit,
        adopted_player=_args.preserve_env_proxy_player,
        max_repairs=2,
    )
    atexit.register(env_lifecycle.cancel)

    # Setup Roblox exit monitor for auto cache deletion (before tray to pass to it)
    roblox_monitor = RobloxExitMonitor(config_manager, proxy_master, mod_manager, env_lifecycle)
    app.aboutToQuit.connect(roblox_monitor.stop)

    # Create system tray
    tray = SystemTray(app, config_manager, proxy_master, mod_manager, roblox_monitor)
    tray_ref['tray'] = tray
    app.aboutToQuit.connect(tray.cleanup_tray_icon)
    single_instance_control_server = _start_single_instance_control_server(app, tray)

    if _env_proxy_migration_pending:
        _show_env_proxy_migration(config_manager, roblox_monitor)

    def _handle_roblox_uri_event(target: str) -> None:
        run_in_thread(_launch_roblox_uri_for_instance)(tray, target)

    roblox_url_event_filter.roblox_uri_received.connect(_handle_roblox_uri_event)
    roblox_url_event_filter.start()
    if pending_roblox_uri:
        QTimer.singleShot(
            0,
            lambda target=pending_roblox_uri: run_in_thread(_launch_roblox_uri_for_instance)(
                tray, target
            ),
        )
    log_buffer.log('App', f'Persistent log file: {LOG_FILE}')
    if _autostart_launch_sync_failed:
        QTimer.singleShot(
            0,
            lambda: _show_run_on_boot_failure(_visible_parent_widget(), config_manager.proxy_mode),
        )
    if _desktop_integration_launch_sync_failed:
        QTimer.singleShot(0, lambda: _show_desktop_integration_failure(_visible_parent_widget()))

    def _check_roblox_permission_failures() -> None:
        denied_dirs = mod_manager.take_permission_denied_dirs()
        if denied_dirs:
            _show_roblox_permission_failure(_visible_parent_widget(), denied_dirs, mod_manager)
        QTimer.singleShot(500, _check_roblox_permission_failures)

    if sys.platform == 'win32':
        QTimer.singleShot(500, _check_roblox_permission_failures)
    _admin_prompt_shown = False

    def _request_admin_once():
        nonlocal _admin_prompt_shown
        if _admin_prompt_shown or _is_admin():
            return
        _admin_prompt_shown = True

        gate = QDialog(None)
        gate.setModal(True)
        gate.setWindowTitle('Administrator Permission Required')
        gate.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        gate_layout = QVBoxLayout(gate)
        if sys.platform == 'darwin':
            gate_text = (
                'Fleasion is waiting for macOS administrator permission.\n\n'
                'Approve the helper install prompt so the normal-user app can use proxy features.'
            )
        else:
            gate_text = (
                'Fleasion is waiting for Windows administrator permission.\n\n'
                'If the UAC prompt is flashing on the taskbar, click it and choose Yes or No.'
            )
        gate_label = QLabel(gate_text)
        gate_label.setWordWrap(True)
        gate_layout.addWidget(gate_label)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            gate.setWindowIcon(QIcon(str(icon_path)))
        gate.show()
        gate.raise_()
        gate.activateWindow()
        QApplication.processEvents()

        log_buffer.log('UAC', 'Requesting administrator relaunch from GUI startup path')
        if _relaunch_as_admin(parent_hwnd=_window_handle(gate)):
            gate.close()
            sys.exit(0)

        gate.close()
        _show_admin_required_dialog()

    if _admin_prompt_needed:
        _request_admin_once()

    def _install_macos_helper_and_start_proxy():
        if (
            sys.platform != 'darwin'
            or not config_manager.proxy_features_enabled
            or proxy_master.is_running
        ):
            return

        from .utils.macos_proxy_helper import helper_is_ready, install_helper

        if helper_is_ready():
            proxy_master.start()
            _refresh_managed_read_only_guard()
            return
        if _suppress_dashboard:
            log_buffer.log(
                'ProxyHelper',
                'Autostart launch skipped helper installation prompt; open Fleasion normally to install it',
            )
            return

        prompt = QMessageBox(_visible_parent_widget())
        prompt.setWindowTitle('Install Proxy Helper')
        prompt.setIcon(QMessageBox.Icon.Information)
        prompt.setText('Install the Fleasion macOS proxy helper?')
        prompt.setInformativeText(
            'macOS requires a small root service to own local port 443, update /etc/hosts, '
            "and patch Roblox's SSL trust bundle.\n\n"
            'This requires one administrator approval now. Fleasion itself will keep running as your normal user, '
            'and future launches and Run on Boot will not ask for an administrator password.'
        )
        install_button = prompt.addButton('Install Helper', QMessageBox.ButtonRole.AcceptRole)
        cancel_button = prompt.addButton('Not Now', QMessageBox.ButtonRole.RejectRole)
        prompt.setDefaultButton(install_button)
        prompt.exec()
        if prompt.clickedButton() == cancel_button:
            log_buffer.log('ProxyHelper', 'macOS proxy helper installation postponed')
            return

        ok, detail = install_helper()
        if ok:
            proxy_master.start()
            _refresh_managed_read_only_guard()
            return

        log_buffer.log('ProxyHelper', f'macOS proxy helper installation failed: {detail}')
        QMessageBox.warning(
            _visible_parent_widget(),
            'Fleasion - Proxy Helper Installation Failed',
            f'Fleasion could not install or start the macOS proxy helper.\n\n{detail}',
        )

    if sys.platform == 'darwin' and config_manager.proxy_features_enabled and not start_proxy:
        _install_macos_helper_and_start_proxy()

    # Warn if no Roblox installations can be found (same scan used for cert injection)
    from .proxy.master import _find_roblox_dirs as _scan_roblox_dirs

    if not _scan_roblox_dirs():
        _top = QApplication.topLevelWidgets()
        _parent = next((w for w in _top if w.isVisible()), None)
        _on_top = any(
            w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
            for w in _top
        )
        _no_roblox_msg = QMessageBox(_parent)
        if _on_top:
            _no_roblox_msg.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        _no_roblox_msg.setWindowTitle('Roblox Not Found')
        _no_roblox_msg.setIcon(QMessageBox.Icon.Warning)
        _no_roblox_msg.setText('Roblox does not appear to be installed.')
        _no_roblox_msg.setInformativeText(
            'Fleasion could not find any Roblox installations on this computer.\n\n'
            'If this is incorrect, click OK and launch Roblox, Fleasion will attempt to detect it.\n\n'
            'Please close Fleasion, install Roblox, and then relaunch Fleasion.\n\n'
            "Without Roblox installed, the majority of Fleasion's features cannot be used.\n\n"
            'Note: To fully close Fleasion, right click Fleasion in the system tray and click Exit.'
        )
        _no_roblox_msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            _no_roblox_msg.setWindowIcon(QIcon(str(icon_path)))
        _no_roblox_msg.exec()

    # Setup periodic status update
    status_timer = QTimer()
    status_timer.timeout.connect(tray.update_status)
    status_timer.start(1000)  # Update every second

    # Setup Roblox check timer
    roblox_check_timer = QTimer()
    roblox_check_timer.timeout.connect(roblox_monitor.check_roblox_status)
    roblox_check_timer.start(500)  # Check every 0.5 seconds

    managed_read_only_timer = QTimer()
    managed_read_only_timer.timeout.connect(_refresh_managed_read_only_guard)
    managed_read_only_timer.start(1000)
    QTimer.singleShot(250, _refresh_managed_read_only_guard)
    QTimer.singleShot(1500, _refresh_managed_read_only_guard)

    # Show first-time setup guide if this is the first run.
    if not _suppress_dashboard and not config_manager.first_time_setup_complete:
        _top = QApplication.topLevelWidgets()
        _parent = next((w for w in _top if w.isVisible()), None)
        _on_top = any(
            w.isVisible() and bool(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
            for w in _top
        )
        welcome_box = _FirstTimeSetupMessageBox(_parent)
        if _on_top:
            welcome_box.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        welcome_box.setWindowTitle('Welcome')
        welcome_box.setText(
            'Welcome to Fleasion!\n\n'
            'Fleasion uses Roblox Env Proxy mode by default. Normal use does not require '
            'administrator permission, and Roblox Studio is left untouched. You can switch '
            'to Hosts File mode at any time under Settings > Proxy > Proxy Mode; that mode '
            'may require administrator permission.\n\n'
            'Quick setup guide:\n\n'
            '1. Use the Replacer tab to manage asset replacements. At the bottom, add IDs you want '
            'to replace, then choose a replacement ID, URL, or local file.\n\n'
            '2. To find asset IDs, click "Scraped games..." in the Replacer tab. Click an asset ID '
            'to add it to Asset IDs, or click Replacement ID to use that asset as the replacement.\n\n'
            '3. Click "Add new", then enable your config at the top next to "Enabled". For most '
            'users this means turning on "Default".\n\n'
            '4. Click "Clear Cache" before joining a game so Roblox downloads the '
            'assets through Fleasion instead of using cached originals.\n\n'
            '5. For assets that are not in Scraped games, open the Scraper tab, enable the cache '
            'scraper, clear cache, and join the Roblox game. Every loaded asset will appear there. '
            'Right-click assets to download them, Replace them, or Replace With them.\n\n'
            'Other tabs are optional tools and settings and are self explanatory.\n\n'
            'Fleasion is client-sided: only you see your changes. Roblox currently cannot/ '
            "doesn't ban or warn you for local asset replacement, and game developers cannot meaningfully "
            'detect it. Game moderators can still ban users for any reason, so use your own '
            'judgment, we take no responsiblity. Roblox has no known detections for fleasion and there '
            'has been no reported cases of warnings or bans for using it, but Roblox has stated it is '
            'not permitted.'
        )
        welcome_box.setIcon(QMessageBox.Icon.Information)
        welcome_box.setStandardButtons(QMessageBox.StandardButton.Ok)
        ok_button = welcome_box.button(QMessageBox.StandardButton.Ok)
        wait_seconds = 15
        remaining_seconds = wait_seconds
        if ok_button is not None:
            ok_button.setEnabled(False)
            ok_button.setText(f'OK ({remaining_seconds}s)')

            countdown_timer = QTimer(welcome_box)
            countdown_timer.setInterval(1000)

            def _update_welcome_countdown():
                nonlocal remaining_seconds
                remaining_seconds -= 1
                if remaining_seconds <= 0:
                    countdown_timer.stop()
                    welcome_box.allow_accept()
                    ok_button.setText('OK')
                    ok_button.setEnabled(True)
                else:
                    ok_button.setText(f'OK ({remaining_seconds}s)')

            countdown_timer.timeout.connect(_update_welcome_countdown)
            countdown_timer.start()
        if icon_path := get_icon_path():
            from PyQt6.QtGui import QIcon

            welcome_box.setWindowIcon(QIcon(str(icon_path)))
        welcome_box.exec()
        _prompt_first_time_startup_options(config_manager, tray)
        config_manager.env_proxy_migration_v1_complete = True
        config_manager.first_time_setup_complete = True
        tray._show_replacer_config()
    elif not _suppress_dashboard and config_manager.open_dashboard_on_launch:
        # Open dashboard on launch if enabled (suppressed when started by autostart task)
        tray._show_replacer_config()

    _auth_prompt_shown = False
    auth_check_invoker = _AuthCheckInvoker()

    def _handle_auth_check_complete(found: bool, details: dict):
        nonlocal _auth_prompt_shown
        if found or _auth_prompt_shown:
            return
        _auth_prompt_shown = True
        if sys.platform == 'darwin':
            try:
                from .utils.roblox_auth import (
                    get_auth_failure_details,
                    get_roblosecurity,
                    notify_auth_source_changed,
                )

                if config_manager.macos_auth_source:
                    log_buffer.log(
                        'Auth',
                        f'Configured Roblox login source {config_manager.macos_auth_source} did not produce a valid token; reopening browser picker',
                    )
                    config_manager.macos_auth_source = ''
                    notify_auth_source_changed()
                    choice_result = _choose_macos_auth_source_on_launch(
                        config_manager, tray, force=True
                    )
                    if choice_result in {'selected', 'already-configured'}:
                        retry_cookie = get_roblosecurity(include_keychain_browsers=True)
                        if retry_cookie:
                            return
                        details = get_auth_failure_details()
                    elif choice_result == 'skipped':
                        details = dict(details)
                        details['user_skipped_token'] = True
            except Exception as exc:
                log_buffer.log(
                    'Auth',
                    f'Unexpected error while retrying macOS auth picker: {type(exc).__name__}: {exc}',
                )
        _show_auth_cookie_unavailable_dialog(details, tray)

    auth_check_invoker.completed.connect(_handle_auth_check_complete)
    initial_auth_choice = _choose_macos_auth_source_on_launch(config_manager, tray)
    if initial_auth_choice == 'skipped':
        _auth_prompt_shown = True
        try:
            from .utils.roblox_auth import get_auth_failure_details, get_roblosecurity

            get_roblosecurity(include_keychain_browsers=False)
            skip_details = get_auth_failure_details()
        except Exception as exc:
            log_buffer.log(
                'Auth',
                f'Unexpected error while preparing token-skip warning: {type(exc).__name__}: {exc}',
            )
            skip_details = {}
        skip_details = dict(skip_details)
        skip_details['user_skipped_token'] = True
        _show_auth_cookie_unavailable_dialog(skip_details, tray)

    def _check_auth_cookie_once():
        try:
            from .utils.roblox_auth import get_auth_failure_details, get_roblosecurity

            if sys.platform == 'darwin':
                log_buffer.log('Auth', 'Running startup Roblox login discovery')
            cookie = get_roblosecurity(
                include_keychain_browsers=sys.platform == 'darwin'
                or sys.platform.startswith('linux')
            )
            details = get_auth_failure_details()
        except Exception as exc:
            log_buffer.log(
                'Auth',
                f'Unexpected error during startup auth check: {type(exc).__name__}: {exc}',
            )
            return
        auth_check_invoker.completed.emit(bool(cookie), details)

    QTimer.singleShot(1500, run_in_thread(_check_auth_cookie_once))

    # Run application
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
