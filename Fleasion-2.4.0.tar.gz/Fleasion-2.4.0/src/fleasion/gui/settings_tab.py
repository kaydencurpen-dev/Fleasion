"""Settings tab – mirrors all settings available in the system tray menu."""

import sys
from pathlib import Path

from PyQt6.QtCore import QEvent, Qt, QTimer
from PyQt6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from ..gui.theme import ThemeManager
from ..utils import CONFIG_DIR, run_in_thread
from ..utils.autostart import sync_autostart, windows_autostart_privilege_hint
from ..utils.desktop_integration import sync_desktop_integration
from ..utils.roblox_auth import (
    notify_auth_source_changed,
    store_manual_roblosecurity,
    validate_roblosecurity_for_import,
)
from .modifications_tab import CollapsibleSection, DropdownComboBox, NoWheelSpinBox

_MACOS_AUTH_SOURCES = (
    ('Choose on launch', ''),
    ('Manual Token', 'manual'),
    ('Chrome', 'Chrome'),
    ('Safari', 'Safari'),
    ('Firefox', 'Firefox'),
    ('Brave', 'Brave'),
    ('Edge', 'Edge'),
    ('Chromium', 'Chromium'),
    ('Opera', 'Opera'),
    ('Vivaldi', 'Vivaldi'),
)


class EnvProxyWarningDialog(QMessageBox):
    """Explain the Player-only relaunch behavior when Env Proxy is selected."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Roblox Env Proxy')
        self.setIcon(QMessageBox.Icon.Information)
        self.setText(
            'Fleasion will relaunch Roblox Player with a local proxy environment.\n\n'
            'Roblox Studio is left untouched. Microsoft Store/Xbox (GDK) Roblox uses '
            'package-aware activation so its Player child receives Fleasion\'s scoped '
            'environment. If Windows rejects that activation, the client is left untouched; '
            'Hosts File mode remains the fallback for GDK traffic. Switching back to Hosts '
            'File mode may require administrator permission.'
        )
        self.setStandardButtons(QMessageBox.StandardButton.Ok)


class SettingsTab(QWidget):
    """Settings tab exposing all options found in the system tray Settings menu."""

    def __init__(self, config_manager, system_tray=None, parent=None):
        super().__init__(parent)
        self._config = config_manager
        self._tray = system_tray
        self._manual_proxy_credentials_timer = QTimer(self)
        self._manual_proxy_credentials_timer.setSingleShot(True)
        self._manual_proxy_credentials_timer.setInterval(10_000)
        self._manual_proxy_credentials_timer.timeout.connect(
            self._revert_manual_proxy_without_credentials
        )
        self._setup_ui()
        self._sync_manual_proxy_credentials_timer()

    # UI construction

    def _setup_ui(self):
        outer = QVBoxLayout()
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        container = QWidget()
        container.setObjectName('_FleasionSettingsContainer')
        self._settings_container = container
        self._container_layout = QVBoxLayout()
        self._container_layout.setSpacing(10)
        self._container_layout.setContentsMargins(10, 10, 10, 10)

        self._container_layout.addWidget(self._build_appearance_section())
        self._container_layout.addWidget(self._build_proxy_section())
        self._container_layout.addWidget(self._build_convenience_section())
        if sys.platform == 'darwin':
            self._container_layout.addWidget(self._build_macos_auth_section())
        self._container_layout.addWidget(self._build_scraper_section())
        self._container_layout.addWidget(self._build_scraped_games_section())
        self._container_layout.addWidget(self._build_export_section())
        self._container_layout.addStretch()

        container.setLayout(self._container_layout)

        footer_widget = QWidget()
        footer_widget.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        self._footer_widget = footer_widget
        footer_layout = QHBoxLayout(footer_widget)
        footer_layout.setContentsMargins(8, 4, 8, 4)
        self._status_label = QLabel('')
        self._status_label.setStyleSheet('color: #888;')
        footer_layout.addWidget(self._status_label)
        footer_layout.addStretch()
        clear_cache_btn = QPushButton('Clear Cache')
        clear_cache_btn.clicked.connect(self._clear_roblox_cache)
        footer_layout.addWidget(clear_cache_btn)

        scroll.setWidget(container)
        outer.addWidget(scroll)
        outer.addWidget(footer_widget)
        self.setLayout(outer)
        self._update_container_bg()

    def changeEvent(self, a0: QEvent | None):
        super().changeEvent(a0)
        if a0 is not None and a0.type() == QEvent.Type.PaletteChange:
            self._update_container_bg()

    # Appearance

    def _build_appearance_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Appearance', expanded=True)

        self._theme_buttons: dict[str, QCheckBox] = {}
        btn_group = QButtonGroup(self)
        btn_group.setExclusive(True)
        theme_row = QHBoxLayout()
        theme_row.setContentsMargins(0, 0, 0, 0)
        current_theme = self._config.theme
        for name in ('System', 'Light', 'Dark'):
            chk = QCheckBox(name)
            chk.setChecked(name == current_theme)
            chk.toggled.connect(lambda checked, t=name: self._on_theme_toggled(checked, t))
            btn_group.addButton(chk)
            theme_row.addWidget(chk)
            self._theme_buttons[name] = chk
        theme_row.addStretch()

        row_widget = QWidget()
        row_widget.setLayout(theme_row)
        section.add_widget(row_widget)

        return section

    def _build_macos_auth_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Roblox Login', expanded=True)

        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(QLabel('Roblox is signed in through'))
        self._macos_auth_source_combo = QComboBox()
        for label, value in _MACOS_AUTH_SOURCES:
            self._macos_auth_source_combo.addItem(label, value)
        idx = self._macos_auth_source_combo.findData(self._config.macos_auth_source)
        self._macos_auth_source_combo.setCurrentIndex(max(0, idx))
        self._macos_auth_source_combo.activated.connect(self._on_macos_auth_source_changed)
        row.addWidget(self._macos_auth_source_combo)
        self._manual_token_btn = QPushButton('Import Token')
        self._manual_token_btn.clicked.connect(self._on_import_manual_token)
        row.addWidget(self._manual_token_btn)
        row.addStretch()

        row_widget = QWidget()
        row_widget.setLayout(row)
        section.add_widget(row_widget)
        return section

    # Proxy

    def _build_proxy_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Proxy', expanded=True)

        self._proxy_features_chk = QCheckBox('⚠ Enable Proxy Features')
        self._proxy_features_chk.setChecked(self._config.proxy_features_enabled)
        self._proxy_features_chk.toggled.connect(self._on_proxy_features_toggled)
        section.add_widget(self._proxy_features_chk)

        # Warning shown under the proxy features checkbox
        self._proxy_warning_label = QLabel('DO NOT TOUCH UNLESS YOU KNOW WHAT YOU ARE DOING')
        self._proxy_warning_label.setStyleSheet('color: #e07a00; font-weight: bold;')
        section.add_widget(self._proxy_warning_label)

        mode_row = QHBoxLayout()
        mode_row.setContentsMargins(0, 0, 0, 0)
        mode_row.addWidget(QLabel('Upstream Transport'))
        self._upstream_mode_combo = DropdownComboBox()
        self._upstream_mode_combo.addItem('Auto', 'auto')
        self._upstream_mode_combo.addItem('Direct IP', 'direct_ip')
        self._upstream_mode_combo.addItem('System Proxy', 'system_proxy')
        self._upstream_mode_combo.addItem('Manual HTTP CONNECT', 'http_connect')
        self._upstream_mode_combo.addItem('Manual SOCKS5', 'socks5')
        current_mode = self._config.upstream_transport_mode
        idx = self._upstream_mode_combo.findData(current_mode)
        self._upstream_mode_combo.setCurrentIndex(max(0, idx))
        self._upstream_mode_combo.activated.connect(self._on_upstream_mode_changed)
        mode_row.addWidget(self._upstream_mode_combo)
        mode_row.addStretch()
        mode_widget = QWidget()
        mode_widget.setLayout(mode_row)
        section.add_widget(mode_widget)

        proxy_mode_row = QHBoxLayout()
        proxy_mode_row.setContentsMargins(0, 0, 0, 0)
        proxy_mode_row.addWidget(QLabel('Proxy Mode'))
        self._proxy_mode_combo = DropdownComboBox()
        self._proxy_mode_combo.addItem('Hosts File', 'hosts')
        self._proxy_mode_combo.addItem('Roblox Env Proxy', 'env')
        current_proxy_mode = self._config.proxy_mode
        proxy_mode_idx = self._proxy_mode_combo.findData(current_proxy_mode)
        self._proxy_mode_combo.setCurrentIndex(max(0, proxy_mode_idx))
        self._proxy_mode_combo.activated.connect(self._on_proxy_mode_changed)
        proxy_mode_row.addWidget(self._proxy_mode_combo)
        proxy_mode_row.addStretch()
        proxy_mode_widget = QWidget()
        proxy_mode_widget.setLayout(proxy_mode_row)
        section.add_widget(proxy_mode_widget)

        self._wire_preserving_chk = QCheckBox(
            'Enable Wire-Preserving Passthrough (Advanced compatibility mode)'
        )
        self._wire_preserving_chk.setChecked(self._config.wire_preserving_passthrough)
        self._wire_preserving_chk.toggled.connect(self._on_wire_preserving_toggled)
        section.add_widget(self._wire_preserving_chk)

        def _proxy_row(label: str, host_value: str, port_value: int):
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.addWidget(QLabel(label))
            host = QLineEdit()
            host.setText(host_value)
            host.setPlaceholderText('Host')
            port = QSpinBox()
            port.setRange(0, 65535)
            port.setValue(port_value)
            port.setPrefix('Port ')
            row.addWidget(host, 1)
            row.addWidget(port)
            widget = QWidget()
            widget.setLayout(row)
            section.add_widget(widget)
            return host, port

        self._http_proxy_host, self._http_proxy_port = _proxy_row(
            'HTTP CONNECT',
            self._config.upstream_http_connect_host,
            self._config.upstream_http_connect_port,
        )
        self._http_proxy_host.editingFinished.connect(self._on_http_proxy_changed)
        self._http_proxy_port.valueChanged.connect(self._on_http_proxy_changed)

        self._socks5_host, self._socks5_port = _proxy_row(
            'SOCKS5',
            self._config.upstream_socks5_host,
            self._config.upstream_socks5_port,
        )
        self._socks5_host.editingFinished.connect(self._on_socks5_proxy_changed)
        self._socks5_port.valueChanged.connect(self._on_socks5_proxy_changed)

        auth_row = QHBoxLayout()
        auth_row.setContentsMargins(0, 0, 0, 0)
        auth_row.addWidget(QLabel('Proxy Auth'))
        self._http_proxy_user = QLineEdit()
        self._http_proxy_user.setText(self._config.upstream_http_connect_username)
        self._http_proxy_user.setPlaceholderText('HTTP user')
        self._http_proxy_pass = QLineEdit()
        self._http_proxy_pass.setText(self._config.upstream_http_connect_password)
        self._http_proxy_pass.setPlaceholderText('HTTP password')
        self._http_proxy_pass.setEchoMode(QLineEdit.EchoMode.Password)
        self._socks5_user = QLineEdit()
        self._socks5_user.setText(self._config.upstream_socks5_username)
        self._socks5_user.setPlaceholderText('SOCKS user')
        self._socks5_pass = QLineEdit()
        self._socks5_pass.setText(self._config.upstream_socks5_password)
        self._socks5_pass.setPlaceholderText('SOCKS password')
        self._socks5_pass.setEchoMode(QLineEdit.EchoMode.Password)
        for widget in (
            self._http_proxy_user,
            self._http_proxy_pass,
            self._socks5_user,
            self._socks5_pass,
        ):
            auth_row.addWidget(widget)
        auth_widget = QWidget()
        auth_widget.setLayout(auth_row)
        section.add_widget(auth_widget)
        self._http_proxy_user.editingFinished.connect(self._on_http_proxy_auth_changed)
        self._http_proxy_pass.editingFinished.connect(self._on_http_proxy_auth_changed)
        self._socks5_user.editingFinished.connect(self._on_socks5_proxy_auth_changed)
        self._socks5_pass.editingFinished.connect(self._on_socks5_proxy_auth_changed)

        limits_row = QHBoxLayout()
        limits_row.setContentsMargins(0, 0, 0, 0)
        limits_row.addWidget(QLabel('VPN Connection Limits'))
        self._asset_limit_spin = NoWheelSpinBox()
        self._asset_limit_spin.setRange(1, 128)
        self._asset_limit_spin.setValue(self._config.vpn_compat_max_assetdelivery_connections)
        self._asset_limit_spin.setPrefix('Asset ')
        self._cdn_limit_spin = NoWheelSpinBox()
        self._cdn_limit_spin.setRange(1, 256)
        self._cdn_limit_spin.setValue(self._config.vpn_compat_max_cdn_connections)
        self._cdn_limit_spin.setPrefix('CDN ')
        self._asset_limit_spin.valueChanged.connect(self._on_connection_limits_changed)
        self._cdn_limit_spin.valueChanged.connect(self._on_connection_limits_changed)
        limits_row.addWidget(self._asset_limit_spin)
        limits_row.addWidget(self._cdn_limit_spin)
        limits_row.addStretch()
        limits_widget = QWidget()
        limits_widget.setLayout(limits_row)
        section.add_widget(limits_widget)

        return section

    # Startup

    def _build_convenience_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Convenience', expanded=True)

        self._open_dashboard_chk = QCheckBox('Open Dashboard on Start')
        self._open_dashboard_chk.setChecked(self._config.open_dashboard_on_launch)
        self._open_dashboard_chk.toggled.connect(self._on_open_dashboard_toggled)
        section.add_widget(self._open_dashboard_chk)

        self._auto_clear_cache_chk = QCheckBox('Auto-Clear Cache on Exit')
        self._auto_clear_cache_chk.setChecked(self._config.auto_delete_cache_on_exit)
        self._auto_clear_cache_chk.toggled.connect(self._on_auto_clear_cache_toggled)
        section.add_widget(self._auto_clear_cache_chk)

        self._clear_cache_launch_chk = QCheckBox('Clear Cache on Launch')
        self._clear_cache_launch_chk.setChecked(self._config.clear_cache_on_launch)
        self._clear_cache_launch_chk.toggled.connect(self._on_clear_cache_launch_toggled)
        section.add_widget(self._clear_cache_launch_chk)

        self._lock_roblox_files_chk = QCheckBox('Lock Roblox Files to Read-Only')
        self._lock_roblox_files_chk.setChecked(self._config.lock_roblox_files_read_only)
        self._lock_roblox_files_chk.setToolTip(
            'Stops Roblox from overwriting active Fleasion modification files in rare cases. '
            'This can interfere with Roblox updates, so it is off by default.'
        )
        self._lock_roblox_files_chk.toggled.connect(self._on_lock_roblox_files_toggled)
        section.add_widget(self._lock_roblox_files_chk)

        self._close_env_roblox_chk = QCheckBox('Close Env-Proxied Roblox Player on Exit')
        self._close_env_roblox_chk.setChecked(self._config.close_env_proxy_roblox_on_exit)
        self._close_env_roblox_chk.setToolTip(
            'Roblox Player and Sober depend on Fleasion while Env Proxy is active. '
            'Turn this off only if you intentionally want Player left open without Fleasion.'
        )
        self._close_env_roblox_chk.toggled.connect(self._on_close_env_roblox_toggled)
        section.add_widget(self._close_env_roblox_chk)

        self._run_on_boot_chk = QCheckBox('Run on Boot')
        self._run_on_boot_chk.setChecked(self._config.run_on_boot)
        self._run_on_boot_chk.toggled.connect(self._on_run_on_boot_toggled)
        section.add_widget(self._run_on_boot_chk)

        self._desktop_integration_chk = QCheckBox('Create desktop/start menu integration on boot')
        self._desktop_integration_chk.setChecked(self._config.desktop_integration)
        self._desktop_integration_chk.toggled.connect(self._on_desktop_integration_toggled)
        section.add_widget(self._desktop_integration_chk)

        self._close_scraped_games_chk = QCheckBox('Close Roblox on Open')
        self._close_scraped_games_chk.setChecked(self._config.close_scraped_games_on_open)
        self._close_scraped_games_chk.toggled.connect(self._on_close_scraped_games_toggled)
        section.add_widget(self._close_scraped_games_chk)

        self._close_to_tray_chk = QCheckBox('Close to Tray')
        self._close_to_tray_chk.setChecked(self._config.close_to_tray)
        self._close_to_tray_chk.toggled.connect(self._on_close_to_tray_toggled)
        section.add_widget(self._close_to_tray_chk)

        self._always_on_top_chk = QCheckBox('Always on Top')
        self._always_on_top_chk.setChecked(self._config.always_on_top)
        self._always_on_top_chk.toggled.connect(self._on_always_on_top_toggled)
        section.add_widget(self._always_on_top_chk)

        return section

    def _build_scraper_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Scraper', expanded=True)

        self._cache_scraper_chk = QCheckBox('Enable Cache Scraper')
        self._cache_scraper_chk.setChecked(self._is_cache_scraper_enabled())
        self._cache_scraper_chk.toggled.connect(self._on_cache_scraper_toggled)
        section.add_widget(self._cache_scraper_chk)

        self._show_names_chk = QCheckBox('Show Names')
        self._show_names_chk.setChecked(self._config.show_names)
        self._show_names_chk.toggled.connect(self._on_show_names_toggled)
        section.add_widget(self._show_names_chk)

        self._show_creator_id_chk = QCheckBox('Show User ID')
        self._show_creator_id_chk.setChecked(self._config.show_creator_id)
        self._show_creator_id_chk.toggled.connect(self._on_show_creator_id_toggled)
        section.add_widget(self._show_creator_id_chk)

        return section

    # Export naming

    def _build_export_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Export Naming', expanded=True)

        self._export_chks: dict[str, QCheckBox] = {}
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        for option in ('name', 'id', 'hash'):
            chk = QCheckBox(option.capitalize())
            chk.setChecked(self._config.is_export_naming_enabled(option))
            chk.toggled.connect(
                lambda checked, opt=option: self._on_export_naming_toggled(checked, opt)
            )
            row.addWidget(chk)
            self._export_chks[option] = chk
        row.addStretch()
        row_widget = QWidget()
        row_widget.setLayout(row)
        section.add_widget(row_widget)

        return section

    def _build_scraped_games_section(self) -> CollapsibleSection:
        section = CollapsibleSection('Scraped Games', expanded=True)

        self._show_replacer_notifications_chk = QCheckBox('Show Replacer Notifications')
        self._show_replacer_notifications_chk.setChecked(self._config.show_replacer_notifications)
        self._show_replacer_notifications_chk.toggled.connect(
            self._on_show_replacer_notifications_toggled
        )
        section.add_widget(self._show_replacer_notifications_chk)

        self._close_viewer_on_replace_chk = QCheckBox('Close Viewer on Replace')
        self._close_viewer_on_replace_chk.setChecked(self._config.close_viewer_on_replace)
        self._close_viewer_on_replace_chk.toggled.connect(self._on_close_viewer_on_replace_toggled)
        section.add_widget(self._close_viewer_on_replace_chk)

        self._close_scraped_games_menu_on_open_chk = QCheckBox('Close Scraped Games Menu on Open')
        self._close_scraped_games_menu_on_open_chk.setChecked(
            self._config.close_scraped_games_menu_on_open
        )
        self._close_scraped_games_menu_on_open_chk.toggled.connect(
            self._on_close_scraped_games_menu_on_open_toggled
        )
        section.add_widget(self._close_scraped_games_menu_on_open_chk)

        return section

    def _update_container_bg(self):
        """Keep the Settings tab background aligned with the tab theme."""
        colors = ThemeManager.panel_colors(self.palette())
        self._settings_container.setStyleSheet(
            f'QWidget#_FleasionSettingsContainer {{ {colors.container_background_css} }}'
        )

    # Public

    def refresh_from_config(self):
        """Re-read all settings from config and update widgets (no signals emitted)."""
        for name, rb in self._theme_buttons.items():
            rb.blockSignals(True)
            rb.setChecked(name == self._config.theme)
            rb.blockSignals(False)

        for chk, value in [
            (self._open_dashboard_chk, self._config.open_dashboard_on_launch),
            (self._proxy_features_chk, self._config.proxy_features_enabled),
            (self._wire_preserving_chk, self._config.wire_preserving_passthrough),
            (self._auto_clear_cache_chk, self._config.auto_delete_cache_on_exit),
            (self._clear_cache_launch_chk, self._config.clear_cache_on_launch),
            (self._lock_roblox_files_chk, self._config.lock_roblox_files_read_only),
            (self._close_env_roblox_chk, self._config.close_env_proxy_roblox_on_exit),
            (self._run_on_boot_chk, self._config.run_on_boot),
            (self._desktop_integration_chk, self._config.desktop_integration),
            (self._close_scraped_games_chk, self._config.close_scraped_games_on_open),
            (self._close_to_tray_chk, self._config.close_to_tray),
            (self._always_on_top_chk, self._config.always_on_top),
            (
                self._show_replacer_notifications_chk,
                self._config.show_replacer_notifications,
            ),
            (self._close_viewer_on_replace_chk, self._config.close_viewer_on_replace),
            (
                self._close_scraped_games_menu_on_open_chk,
                self._config.close_scraped_games_menu_on_open,
            ),
            (self._show_names_chk, self._config.show_names),
            (self._show_creator_id_chk, self._config.show_creator_id),
        ]:
            chk.blockSignals(True)
            chk.setChecked(value)
            chk.blockSignals(False)

        idx = self._upstream_mode_combo.findData(self._config.upstream_transport_mode)
        self._upstream_mode_combo.blockSignals(True)
        self._upstream_mode_combo.setCurrentIndex(max(0, idx))
        self._upstream_mode_combo.blockSignals(False)

        idx = self._proxy_mode_combo.findData(self._config.proxy_mode)
        self._proxy_mode_combo.blockSignals(True)
        self._proxy_mode_combo.setCurrentIndex(max(0, idx))
        self._proxy_mode_combo.blockSignals(False)

        for widget, value in [
            (self._http_proxy_host, self._config.upstream_http_connect_host),
            (self._http_proxy_user, self._config.upstream_http_connect_username),
            (self._http_proxy_pass, self._config.upstream_http_connect_password),
            (self._socks5_host, self._config.upstream_socks5_host),
            (self._socks5_user, self._config.upstream_socks5_username),
            (self._socks5_pass, self._config.upstream_socks5_password),
        ]:
            widget.blockSignals(True)
            widget.setText(value)
            widget.blockSignals(False)

        for widget, value in [
            (self._http_proxy_port, self._config.upstream_http_connect_port),
            (self._socks5_port, self._config.upstream_socks5_port),
            (
                self._asset_limit_spin,
                self._config.vpn_compat_max_assetdelivery_connections,
            ),
            (self._cdn_limit_spin, self._config.vpn_compat_max_cdn_connections),
        ]:
            widget.blockSignals(True)
            widget.setValue(value)
            widget.blockSignals(False)

        self.set_cache_scraper_enabled(self._is_cache_scraper_enabled())

        for option, chk in self._export_chks.items():
            chk.blockSignals(True)
            chk.setChecked(self._config.is_export_naming_enabled(option))
            chk.blockSignals(False)
        if sys.platform == 'darwin':
            idx = self._macos_auth_source_combo.findData(self._config.macos_auth_source)
            self._macos_auth_source_combo.blockSignals(True)
            self._macos_auth_source_combo.setCurrentIndex(max(0, idx))
            self._macos_auth_source_combo.blockSignals(False)

    # Handlers

    def _clear_roblox_cache(self):
        from .delete_cache import DeleteCacheWindow

        window = DeleteCacheWindow()
        window.show()

    def _on_theme_toggled(self, checked: bool, theme: str):
        if not checked:
            return
        ThemeManager.apply_theme(theme)
        self._config.theme = theme
        if self._tray and hasattr(self._tray, 'theme_actions'):
            for name, action in self._tray.theme_actions.items():
                action.setChecked(name == theme)

    def _on_open_dashboard_toggled(self, checked: bool):
        self._config.open_dashboard_on_launch = checked
        if self._tray and hasattr(self._tray, 'open_dashboard_action'):
            self._tray.open_dashboard_action.setChecked(checked)

    def _on_proxy_features_toggled(self, checked: bool):
        if not checked:
            result = QMessageBox.warning(
                self,
                'Disable Proxy Features?',
                'Turning off proxy features will stop the Replacer, Scraper, '
                'Subplace Joiner, Reserved Server Rejoin, and Subplace Blacklist '
                'because they rely on the local proxy. Continue?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            )
            if result != QMessageBox.StandardButton.Yes:
                self._proxy_features_chk.blockSignals(True)
                self._proxy_features_chk.setChecked(True)
                self._proxy_features_chk.blockSignals(False)
                return

        if self._tray and hasattr(self._tray, 'set_proxy_features_enabled'):
            self._tray.set_proxy_features_enabled(checked)
        else:
            self._config.proxy_features_enabled = checked

    def _on_upstream_mode_changed(self, *_args):
        self._config.upstream_transport_mode = self._upstream_mode_combo.currentData()
        self._sync_manual_proxy_credentials_timer()

    def _on_proxy_mode_changed(self, *_args):
        previous_mode = self._config.proxy_mode
        new_mode = self._proxy_mode_combo.currentData()
        self._config.proxy_mode = new_mode
        if self._config.run_on_boot:
            try:
                boot_ok = sync_autostart(
                    True,
                    CONFIG_DIR,
                    proxy_mode=new_mode,
                )
            except Exception as exc:
                boot_ok = False
                log_message = f'Run on Boot mode refresh failed: {exc}'
                try:
                    from ..utils.logging import log_buffer

                    log_buffer.log('Autostart', log_message)
                except Exception:
                    pass
            if not boot_ok:
                QMessageBox.warning(
                    self,
                    'Run on Boot Update Failed',
                    'Proxy mode changed, but the Run on Boot task could not be refreshed.\n\n'
                    f'{windows_autostart_privilege_hint(new_mode)}\n\n'
                    'Check the application log and repair the task before relying on this mode at sign-in.',
                )
        if new_mode == 'env' and previous_mode != 'env':
            EnvProxyWarningDialog(self).exec()
            # Env mode needs nothing this process doesn't already have, so
            # swap the running proxy over live instead of restarting the app.
            proxy_master = getattr(self._tray, 'proxy_master', None) if self._tray else None
            if proxy_master is not None and hasattr(proxy_master, 'restart_for_mode_switch'):
                proxy_master.restart_for_mode_switch()
                if sys.platform == 'win32':
                    # The proxy may have fallen back from 58443 to a dynamic
                    # port. Arm Store/GDK only after the restarted proxy has
                    # published its final loopback URL.
                    from ..app import _arm_windows_gdk_env_proxy_when_ready

                    run_in_thread(_arm_windows_gdk_env_proxy_when_ready)(proxy_master)
            monitor = getattr(self._tray, 'roblox_monitor', None) if self._tray else None
            lifecycle = getattr(monitor, 'env_lifecycle', None)
            if (
                lifecycle is not None
                and self._config.proxy_features_enabled
                and monitor.is_player_running()
            ):
                if sys.platform.startswith('linux'):
                    exe_path = Path('org.vinegarhq.Sober')
                else:
                    from ..utils import get_roblox_player_exe_path

                    exe_path = get_roblox_player_exe_path()
                run_in_thread(lifecycle.handle_player_launch)(exe_path)
        if new_mode == 'hosts' and previous_mode != 'hosts':
            # Hosts mode may need admin this process doesn't hold - restart
            # the app instead of live-swapping so the new process's own
            # startup flow can request elevation if needed.
            if self._tray and hasattr(self._tray, 'restart_fleasion'):
                self._tray.restart_fleasion()
                return
        if self._tray and hasattr(self._tray, 'notify_proxy_mode_changed'):
            self._tray.notify_proxy_mode_changed()

    def _on_wire_preserving_toggled(self, checked: bool):
        self._config.wire_preserving_passthrough = checked

    def _on_http_proxy_changed(self, *_args):
        self._config.upstream_http_connect_host = self._http_proxy_host.text()
        self._config.upstream_http_connect_port = self._http_proxy_port.value()

    def _on_http_proxy_auth_changed(self):
        self._config.upstream_http_connect_username = self._http_proxy_user.text()
        self._config.upstream_http_connect_password = self._http_proxy_pass.text()
        self._sync_manual_proxy_credentials_timer()

    def _on_socks5_proxy_changed(self, *_args):
        self._config.upstream_socks5_host = self._socks5_host.text()
        self._config.upstream_socks5_port = self._socks5_port.value()

    def _on_socks5_proxy_auth_changed(self):
        self._config.upstream_socks5_username = self._socks5_user.text()
        self._config.upstream_socks5_password = self._socks5_pass.text()
        self._sync_manual_proxy_credentials_timer()

    def _selected_manual_proxy_has_credentials(self) -> bool:
        mode = self._upstream_mode_combo.currentData()
        if mode == 'http_connect':
            return bool(self._http_proxy_user.text().strip() or self._http_proxy_pass.text())
        if mode == 'socks5':
            return bool(self._socks5_user.text().strip() or self._socks5_pass.text())
        return True

    def _sync_manual_proxy_credentials_timer(self) -> None:
        if self._selected_manual_proxy_has_credentials():
            self._manual_proxy_credentials_timer.stop()
        else:
            self._manual_proxy_credentials_timer.start()

    def _revert_manual_proxy_without_credentials(self) -> None:
        if self._selected_manual_proxy_has_credentials():
            return
        auto_index = self._upstream_mode_combo.findData('auto')
        self._upstream_mode_combo.blockSignals(True)
        self._upstream_mode_combo.setCurrentIndex(auto_index)
        self._upstream_mode_combo.blockSignals(False)
        self._config.upstream_transport_mode = 'auto'
        proxy_master = getattr(self._tray, 'proxy_master', None)
        if proxy_master is not None and proxy_master.is_running:

            def _restart_proxy():
                proxy_master.stop()
                proxy_master.start()

            run_in_thread(_restart_proxy)()

    def _on_connection_limits_changed(self, *_args):
        self._config.vpn_compat_max_assetdelivery_connections = self._asset_limit_spin.value()
        self._config.vpn_compat_max_cdn_connections = self._cdn_limit_spin.value()

    def _on_run_on_boot_toggled(self, checked: bool):
        ok = sync_autostart(
            checked,
            CONFIG_DIR,
            proxy_mode=self._config.proxy_mode,
        )
        if ok:
            self._config.run_on_boot = checked
            if self._tray and hasattr(self._tray, 'run_on_boot_action'):
                self._tray.run_on_boot_action.setChecked(checked)
        else:
            if sys.platform == 'win32':
                # Imported on demand to avoid an app <-> GUI import cycle during startup.
                from ..app import _show_run_on_boot_failure

                if _show_run_on_boot_failure(
                    self, self._config.proxy_mode, enabled=checked
                ):
                    self._config.run_on_boot = checked
                    if self._tray and hasattr(self._tray, 'run_on_boot_action'):
                        self._tray.run_on_boot_action.setChecked(checked)
                    return
            self._run_on_boot_chk.blockSignals(True)
            self._run_on_boot_chk.setChecked(not checked)
            self._run_on_boot_chk.blockSignals(False)
            QMessageBox.warning(
                self,
                'Run on Boot Failed',
                'Failed to register the autostart task.\n'
                'Check the application log for details.\n\n'
                'Turn off Run on Boot to stop this error from appearing.',
            )

    def _on_lock_roblox_files_toggled(self, checked: bool):
        self._config.lock_roblox_files_read_only = checked
        mod_manager = getattr(self._tray, 'mod_manager', None)
        if mod_manager is not None and hasattr(mod_manager, 'set_read_only_lock_enabled'):
            mod_manager.set_read_only_lock_enabled(checked)

    def _on_close_env_roblox_toggled(self, checked: bool):
        self._config.close_env_proxy_roblox_on_exit = checked

    def _on_desktop_integration_toggled(self, checked: bool):
        ok = sync_desktop_integration(checked)
        if ok:
            self._config.desktop_integration = checked
            if self._tray and hasattr(self._tray, 'desktop_integration_action'):
                self._tray.desktop_integration_action.setChecked(checked)
            if sys.platform.startswith('linux') and self._config.run_on_boot:
                if not sync_autostart(
                    True,
                    CONFIG_DIR,
                    proxy_mode=self._config.proxy_mode,
                ):
                    QMessageBox.warning(
                        self,
                        'Run on Boot Failed',
                        'Failed to refresh the autostart task after changing desktop integration.\n'
                        'Check the application log for details.\n\n'
                        'Turn off Run on Boot to stop this error from appearing.',
                    )
        else:
            self._desktop_integration_chk.blockSignals(True)
            self._desktop_integration_chk.setChecked(not checked)
            self._desktop_integration_chk.blockSignals(False)
            QMessageBox.warning(
                self,
                'Desktop Integration Failed',
                'Failed to create desktop/start menu integration.\n'
                'Check the application log for details.\n\n'
                'Turn off desktop integration creation to stop this error.',
            )

    def _on_always_on_top_toggled(self, checked: bool):
        self._config.always_on_top = checked
        if self._tray and hasattr(self._tray, 'always_on_top_action'):
            self._tray.always_on_top_action.setChecked(checked)
        if self._tray and hasattr(self._tray, 'open_windows'):
            for window in self._tray.open_windows:
                if window.isVisible():
                    flags = window.windowFlags()
                    if checked:
                        flags |= Qt.WindowType.WindowStaysOnTopHint
                    else:
                        flags &= ~Qt.WindowType.WindowStaysOnTopHint
                    window.setWindowFlags(flags)
                    window.show()

    def _on_close_to_tray_toggled(self, checked: bool):
        self._config.close_to_tray = checked
        if self._tray and hasattr(self._tray, 'close_to_tray_action'):
            self._tray.close_to_tray_action.setChecked(checked)

    def _on_auto_clear_cache_toggled(self, checked: bool):
        self._config.auto_delete_cache_on_exit = checked
        if self._tray and hasattr(self._tray, 'auto_delete_cache_action'):
            self._tray.auto_delete_cache_action.setChecked(checked)

    def _on_clear_cache_launch_toggled(self, checked: bool):
        self._config.clear_cache_on_launch = checked
        if self._tray and hasattr(self._tray, 'clear_cache_action'):
            self._tray.clear_cache_action.setChecked(checked)

    def _on_macos_auth_source_changed(self, *_args):
        if sys.platform != 'darwin':
            return
        self._config.macos_auth_source = self._macos_auth_source_combo.currentData()
        notify_auth_source_changed()

    def _on_import_manual_token(self):
        if sys.platform != 'darwin':
            return
        from .rando_stuff_tab import AddAccountDialog

        dlg = AddAccountDialog(self, title='Import Roblox Token')
        dlg.set_ok_label('Import')
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        if not dlg.result_cookie:
            return
        valid, detail = validate_roblosecurity_for_import(dlg.result_cookie)
        if not valid:
            QMessageBox.warning(
                self,
                'Invalid Roblox Token',
                f'Fleasion could not confirm this Roblox token is valid.\n\n{detail}',
            )
            return
        if not store_manual_roblosecurity(dlg.result_cookie):
            QMessageBox.warning(
                self,
                'Token Import Failed',
                'Fleasion could not store the Roblox token encrypted.',
            )
            return
        self._config.macos_auth_source = 'manual'
        notify_auth_source_changed()
        idx = self._macos_auth_source_combo.findData('manual')
        self._macos_auth_source_combo.blockSignals(True)
        self._macos_auth_source_combo.setCurrentIndex(max(0, idx))
        self._macos_auth_source_combo.blockSignals(False)
        username = dlg.result_username or 'Roblox account'
        QMessageBox.information(self, 'Token Imported', f'{username} was stored encrypted.')

    def _on_close_scraped_games_toggled(self, checked: bool):
        self._config.close_scraped_games_on_open = checked
        if self._tray and hasattr(self._tray, 'close_scraped_games_action'):
            self._tray.close_scraped_games_action.setChecked(checked)

    def _on_close_viewer_on_replace_toggled(self, checked: bool):
        self._config.close_viewer_on_replace = checked
        if self._tray and hasattr(self._tray, 'close_viewer_on_replace_action'):
            self._tray.close_viewer_on_replace_action.setChecked(checked)

    def _on_close_scraped_games_menu_on_open_toggled(self, checked: bool):
        self._config.close_scraped_games_menu_on_open = checked
        if self._tray and hasattr(self._tray, 'close_scraped_games_menu_on_open_action'):
            self._tray.close_scraped_games_menu_on_open_action.setChecked(checked)

    def _on_show_replacer_notifications_toggled(self, checked: bool):
        self._config.show_replacer_notifications = checked
        if self._tray and hasattr(self._tray, 'show_replacer_notifications_action'):
            self._tray.show_replacer_notifications_action.setChecked(checked)

    def _on_show_names_toggled(self, checked: bool):
        self._config.show_names = checked
        if self._tray and hasattr(self._tray, 'show_names_action'):
            self._tray.show_names_action.setChecked(checked)
        self._apply_to_cache_viewer('show_names', checked)

    def _on_show_creator_id_toggled(self, checked: bool):
        self._config.show_creator_id = checked
        if self._tray and hasattr(self._tray, 'show_creator_id_action'):
            self._tray.show_creator_id_action.setChecked(checked)
        self._apply_to_cache_viewer('show_creator_id', checked)

    def _apply_to_cache_viewer(self, setting: str, value: bool):
        if self._tray and self._tray.dashboard_window:
            tab = getattr(self._tray.dashboard_window, '_cache_viewer_tab', None)
            if tab is not None:
                if setting == 'show_names':
                    tab._on_show_names_toggled(value)
                elif setting == 'show_creator_id':
                    tab._on_show_creator_id_toggled(value)

    def _is_cache_scraper_enabled(self) -> bool:
        if self._tray and hasattr(self._tray, '_is_cache_scraper_enabled'):
            return self._tray._is_cache_scraper_enabled()
        return False

    def set_cache_scraper_enabled(self, enabled: bool):
        self._cache_scraper_chk.blockSignals(True)
        self._cache_scraper_chk.setChecked(enabled)
        self._cache_scraper_chk.blockSignals(False)

    def _on_cache_scraper_toggled(self, checked: bool):
        if self._tray and hasattr(self._tray, '_set_cache_scraper_enabled'):
            self._tray._set_cache_scraper_enabled(checked)

    def _on_export_naming_toggled(self, checked: bool, option: str):
        current = self._config.is_export_naming_enabled(option)
        if current != checked:
            new_state = self._config.toggle_export_naming(option)
            self._export_chks[option].blockSignals(True)
            self._export_chks[option].setChecked(new_state)
            self._export_chks[option].blockSignals(False)
        if self._tray and hasattr(self._tray, 'export_naming_actions'):
            self._tray.export_naming_actions[option].setChecked(
                self._config.is_export_naming_enabled(option)
            )
